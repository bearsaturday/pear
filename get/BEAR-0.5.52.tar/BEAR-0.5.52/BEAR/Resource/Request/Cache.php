<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Cache.php 470 2009-02-18 10:11:46Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * リソースキャッシュクラス
 *
 * <pre>
 * リソースリクエストをキャッシュするクラスです。キャッシュするオブジェクトかそうでないかをfacotryで判断しています。
 * DIコンテナでBEAR_Resource_Requestクラスに注入されます。
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Cache.php 470 2009-02-18 10:11:46Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */
class BEAR_Resource_Request_Cache extends BEAR_Base implements BEAR_Resource_Request_Interface
{

    /**
     * コンストラクタ
     * 
     * @param array $config 設定
     */
    function __construct($config)
    {
        //_configプロパティセット
        parent::__construct($config);
    }

    /**
     * factory
     * 
     * <pre>
     * DIコンテナで生成されBEAR_Resource_Requesオブジェクトに注入されます
     * </pre>
     * 
     * @param array $config コンフィグ
     * 
     * @return object
     */
    public function factory($config)
    {
        $isCacheRequst = isset($config['options']['cache']) && !(isset($_GET['_cc'])) && false;
        if ($isCacheRequst === true) {
            $obj = $this;
        } else {
            $obj = BEAR::dependency('BEAR_Resource_Request_Execute', $this->_config, false);
        }
        return $obj;
    }

    /**
     * リクエスト実行クラスを返す
     * 
     * <pre>
     * 実行オブジェクトを作成して返します
     * </pre>
     * 
     * @param string $uri    URI
     * @param array  $values 引数
     * @param string $method リクエストメソッド
     * 
     * @return BEAR_Vo
     */
    public function request($uri, array $values, $method)
    {
        if (isset($this->_config['cache']['key'])) {
            $cacheKey = $this->_config['cache']['key'];
        } else {
            $start    = isset($_GET['_start']) ? $_GET['_start'] : '';
            $sval     = serialize($this->_values);
            $sopt     = serialize($this->_config);
            $cacheKey = "$this->_uri}{$sval}-{$sopt}-{$start}";
            //set
            $this->_config['cache']['key'] = $cacheKey;
        }
        // キャッシュ
        $cache = BEAR::dependency('BEAR_Cache');
        $cache->setLife($this->_config['cache']['life']);
        $vo = $cache->get($cacheKey);
        if ($vo) {
            // キャッシュ読み込み
        } else {
            // キャッシュ書き込み
            $obj = BEAR::dependency('BEAR_Resource_Request_Execute', $this->_config, false);
            $vo  = $obj->request($uri, $values, $method);
            if (!PEAR::isError($vo)) {
                $cache->set($cacheKey, $vo);
            } else {
                // キャッシュ生成エラー
                /* @var $vo PEAR_Error */
                BEAR_Vo::error('No Resource Cache Write');
            }
        }
        return $vo;
    }

    /**
     * キャッシュリクエストか判別
     * 
     * @param array $options オプション
     * 
     * @return bool
     */
    function _isCache($options)
    {
        $isRead = ($this->_method == self::METHOD_READ);
        // キャッシュ
        $isCache = $isRead && isset($options['cache']) &&
                 is_array($options['cache']);
        $isCache = $isCache && (key_exists('life', $options)) ? true : false;
        return $isCache;
    }
}

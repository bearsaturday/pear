<?php
/**
 * BEAR_Resource
 * 
 * PHP versions 5
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Output
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: print.php 425 2009-01-06 11:24:50Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * 変数画面出力
 *
 * @param array $values  値
 * @param array $options オプション
 * 
 * @return BEAR_Vo
 */
function outputPrint($values, $options = null)
{
    $headers = array('X-BEAR-Output: PRINT', 
            array('X-BEAR-Output: PRINT', 
                    'Content-Type: text/html; charset=utf-8'));
    return new BEAR_Vo(print_a($values), $headers);
}
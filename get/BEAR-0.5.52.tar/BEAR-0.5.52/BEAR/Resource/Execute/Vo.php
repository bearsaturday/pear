<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Execute
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: Vo.php 507 2009-03-03 14:21:08Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * VOリソースクラス
 *
 * <pre>
 * VOクラスをリソースとして扱うクラスです。VOクラスはメソッドをもちCRUDインターフェイスに対応します。
 * </pre>
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Execute
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: Vo.php 507 2009-03-03 14:21:08Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 *  */
class BEAR_Resource_Execute_Vo extends BEAR_Base implements BEAR_Resource_Request_Interface
{

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    function __construct($config)
    {
        parent::__construct($config);
    }

    /**
     * リソースアクセス
     *
     * リソースを使用します。
     *
     * @param array  $uri    URI
     * @param array  $values 引数
     * @param string $method リクエストメソッド（無効)
     *
     * @return mixed
     */
    public function request($uri, array $values, $method)
    {
        $fullPath = _BEAR_APP_HOME . '/App/resources/' . $uri . '.php';
        $result   = include_once $fullPath;
        if (!$result) {
            trigger_error("No Resource File=[$fullPath]", E_USER_ERROR);
            $mock = BEAR::dependency('BEAR_Resource_Execute_Mock', $this->_config);
            return $mock->request($uri, $values, $method);
        }
        // VOクラスDI 
        $this->_config['obj'] = BEAR::dependency($this->_config['class']);
        // configを手動でセット
        $this->_config['obj']->_config = $this->_config;
        // アノテーションクラスDI
        $methodName              = 'on' . $method;
        $this->_config['method'] = $methodName;
        $annotation              = BEAR::dependency('BEAR_Annotation', $this->_config);
        // requireアノテーション (引数のチェック)
        $annotation->required($values);
        // aspectアノテーション (アドバイスの織り込み）　
        $method = $annotation->aspect();
        $result = $method->invoke($this->_config['obj'], $values);
        // 後処理
        if (PEAR::isError($result)) {
            $vo = new $this->_config['class']();
            $vo->setCode(BEAR::CODE_ERROR);
        } else {
            if ($result instanceof BEAR_Vo) {
                $vo =& $result;
            } else {
                $this->_config['obj']->setBody($result);
                $vo =& $this->_config['obj'];
            }
        }
        return $vo;
    }
}
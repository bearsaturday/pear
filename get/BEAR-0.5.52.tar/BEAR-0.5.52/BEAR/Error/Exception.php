<?php
/**
 * BEAR_Page
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Page
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Exception.php 518 2009-03-05 19:15:40Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Page/BEAR_Page.html
 */

/**
 * BEAR_Pageエラー
 *
 * <pre>
 * HTTPのステータスコードを出力してエラー終了
 * 
 * 指定のエラーコードとメッセージでエラー終了します。
 * エラー時のHTMLを簡単なものにします。
 * </pre>
 */
class BEAR_Error_Exception extends ErrorException
{
    protected $_httpStatus;
     
    /**
     * コンストラクタ
     *
     * @param int    $httpStatus HTTPレスポンスコード
     * @param string $message    メッセージ
     * @param int    $severity   深刻度
     */
    function __construct($httpStatus, $message, $severity = E_ERROR)
    {
        parent::__construct($message, $httpStatus, $severity);
        $this->_httpStatus = $httpStatus;
    }

    /**
     * HTTPステータスコードの取得
     *
     * @return int
     */
    public function getHttpStatusCode()
    {
        return $this->_httpStatusCode;
    }
}
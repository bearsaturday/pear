<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Util
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Util.php 470 2009-02-18 10:11:46Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Util/BEAR_Util.html
 */

/**
 * ユーティリティクラス
 *
 * <pre>
 * デバックモードの時のみ使用するクラス群です。
 * フレームワークが使用しています。
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Util
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Util.php 470 2009-02-18 10:11:46Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Util/BEAR_Util.html
 */
final class BEAR_Util
{

    /**
     * フレームワーク、アプリケーションの上位パスを削除します
     *
     * @param string &$path パス
     *
     * @return string
     */
    public static function removeKnownPath(&$path)
    {
        $path = str_replace(_BEAR_BEAR_HOME . '/', '', $path);
        $path = str_replace(_BEAR_APP_HOME . '/', '', $path);
        return $path;
    }

    /**
     * サービスを確認する
     *
     * <pre>
     * 現在レジストリに格納されているサービスを表示します。
     * </pre>
     *
     * @return void
     */
    public static function printAllService()
    {
        // service locaterのサービス
        $service = BEAR::getAll();
        foreach ($service as $key => &$row) {
            if (is_object($row)) {
                $row = '(class)' . get_class($row);
            }
        }
        print_a($service, 'label:All Registry');
    }

    /**
     * 再帰でファイルリストを得る
     *
     * @param string $path ファイルまたはディレクトリパス
     *
     * @return array
     */
    public static function getFilesList($path)
    {
        static $_files = array();

        $files = 0;
        $dir   = opendir($path);
        while (($file = readdir($dir)) !== false) {
            if ($file[0] == '.') {
                continue;
            }
            if (strpos($path . DIRECTORY_SEPARATOR . $file, 'beardev') !== false) {
                continue;
            }
            $fileParts = explode('.', $path . DIRECTORY_SEPARATOR . $file);
            if (is_dir($path . DIRECTORY_SEPARATOR . $file)) {
                //dir
                self::getFilesList($path . DIRECTORY_SEPARATOR . $file);
            } else {
                //file
                if (array_pop($fileParts) !== 'php') {
                    continue;
                }
                $fullPath = $path . DIRECTORY_SEPARATOR . $file;
                $_files[] = str_replace(_BEAR_APP_HOME, '', $fullPath);
            }
        }
        closedir($dir);
        return $_files;
    }

    /**
     * 文字列以外の値を確認用に文字列でする。
     *
     * @param mixed $value      mix値
     * @param bool  $onlyScalar スカラーのみ変更
     *
     * @return mixed
     */
    public static function toString($value, $onlyScalar = true)
    {
        $value = is_array($value) && !$value ? 'array()' : $value;
        $value = is_bool($value) && !$value ? '(false)' : $value;
        $value = is_string($value) && !$value ? "''" : $value;
        $value = is_null($value) ? '(null)' : $value;
        if (!$onlyScalar) {
            $value = is_scalar($value) ? $value : http_build_query($value);
        }
        return $value;
    }

    /**
     * 全てのキャッシュをクリア
     *
     * @return void
     */
    public static function clearAllCache()
    {
        clearstatcache();
        $cache = BEAR::dependency('BEAR_Cache');
        $cache->deleteAll();
        print '<div style="font-size: 9px; position: absolute;';
        print ' top: 0px; left: 0px; text-align: left padding:';
        print '5px 3px 3px 3px;background-color:orange;color:white;';
        print 'border: 1px solid #dddddd">Cache Cleard.</div>';
    }

    /**
     *
     */
    public static function countExit($count, $val=false)
    {
        include_once 'BEAR/inc/debuglib.php';
        static $c = 0;

        print '<div style="font-size: 14px; position: absolute;';
        print ' bottom: 0px; right: 0px; text-align: center padding:';
        print '5px 3px 3px 3px;background-color:chocolate;color:white;';
        print 'border: 1px solid black">cnt : ' . $c .'</div>';
        if ($val){
            print_a($val, "label:countExit = " . $c);
        }
        if ($c === $count) {
            exit();
        }
        $c++;
    }
}
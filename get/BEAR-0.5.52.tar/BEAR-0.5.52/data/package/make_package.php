<?php
/**
 * BEARスクリプトライブラリ
 *
 * @package BEAR
 * @subpackage script
 */

/**
 * package.xml生成
 *
 * BEARのパッケージ生成のためのpackage.xmlファイルを生成します。
 * <pre>
 * -------------------------------------
 * Example. パッケージングスクリプト実行準備
 *
 * </pre>
 * <code>
 * sudo pear channel-discover pear.bear-project.net
 * sudo pear install PEAR_PackageFileManager
 * </code>
 * 
 * <pre>
 * 
 * PEAR_PackageFileManagerパッケージインストール
 *
 * </pre><code>
 * $ sudo pear config-set preferred-state beta
 * $ sudo pear install --alldeps PEAR/PEAR_PackageFileManager
 * </code>
 * <pre>
 * パッケージ生成
 *
 * </pre><code>
 * $ cd /path/to/script
 * $ php make_package.php
 * $ php make_package.php make
 * $ cd ..
 * $ pear package-validate package.xml
 * $ pear package
 * </code>
 * <pre>
 * パッケージインストール
 *
 * </pre><code>
 * $ pear install BEAR-x.x.x.tar.gz
 *
 * または
 *
 * $pear channel-discovier {pear.example.com}
 * $pear install {bear}/BEAR
 *
 * </code>
 *
 * @package     BEAR
 * @subpackage  script
 * @since       Tue Feb 28 10:13:31 GMT+09:00 2006
 * @author      koriyama
 * @version     $Id: make_package.php 352 2008-06-27 07:34:02Z koriyama $
 *
 */

// http://pear.php.net/package/PEAR_PackageFileManager/docs/1.6.0a4/PEAR_PackageFileManager/PEAR_PackageFileManager2.html#methodaddReplacement
/**
 * BEARバージョン読み込み
 */
require_once('../../BEAR.php');
/**
 * PackageFileManager2読み込み
 */
require_once('PEAR/PackageFileManager2.php');
//require_once('PEAR/PackageFileManager/File.php');   // avoid bugs

PEAR::setErrorHandling(PEAR_ERROR_DIE);
$description = 'BEAR is web application framework package.';
$package = "BEAR";
$release_status = "beta";
$notes = 'BEAR PHP Framework Package';
$version = BEAR::VERSION;

$config = array(
'filelistgenerator' => 'file',
'packagedirectory' => dirname(dirname(dirname(__FILE__))).'/',
'baseinstalldir' => 'BEAR',
'ignore' => array('CVS/', 'dev/', 'package.xml', '.svn/', ),
'changelogoldtonew' => false,
'description' => $description,
'exceptions' => array('BEAR/BEAR/bin/bear.sh' => 'script'),
'installexceptions' => array('BEAR/BEAR/bin/bear.sh' => '/'),
'installas' => array('BEAR/BEAR/bin/bear.sh' => 'bear'),
//    'simpleoutput' => true,
//'dir_roles' => array('data'=>'data'),
);
$packagexml = new PEAR_PackageFileManager2();
$packagexml->setOptions($config);
$packagexml->setPackage($package);
$packagexml->setSummary($notes);
$packagexml->setDescription($description);

$packagexml->setAPIVersion($version);
$packagexml->setReleaseVersion($version);
$packagexml->setReleaseStability($release_status);
$packagexml->setAPIStability($release_status);
$packagexml->setNotes($notes);
$packagexml->setLicense('The BSD License', 'http://www.opensource.org/licenses/bsd-license.php');
$packagexml->setPackageType('php');
$packagexml->addRole('*', 'php');
$packagexml->addRole('html', 'php');
$packagexml->setPhpDep('5.2.0');
$packagexml->setPearinstallerDep('1.4.0');
// Maintainer
$packagexml->addMaintainer('lead', 'koriyama' , 'koriyama', 'koriyama@users.sourceforge.jp');
// replace
$packagexml->addReplacement('BEAR/BEAR/bin/bear.sh', 'pear-config', '@PEAR-DIR@', 'php_dir');
$packagexml->addReplacement('BEAR/BEAR/bin/bear.sh', 'pear-config', '@DATA-DIR@', 'data_dir');
$packagexml->addReplacement('BEAR/BEAR/bin/bear.sh', 'pear-config', '@PHP-BIN@', 'bin_dir');
$packagexml->addReplacement('BEAR/BEAR/bin/bear.php', 'pear-config', '@PEAR-DIR@', 'php_dir');
$packagexml->addReplacement('BEAR/BEAR/bin/bear.php', 'pear-config', '@DATA-DIR@', 'data_dir');
$packagexml->addReplacement('BEAR/BEAR/bin/bear.php', 'pear-config', '@PHP-BIN@', 'bin_dir');

$packagexml->addRelease();
$packagexml->addInstallAs('BEAR/BEAR/bin/bear.sh', 'bear');
// dependency
$packagexml->addPackageDepWithChannel('required', 'Cache_Lite', 'pear.php.net', '1.7.0');
$packagexml->addPackageDepWithChannel('required', 'HTML_QuickForm', 'pear.php.net', '3.2.5');
$packagexml->addPackageDepWithChannel('required', 'HTML_QuickForm_Renderer_Tableless', 'pear.php.net', '0.6.0');
$packagexml->addPackageDepWithChannel('required', 'HTTP_Upload', 'pear.php.net', '0.9.1');
$packagexml->addPackageDepWithChannel('required', 'HTTP_Download', 'pear.php.net', '1.1.1');
$packagexml->addPackageDepWithChannel('required', 'HTTP_Client', 'pear.php.net', '1.1.0');
$packagexml->addPackageDepWithChannel('required', 'HTTP_Session2', 'pear.php.net', '0.7.2');
$packagexml->addPackageDepWithChannel('required', 'Log', 'pear.php.net', '1.9.3');
$packagexml->addPackageDepWithChannel('required', 'Net_UserAgent_Mobile', 'pear.php.net', '0.26.0');
$packagexml->addPackageDepWithChannel('required', 'Pager', 'pear.php.net', '2.3.6');
$packagexml->addPackageDepWithChannel('required', 'Spreadsheet_Excel_Writer', 'pear.php.net', '0.9.0');
$packagexml->addPackageDepWithChannel('required', 'XML_RPC', 'pear.php.net', '1.4.5');
$packagexml->addPackageDepWithChannel('required', 'XML_Serializer', 'pear.php.net', '0.18.0');
$packagexml->addPackageDepWithChannel('required', 'I18N_UnicodeString', 'pear.php.net', '0.2.1');
$packagexml->addPackageDepWithChannel('required', 'XML_RSS', 'pear.php.net', '0.9.10');
$packagexml->addPackageDepWithChannel('required', 'MDB2', 'pear.php.net', '2.4.0');
$packagexml->addPackageDepWithChannel('required', 'MDB2_Driver_mysqli', 'pear.php.net', '1.4.0');
$packagexml->addPackageDepWithChannel('required', 'XML_RSS', 'pear.php.net', '0.7.2');
$packagexml->addPackageDepWithChannel('required', 'Var_Dump', 'pear.php.net', '1.0.3');
$packagexml->addPackageDepWithChannel('required', 'Text_Highlighter', 'pear.php.net', '0.7.1');
$packagexml->addPackageDepWithChannel('required', 'Config', 'pear.php.net', '1.10.0');
$packagexml->addPackageDepWithChannel('required', 'File', 'pear.php.net', '1.3.0');
$packagexml->addPackageDepWithChannel('required', 'HTTP_Session2', 'pear.php.net', '0.7.2');
$packagexml->addPackageDepWithChannel('required', 'Console_CommandLine', 'pear.php.net', '1.0.6');
$packagexml->addPackageDepWithChannel('required', 'Console_Color', 'pear.php.net', '1.0.2');
$packagexml->addPackageDepWithChannel('required', 'Console_Table', 'pear.php.net', '1.1.3');
$packagexml->addPackageDepWithChannel('required', 'File_SearchReplace', 'pear.php.net', '1.1.2');
$packagexml->addPackageDepWithChannel('required', 'HTTP_Request2', 'pear.php.net', '0.3.0');
// optional (for developper)
$packagexml->addPackageDepWithChannel('optional', 'Zend', 'zend.googlecode.com/svn', '1.6.1');
$packagexml->addPackageDepWithChannel('optional', 'PEAR_PackageFileManager', 'pear.php.net', '1.6.0a7');
$packagexml->addPackageDepWithChannel('optional', 'PHPUnit', 'pear.phpunit.de', '1.3.2');
$packagexml->addPackageDepWithChannel('optional', 'PhpDocumentor', 'pear.php.net', '1.4.2');
$packagexml->addPackageDepWithChannel('optional', 'PHP_CodeSniffer', 'pear.php.net', '1.1.0');
$packagexml->addPackageDepWithChannel('optional', 'FirePHPCore', 'pear.firephp.org', '0.2.1');

// user if no arg
if (!isset($_SERVER['argv'][1])) {
	print ("Usage: php{$_SERVER['argv'][0]} package_uri uri|channel [make]\n");
	print ("ex)\n1) php {$_SERVER['argv'][0]} pear.example.co.jp channel \n");
	print ("2) php {$_SERVER['argv'][0]} pear.example.co.jp channel make\n");
	print ("3) cd ../../\n");
	print ("4) pear package-validate\n");
	print ("5) pear package\n");
	exit();
} else {
	$uri = $_SERVER['argv'][1];
}

// network install package or local package
if ($_SERVER['argv'][2] == 'uri') {
	$packagexml->setUri($uri);
} else {
	$packagexml->setChannel($uri);
}
// this makes local install package
$packagexml->generateContents();
// note use of debugPackageFile() - this is VERY important
if ($_SERVER['argv'][3] != 'debug') {
	debugPrint("writePackageFile\n");
	$result = $packagexml->writePackageFile();
} else {
	$result = $packagexml->debugPackageFile();
	debugPrint("debugPackageFile\n");
}

if (PEAR::isError($result)) {
	debugPrint($result->getMessage()."\n");
	exit();
}
debugPrint("End Script\n");

/**
 * デバック表示
 *
 * @param string $message
 */
function debugPrint($message)
{
	return print($message);
}

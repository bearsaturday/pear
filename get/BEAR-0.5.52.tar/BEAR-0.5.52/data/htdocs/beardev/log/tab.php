<?php
/**
 * ページ変数表示
 *
 * /logs/page.logに保存されたページ状態のログを表示します。
 */

//ライブモードで使用するためApp.phpより先に読み込み
require_once 'BEAR/inc/debuglib.php';
require_once 'App.php';
App::$debug = false;
BEAR::disableAutoLoader();
$pageLog = unserialize(file_get_contents(_BEAR_APP_HOME . '/logs/page.log'));
switch ($_GET['var']) {
    case 'page' :
        $log = $pageLog['page'];
        rsort($log, SORT_NUMERIC);
        foreach ($log as $row){
            echo "<p class=\"uri\">{$row['uri']}</p>";
            print_a($row['page']);
        }
        break;
    case 'smarty' :
        print_a($pageLog['smarty']);
        break;
    case 'var' :
        print $pageLog['var'];
        break;
    case 'ajax' :
        $path = _BEAR_APP_HOME . '/logs/ajax.log';
        $log = file_exists($path) ? unserialize(file_get_contents($path)) : false;
        if (!$log) {
            return;
        }
        rsort($log, SORT_NUMERIC);
        foreach ($log as &$row){
            echo "<p class=\"uri\">{$row['uri']}</p>";
            print_a($row['page']);
        }
        break;
    case 'reg' :
        $reg = $pageLog['reg'];
//        print '<h2>Keys</h2>' . print_a($reg, "show_objects:0; return:1") .'<h2>Values</h2>'  . print_a($reg, "show_objects:1;return:1") ;
        print($reg) ;
        break;
    case 'include' :
        print_a($pageLog['include']);
        break;
    default :
        print_a($pageLog);
        break;
}

$(document).ready( function() {
	// Ajax Form
	$("form").bearAjax({"event":"submit", "url":"/beardev/bearshell/shell.php", "error":"onerror"});
	document.form.q.focus();
	$(document).click(function(){
		document.form.q.focus();
	});
	$("input[type='text']").click();
//	document.form.q.focus();
	$("#q").focus();
	$().print_b("shell ready...");
});
$("#q").focus();

<?php
/**
 * @package App
 * @subpackage page
 */
require_once 'App.php';

/**
 * Untitled Page
 * 
 * description here...
 *
 * @package     App
 * @subpackage  page
 * @author      $Author: $
 * @version     $Id: $
 */
class Index extends App_Page
{

    function onInit()
    {}

    function onOutput()
    {
        $this->display();
    }

    function onAction($submit)
    {
        $this->set('submit', $submit);
        $this->display();
    }
}

new BEAR_Main('Index');
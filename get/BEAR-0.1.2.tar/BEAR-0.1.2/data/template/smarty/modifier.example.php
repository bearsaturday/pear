<?php
/**
 * App Smarty plugin
 * @package App
 * @subpackage smarty
 */

/**
 * Smarty sample modifier
 *
 * <pre>Enter description here...
 * </pre>
 * 
 * Example1.<br>
 *
 * <code>
 * {$name|sample:"size=16 maxlength=32"}
 * </code>
 *
 * @author  $Author: $
 * @version $Id: $
 * @param   string $string
 * @param   string $attribute_string
 * @return  string
 */
function smarty_modifier_example($string, $option)
{
    $result = $string;
    return $result;
}
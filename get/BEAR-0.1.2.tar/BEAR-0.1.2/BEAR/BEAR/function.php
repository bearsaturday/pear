<?php
/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$

 **
 * print_a関数読み込み
 */
require_once ('BEAR/inc/debuglib.php');

/**
 * デバック用プリント
 *
 * デバック用に変数を表示します。<var>$ouputMode</var>を変え様々なフォーマットで変数表示可能です。
 *
 * Example. print_a(http://www.atomar.de/debuglib/)方式
 *
 * <code>
 * p($values)　//件数が多いときはメモリ消費をふせぐために自動的に'v'になります。
 * </code>
 *
 * Example. 通常ではメモリエラーが出るときなどにVar_Dump方式
 *
 * <code>
 * p($values, 'var') // or 'v'
 * </code>
 *
 * Example. アプリケーションログ画面表示（画面をくずしません）
 *
 * <code>
 * p($values, 'app') // or 'a'
 * </code>
 *
 * Example. ヘッダーに出力
 *
 * <code>
 * p($values, 'header') // or 'h'
 * </code>
 *
 * Example. syslog方式
 *
 * <code>
 * p($values, 'syslog') // or 's' 
 * </code>
 *
 * @param mixed $values
 * @param string $ouputMode 出力形式
 * @see http://www.atomar.de/debuglib/
 */
function p($values = '', $ouputMode = '')
{
    if (count($values, COUNT_RECURSIVE) > 200) {
        $ouputMode = 'var';
    }
    $trace = (debug_backtrace());
    $file = $trace[0]['file'];
    $include_path = explode(":", get_include_path());
    // include_pathがあれば除去
    foreach($include_path as $var) {
        if ($var != '.') {
            $file = str_replace($var, '', $file);
        }
    }
    $file = substr($file, 1); //先頭の/を除去
    $method = (isset($trace[1]['function'])) ? " ({$trace[1]['class']}" . '->' . "{$trace[1]['function']})" : '';
    $label = "in {$file} on line {$trace[0]['line']}$method";
    switch ($ouputMode) {
        case 1 :
        case 'v' :
        case 'var' :
            require_once ('Var_Dump.php'); // auloader doesn't work
            Var_Dump::displayInit(array(
                    'display_mode' => 'HTML4_Text'));
            print $label;
            Var_Dump::display($values);
            break;
        case 2 :
        case 'a' :
        case 'applog' :
            BEAR_Log::appLog('p()', array('location' => $label) + $values);
            break;
        case 3 :
        case 'h' :
        case 'header' :
            header("x-bear-debug-$label", print_r($values, true));
            break;
        case 4 :
        case 's' :
        case 'syslog' :
            syslog("label:$label" . print_r($values, true));
            break;
        default :
            $options = "show_objects:1;max_y:50;label:{$label}";
            print_a($values, $options);
    }

}

/**
 * クラスリバーシエンジニアリング表示
 *
 * クラスの内容概略が画面表示されます。環境に寄っては利用できません。
 * 
 * <code>
 * c('BEAR_Form');  //クラス
 * c($obj);　//オブジェクト
 * </code>
 *
 * @param string $class クラスまたはオブジェクト
 */
function c($class)
{
    if (is_object($class)) {
        $class = get_class($class);
    }
    if (!is_string($class) && !class_exists($class, true)) {
        print("c error: $class is unavailable (not class or unloaded)");
        return;
    }
    ob_start();
    $reflection = ob_get_clean();    
    require_once ('Var_Dump.php'); // auloader doesn't work
    Var_Dump::displayInit(array('display_mode' => 'HTML4_Text'));
    Reflection::export(new ReflectionClass($class));
    $reflection = ob_get_clean();
    $option = "show_objects:1;label:{$class}";
    print_a($reflection, $option);    //	$option = "show_objects:1;label:{$class}";
}

/**
 * バックトレース表示
 * 
 * <code>
 * t(1); //直前のトレースを表示します
 * t(); //最初から全てのトレースを表示します
 * </code>
 *
 * @param integer $level 省略時はすべて
 */
function t($level = false)
{
    $trace = debug_backtrace();
    if ($level === false) {
        $var = $trace;
    } else {
        unset($trace[$level]['args']->backtrace);
        $var = $trace[$level];
    }
    p($var, 'v');
}

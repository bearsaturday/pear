<?php
/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Pager
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * PEAR ページャーライブラリ読み込み
 */
require_once ('Pager.php');

/**
 *
 * ページャークラス
 *
 * <pre>
 *  データを分割して表示するページャークラスです。
 *　BEAR_Resourceクラスと組み合わせて、viewのスライスやリンクの生成などを行います。
 *
 * このクラスではDBページングの機能は持っていません。ページャーの扱えるDBから取得するなどデータを
 * 全て用意してからデータスライスします。PEARのPagerクラスを利用しています。
 *
 * DBページングはBEAR_DBクラスで実装されています。
 *
 * Example 1. 10アイテム毎のページング処理をしたアイテムとナビゲートHTMLをsmartyでアサイン
 * </pre>
 *
 * </code>
 * $pager = new BEAR_Pager();
 * $pager->setOption('perPage', 10);                  // 10アイテム/page
 * $pager->setOption('linkClass', $linkCssClass);    // HTML CSS指定
 * $pager->makePage($itemData);
 * $view = $pager->getResult();
 * $pager = $pager->getLinks();
 * $smarty->assign('view', $view);
 * $smarty->assign('pager', $pager);
 * </code>
 * <pre>
 *
 * Example 2. PagerオプションのデフォルトをPC,モバイル共に設定
 * </pre>
 *
 * <code>
 * //ページャー設定
 * BEAR_Pager::$options_pc = array('separator'=>'|');
 * BEAR_Pager::$options_mobile = array('separator'=>'');
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Pager
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Pager.php 406 2008-07-02 06:41:10Z koriyama $
 * @see         PEAR::Pager
 */
class BEAR_Pager
{

    /**
     * PEARページャークラス
     *
     * @var object
     */
    public $pager;

    /**
     * ページャーオプション
     *
     * @var     array
     * @access  private
     * @see http://pear.php.net/manual/ja/package.html.pager.factory.php
     */
    private $_options;

    /**
     * ページャーでスライスされたビュー
     *
     * @var array
     * @access  private
     */
    private $_pager_result;

    /**
     * ページャーリンクHTML
     *
     * @var string
     * @access private
     */
    private $_links;

    /**
     * PC用ページャーオプション
     */
    public static $options_pc = array();

    /**
     * モバイル用ページャーオプション
     */
    public static $options_mobile = array();

    /**
     * コンストラクタ
     *
     * エージェントに応じて（PC,携帯）ページャーオプションを変えます。
     *
     * @param   void
     * @see http://pear.php.net/manual/ja/package.html.pager.factory.php
     */
    function __construct()
    {
        $session_id = session_name();
        switch (BEAR::$ua) {
            // PC
            case BEAR_Agent::UA_PC :
                $this->_options = array(
                        'perPage' => 10,  // ページごとに表示するアイテムの数を指定します
                        'delta' => 10,  // 現在のページの前後に表示するページ番号の数を指定します
                        'urlVar' => '_start',  // ページ番号を示すためのURL変数名を指定します。
                        'prevImg' => '前へ',  // Prevボタン（IMGタグをつけてグラフィック表示も可能）
                        'nextImg' => '次へ',  // Nextボタン（IMGタグをつけてグラフィック表示も可能）
                        'separator' => ' ',  // セパレーター
                        'linkClass' => 'page',  // リンクスタイルのためのCSSクラス名を指定します
                        'totalItems' => 100,  // アイテム総数
                        'excludeVars' => array(
                                $session_id));
                break;
            // Mobile
            default :
                $this->_options = array(
                        'perPage' => 10, 
                        'delta' => 5, 
                        'altNext' => 'Next', 
                        'urlVar' => '_start', 
                        'prevImg' => '<<(*)', 
                        'nextImg' => '>>(#)', 
                        'separator' => ' ', 
                        'totalItems' => 100, 
                        'excludeVars' => array(
                                $session_id));
                break;
        }
        // オプションを指定されていれば値があればオーバーライド
        if (BEAR::$ua == BEAR_Agent::UA_PC && self::$options_pc) {
            $this->_options = array_merge($this->_options, self::$options_pc);
        } elseif (BEAR::$ua != BEAR_Agent::UA_PC && self::$options_mobile) {
            $this->_options = array_merge($this->_options, self::$options_mobile);
        }
        // ページャーオブジェクト
        $this->pager = Pager::factory();
    }

    /**
     * ページャーオプションの取得
     */
    public function getPagerOptions()
    {
        return $this->_options;
    }

    /**
     * ページング
     *
     * <pre>
     * ページング処理します。
     * ページングされた結果とページナビゲーションHTMLの生成をプロパティに保持します。
     * </pre>
     *
     * @param array $view ページングするデータアイテム
     */
    function makePager($view)
    {
        if (is_null($view)) {
            //$viewが無い
            $this->_links = NULL;
            return;
        } else {
            $this->_options['itemData'] = $view;
            // Pager オブジェクトを作成
            $this->pager->setOptions($this->_options);
            $this->pager->build();
            // ページデータを取得
            $this->_pager_result = $this->pager->getPageData();
            // リンク
            $this->_links = $this->pager->getLinks();
        }
    }

    /**
     * ページングリンク生成
     *
     * データをページングしないでリンクのみ生成します
     *
     * @param string $total_items
     * @param string
     */
    function makeLinks($delta, $total_items)
    {
        $this->_options['delta'] = $delta;
        $this->_options['totalItems'] = $total_items;
        // Pager オブジェクトを作成
        $this->pager->setOptions($this->_options);
        $this->pager->build();
        $this->_links = $this->pager->getLinks();
        return $this->_links;
    }

    /**
     * ページャーオプションの設定
     *
     * オプションを１つ設定します。
     * 
     * @param    string  $key    オプションキー（上記参照）
     * @param    string  $str    オプション値
     * @return   void
     * @access   public
     * @see     http://pear.php.net/manual/ja/package.html.pager.factory.php
     * @see BEAR_Pager::setOptions(9
     */
    public function setOption($key, $option_value)
    {
        $this->_options[$key] = $option_value;
    }

    /**
     * ページャーオプション設定
     *
     * ページャーのオプションを連想配列で指定します。
     *
     * @param array $options
     * @return void
     * @see http://pear.php.net/manual/ja/package.html.pager.factory.php
     * @see BEAR_Pager::setOption()
     *      */
    function setOptions($options)
    {
        assert(is_array($options));
        $this->_options = $options + $this->_options;
    }

    /**
     * ページング結果の取得
     *
     * <pre>ページングされた結果の取得を行います。</pre>
     *
     * @param    void
     * @return   array  ページングされた結果
     * @access   public
     */
    public function getResult()
    {
        return $this->_pager_result;
    }

    /**
     * ナビゲートリンクの取得
     *
     * <pre>ページのナビゲートHTMLを取得します。
     * エージェントに応じたHTMLを生成し、携帯の場合はアクセスキーが利用できます。</pre>
     *
     * @param    $links mixed false | リンクHTML配列
     * @return   array  ナビゲートリンクHTML
     * @access   public
     */
    public function getLinks($links = false)
    {
        // エラーチェック　-  make(), makeView()をしていないときにこのメソッドを呼んでも無効
        assert(is_object($this->pager));
        $links = ($links) ? $links : $this->_links;
        // PC
        if (BEAR::$ua == BEAR_Agent::UA_PC) {
            return $links;
        }
        // 携帯 $links['all']を書き換え
        $has_back = $has_next = false;
        if ($links['next']) {
            $next = str_replace(' title=', ' accesskey="#" title=', $links['next']);
            $has_next = true;
        }
        if ($links['back']) {
            $back = str_replace(' title=', ' accesskey="*" title=', $links['back']);
            $has_back = true;
        }
        $links['back_mobile'] = $back;
        $links['next_mobile'] = $next;
        /** @var $this->pager Pager */
        $current = $this->pager->getCurrentPageID();
        $total = $this->pager->numPages();
        switch (array($has_back, $has_next)) {
            case array(false, 
                    true) :
                $links['all'] = "<font color=gray >{$this->_options['prevImg']} $current/$total</font> {$next}";
                break;
            case array(true, 
                    false) :
                $links['all'] = "{$back} <font color=gray>$current/$total {$this->_options['nextImg']}</font>";
                break;
            case array(true, 
                    true) :
                $links['all'] = "{$back} | {$next}";
                $links['all'] = "{$back} <font color=gray>$current/$total</font> {$next}";
            default :
                break;
        }
        // セッションクエリーを削除
        return $links;
    }

    /**
     * AJAX用ページャーリンクを取得
     *
     * リンクにrel="bear"をつけbear.js用のAJAXのリンクにします
     *
     * @param void
     * @return array
     */
    public function getAjaxLinks()
    {
        $links = $this->_links;
        foreach($key as $value) {
            $value = preg_replace('/<a\s/', '<a rel="bear" >', $value);
            $array[$key] = $value;
        }
        return $array;
    }
}
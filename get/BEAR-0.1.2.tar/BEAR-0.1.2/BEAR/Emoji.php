<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Emoji
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * 絵文字クラス
 *
 * <pre>
 * 絵文字を取り扱うためのクラスです。携帯の絵文字のキャリア相互変換、imgタグによる絵文字の画像表示が行えます。
 * ソフトバンクモバイルの3G端末、旧端末どちらもサポートします。UTF8絵文字からwebコード絵文字の変換が行えます。
 * 絵文字変換はメール時の変換にキャリアが仕様してる変換マップに基づいています。対応する絵文字が無い場合はカタカナで表現されます。
 *
 * 注） 絵文字変換を行う場合、最低でも16MのPHPへのメモリ割り当てが必要です。
 *
 *
 * Example 1. iモード絵文字の絵文字を含む文字列を閲覧しているUAに応じて変換
 *
 * </pre>
 * <code>
 * //iモード絵文字を現在のUAの携帯絵文字に変換
 * $bear_emoji = BEAR_Emoji::getInstance($string, BEAR_Agent::UA_DOCOMO);
 * $result = $bear_emoji->convert();
 * </code>
 *
 * Example 2. UTF8のSB文字列のポストをWebコードに変換する
 *
 * <code>
 * $result = BEAR_Emoji::encodeWebCode($sb_utf8_emoji);
 * </code>
 *
 * Example 3. 絵文字を除去する
 *
 * <code>
 * $result = BEAR_Emoji::removeEmoji($string);
 * </code>
 *
 * Example 4. 絵文字をIMGタグにする
 *
 * <code>
 * //タグをセット
 * BEAR_Emoji::setDefaultImgTag('<img src="/emoji/');
 * $bear_emoji = BEAR_Emoji::getInstance($string, BEAR_Agent::UA_DOCOMO);
 * $result = $bear_emoji->imgTag();
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Emoji
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 */
class BEAR_Emoji
{

    /**
     * iモード絵文字10進数エンティティ開始番号
     *
     */
    const IMODE_MIN = 63552; //#F840

    
    /**
     * iモード絵文字10進数エンティティ終了番号
     *
     */
    const IMODE_MAX = 63996; //#F9FC

    
    /**
     * Ez絵文字10進数エンティティ開始番号
     *
     */
    const EZ_MIN = 62272; //#F340

    
    /**
     * Ez絵文字10進数エンティティ終了番号
     *
     */
    const EZ_MAX = 63484; //#F7FC

    
    /**
     * 絵文字imgタグ
     */
    public static $imgTag = '<img src="/emoji';

    /**
     * 入力文字列
     *
     * @var string
     * @access private
     */
    private $_string;

    /**
     * 携帯キャリアコード
     *
     * @var string
     * @access private
     */
    private $_ua;

    /**
     * 絵文字変換テーブル1
     *
     * @var bool
     * @access private
     */
    private $_emojiConvertMap = false;

    /**
     * シングルトンインスタンス
     *
     * @var BEAR_Emoji
     */
    private $_insatance;

    /**
     * 
     * シングルトンパターンクラスのためコンストラクタ不可
     * 
     */
    final private function __construct()
    {}

    /**
     * シングルトン
     *
     * シングルトンででインスタンスを取得します
     *
     * @param array $config
     *  + string: 入力文字列
     *  + ua: UAコード falseで自動判別
     * @return BEAR_Emoji
     */
    public function &getInstance($config = array('string'=>'', 'ua'=>false))
    {
        $string = $config['string'];
        $string = $config['ua'];
        if (!isset(self::$_instance)) {
            //インスタンス生成
            self::$_instance = new BEAR_Emoji();
        }
        $ua = ($ua === false) ? BEAR::$ua : $ua;
        // SBコード変換 - SBではなくSJISでもない文字列をBEAR_Emojiクラス内でSJIS-winとして処理するため
        if ($ua != BEAR_Agent::UA_SOFTBANK && mb_detect_encoding($string, _BEAR_DETECT_ORDER, true) != 'SJIS-win') {
            $string = mb_convert_encoding($string, 'SJIS-win', 'UTF-8');
        }
        $instance->_string = $string;
        $instance->_ua = $ua;
        return self::$_instance;
    }

    /**
     * SB3G端末の絵文字入りUTF-8コードの文字列をwebコードの絵文字文字列に変換
     *
     * <pre>SB3G端末からポストされた絵文字入りのユニコード文字列をwebコードのUTF-8に変換します。
     * (注意）3G端末のSJISページでは絵文字はポストされない。SBで絵文字を取り扱うにはUTF8ページを用意する必要があります。
     * </pre>
     *
     * @param   string $utf8
     * @return  string
     * @static
     */
    public function encodeWebCode($utf8)
    {
        $result = array();
        $unicodes = I18N_UnicodeString::utf8ToUnicode($utf8);
        foreach($unicodes as $unicode_decimal) {
            //絵文字処理
            if (($unicode_decimal > 0xE000 && $unicode_decimal <= 0xE53E)) {
                if (($unicode_decimal > 0xE000 && $unicode_decimal < 0xE100)) {
                    $offset = hexdec('98E0');
                } elseif ($unicode_decimal > 0xE100 && $unicode_decimal < 0xE300) {
                    $offset = hexdec('9BE0');
                } else {
                    $offset = hexdec('93E0');
                }
                $webcode_decimal = $unicode_decimal - $offset;
                //絵文字
                //1B24 (ESC開き)
                $result[] = 0x1b;
                $result[] = 0x24;
                //絵文字2バイトコード
                $result[] = ($webcode_decimal >> 8) & 0xff;
                $result[] = $webcode_decimal & 0xff;
                //0F (ESC閉じ)
                $result[] = 0x0f;
            } else {
                //非絵文字
                $result[] = $unicode_decimal;
            }
        }
        //unicodeからUTF8に
        $i18 = new I18N_UnicodeString($result, 'Unicode');
        $result = $i18->toUtf8String();
        return $result;
    }

    /**
     * 10進数エンティティをつくる
     *
     * <pre>
     * stringプロパティの文字列を10進エンティティにしてentityプロパティに格納して返します
     * </pre>
     * @param bool $is_voder_utf8_post SBでUTF8からポストされたか
     * @param string
     */
    public function makeDecEntity($is_voder_utf8_post = false)
    {
        switch ($this->_ua) {
            case BEAR_Agent::UA_SOFTBANK :
                if ($is_voder_utf8_post) {
                    $unicodes = I18N_UnicodeString::utf8ToUnicode($this->_string);
                    $i18 = new I18N_UnicodeString($unicodes, 'Unicode');
                    $this->_string = $i18->toUtf8String();
                    $encode = 'UTF8';
                    $conv_map = $this->_getEmojiMap();
                    $this->_string = mb_encode_numericentity($this->_string, $conv_map, $encode);
                } else {
                    //'SJIS-win'
                    $emoji_regex = '[\xE0-\xE4][\x00-\xFF]|[\xE5][\x00-\x3A]';
                    $this->_string = $this->_makeEntityByRegex($this->_string, $emoji_regex);
                }
                break;
            case BEAR_Agent::UA_DOCOMO :
                $emoji_regex = '[\xF8\xF9][\x40-\x7E\x80-\xFC]';
                $this->_string = $this->_makeEntityByRegex($this->_string, $emoji_regex);
                break;
            case BEAR_Agent::UA_AU :
                // AUの文字範囲
                // F340～F3FC
                // F440～F493
                // F640～F6FC
                // F740～F7FC
                $emoji_regex = '[\xF3\xF6\xF7][\x40-\xFC]|[\xF4][\x40-\x93]';
                $this->_string = $this->_makeEntityByRegex($this->_string, $emoji_regex);
                break;
            default :
                $encode = '';
                break;
        }
        return $this->_string;
    }

    /**
     * 正規表現により絵文字を数値エンティティに変換
     *
     * makeDecEntity()からコールされます。
     *
     * @param string $emoji 絵文字の正規表現
     * @return string
     * @access private
     */
    private function _makeEntityByRegex($string, $emoji)
    {
        $mb_regex_encoding = mb_regex_encoding();
        mb_regex_encoding('SJIS');
        $sjis = '[\x81-\x9F\xE0-\xEF][\x40-\x7E\x80-\xFC]|[\x00-\x7F]|[\xA1-\xDF]';
        $pattern = "/\G((?:$sjis)*)(?:($emoji))/";
        // 絵文字を検索
        preg_match_all($pattern, $string, $arr); // $arr[2]に対象絵文字が格納される
        // 絵文字を置換
        $converted = $string;
        foreach($arr[2] as $value) {
            $pattern_rep = "$value";
            $emoji_cd = unpack("C*", $value);
            $hex = dechex($emoji_cd[1]) . dechex($emoji_cd[2]);
            $replacement = '&#' . hexdec($hex) . ';';
            $converted = mb_ereg_replace($pattern_rep, $replacement, $converted);
        }
        mb_regex_encoding($mb_regex_encoding);
        return $converted;
    }

    /**
     * 16進エンティティをつくる
     *
     * <pre>
     *  10進エンティティから16進エンティティをつくります。
     * _stringプロパティの文字列を10進エンティティにして_stringプロパティに格納して返します
     * </pre>
     *
     * @param void
     * @return string
     */
    public function makeHexEntity()
    {
        $regex = '/&#(\d{5});/is';
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', 'onHexEntity'), $this->_string);
        return $this->_string;
    }

    /**
     * PCで携帯絵文字を表示するために対応するgif画像にする
     *
     * <pre>
     *  10進エンティティから絵文字画像のimgタグをつくります。
     * _stringプロパティの文字列を10進エンティティにしてentityプロパティに格納して返します
     * </pre>
     *
     * @param void
     * @return string
     */
    public function makeImgTag()
    {
        //変換
        if (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) {
            $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
        } else {
            $regex = '/&#(\d{5});/is';
        }
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', 'onImgTag'), $this->_string);
        return $this->_string;
    }

    /**
     * 絵文字をIMGタグに変換します
     *
     * 絵文字を内部で10進エンティティにした後、キャリアが違えば対応する絵文字のイメージタグにします。
     *
     * @param void
     * @return string
     */
    public function imgTag()
    {
        $this->makeDecEntity();
        $result = $this->makeImgTag();
        return $result;
    }

    /**
     * 16進エンティティ絵文字表記にするための正規表現からコールバックメソッド
     *
     * @param array $matches
     * @return string
     * @access private
     */
    private function onHexEntity($matches)
    {
        $result = '&#x' . dechex($matches[1]) . ';';
        return $result;
    }

    /**
     * イメージタグを生成するための正規表現からコールバックメソッド
     *
     * @param array $matches
     * @return string
     * @access private
     */
    private function onImgTag($matches)
    {
        $imgTag = BEAR_Emoji::$imgTag;
        $ext = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) ? '.png' : '.gif';
        $emoji_id = $matches[1];
        switch (BEAR::$ua) {
            case BEAR_Agent::UA_DOCOMO :
                $emoji_id = strtoupper(dechex($emoji_id));
                $image_file_name = $emoji_id . $ext;
                $result = "{$imgTag}/{$ua}/{$image_file_name}\" border=0>";
                break;
            case BEAR_Agent::UA_AU :
                $emoji_id = (dechex($emoji_id));
                $image_file_name = $emoji_id . $ext;
                $result = "{$imgTag}/{$ua}/{$image_file_name}\" border=0>";
                break;
            case BEAR_Agent::UA_SOFTBANK :
                $voda_emoji = array();
                $stirng = $matches[0];
                for($i = 3; $i < strlen($stirng) - 1; $i++) {
                    $voda_emoji[] = $stirng[$i];
                }
                $emojis = array();
                $result = "";
                foreach($voda_emoji as $emoji) {
                    $webcode_hex_high = dechex(ord($stirng[2]));
                    $webcode_hex_low = dechex(ord($emoji));
                    $webcode_hex_highlow = strtoupper($webcode_hex_high . $webcode_hex_low);
                    $image_file_name = $webcode_hex_highlow . $ext;
                    $result = "{$imgTag}/{$ua}/{$image_file_name}\" border=0>";
                }
                break;
            default :
                trigger_error('BEAR_Emoji,piev PEAR static property not defined.');
                break;
        }
        return $result;
    }

    /**
     * imageTag用コールバック関数
     *
     * <pre>自分のキャリアではない絵文字をイメージタグに変換して返します</pre>
     *
     * @param array $matches
     * @return string
     * @access private
     * @deprecated
     */
    private function onEmojiImage($matches)
    {
        $imgTag = & PEAR::getStaticProperty('BEAR_Emoji', 'img_tag');
        if (!$imgTag) {
            $imgTag = '<img src="/emoji';
        }
        $ext = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) ? '.png' : '.gif';
        $emoji_id = $matches[1];
        //キャリア判定
        if (self::IMODE_MIN <= $emoji_id && $emoji_id <= self::IMODE_MAX) {
            $ua = BEAR_Agent::UA_DOCOMO;
        } elseif (self::EZ_MIN <= $emoji_id && $emoji_id <= self::EZ_MAX) {
            $ua = BEAR_Agent::UA_AU;
        } else {
            $ua = BEAR_Agent::UA_SOFTBANK;
        }
        $agent_piev = & PEAR::getStaticProperty('BEAR_Emoji', 'agent_piev');
        if ($agent_piev == $ua) {
            //Docomo/Ezの場合はエンティティからpack,SBの場合はWebコードのまま
            $result = pack('n', $emoji_id);
        } else {
            switch ($ua) {
                case BEAR_Agent::UA_DOCOMO :
                    $emoji_id = strtoupper(dechex($emoji_id));
                    $image_file_name = $emoji_id . $ext;
                    $result = "{$imgTag}/{$ua}/{$image_file_name}\" border=0>";
                    break;
                case BEAR_Agent::UA_AU :
                    $emoji_id = (dechex($emoji_id));
                    $image_file_name = $emoji_id . $ext;
                    $result = "{$imgTag}/{$ua}/{$image_file_name}\" border=0>";
                    break;
                case BEAR_Agent::UA_SOFTBANK :
                    $voda_emoji = array();
                    $stirng = $matches[0];
                    for($i = 3; $i < strlen($stirng) - 1; $i++) {
                        $voda_emoji[] = $stirng[$i];
                    }
                    $emojis = array();
                    $result = "";
                    foreach($voda_emoji as $emoji) {
                        $webcode_hex_high = dechex(ord($stirng[2]));
                        $webcode_hex_low = dechex(ord($emoji));
                        $webcode_hex_highlow = strtoupper($webcode_hex_high . $webcode_hex_low);
                        $image_file_name = $webcode_hex_highlow . $ext;
                        $result = "{$imgTag}/{$ua}/{$image_file_name}\" border=0>";
                    }
                    break;
                default :
                    break;
            }
        }
        return $result;
    }

    /**
     * 絵文字コードマップの取得
     *
     *
     * <pre>絵文字コードマップの配列を取得します。
     *
     * マップフォーマット
     * i,e
     * 絵文字UNICODE開始, 絵文字UNICODE終了,UNICODE<=>SJISオフセット, マスク
     * v
     * 絵文字UNICODE開始, 絵文字UNICODE終了,0, マスク
     *
     * </pre>
     *
     * @param string $ua
     * @return array
     * @access private
     */
    private function _getEmojiMap($ua = false)
    {
        if (!$ua) {
            $ua = $this->_ua;
        }
        switch ($this->_ua) {
            case BEAR_Agent::UA_DOCOMO :
                // Unicode絵文字表
                $result = array(0xE63E, 0xE69B, 0x1261, 0xFFFF, //F89F-F8FC(SJIS)
0xE69C, 0xE6A5, 0x12A4, 0xFFFF, //F940-F949
0xE6CE, 0xE6DA, 0x12A4, 0xFFFF, //F972-F97E
0xE6DB, 0xE757, 0x12A5, 0xFFFF); //F980-F9FC
                break;
            case BEAR_Agent::UA_AU :
                $result = array(0xE468, 0xE4A6, 0x11D8, 0xFFFF, //0xF640 0xF67E
0xE4A7, 0xE523, 0x11D9, 0xFFFF, //0xF680-0xF6FC
0xE524, 0xE562, 0x121C, 0xFFFF, //0xF740-0xF77E
0xE563, 0xE5B4, 0x121D, 0xFFFF, //0xF780-
0xE5B5, 0xE5CC, 0x1230, 0xFFFF, //0xF7E5-
0xE5CD, 0xE5DF, 0x0D73, 0xFFFF, //0xF340-
0xEA80, 0xEAAB, 0x08D3, 0xFFFF, //0xF353-
0xEAAC, 0xEAFA, 0x08D4, 0xFFFF, //0xF380-
0xEAFB, 0xEB0D, 0x0CD7, 0xFFFF, //0xF7D2-
0xEB0E, 0xEB3B, 0x08C1, 0xFFFF, //0xF3CF-
0xEB3C, 0xEB7A, 0x0904, 0xFFFF, //0xF440-
0xEB7B, 0xEB88, 0x0905, 0xFFFF); //0xF480-
                break;
            case BEAR_Agent::UA_SOFTBANK :
                $result = array(0xE000, 0xE53A, 0x000, 0xFFFF);
                break;
            //            case 'h':
            //                $result = array(
            //                                                    //iモードコンパチ絵文字
            //                0xE63E, 0xE69B, 0x1261, 0xFFFF,     //F89F-F8FC(SJIS)
            //                0xE69C, 0xE6A5, 0x12A4, 0xFFFF,     //F940-F949
            //                0xE6CE, 0xE6DA, 0x12A4, 0xFFFF,     //F972-F97E
            //                0xE6DB, 0xE757, 0x12A5, 0xFFFF,     //F980-F9FC
            //                                                    //willcomeネイティブ絵文字
            //                0xE000, 0xE53A, 0x000, 0xFFFF       //F040-F14F
            //                );
            //                break;
            default :
                $result = PEAR::raiseError('invalid ua');
                break;
        }
        return $result;
    }

    /**
     * 絵文字変換
     *
     * <pre>
     * 絵文字変換マップを使って10進エンティティから他キャリアの対応する絵文字に変換します。
     * </pre>
     *
     * @param string $to デフォルトはエージェント
     * @return string
     */
    public function convert($to = false)
    {
        //10進エンティティに
        $this->makeDecEntity();
        $to_ref = & PEAR::getStaticProperty('BEAR_Emoji', 'to');
        //toを保存
        $to_ref = ($to) ? $to : BEAR::$ua;
        //変換
        if ($this->_ua == BEAR_Agent::UA_SOFTBANK) {
            $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
        } else {
            $regex = '/&#(\d{5});/is';
        }
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', 'onConvertEmoji'), $this->_string);
        return $this->_string;
    }

    /**
     * エンティティ化されている絵文字を含んだ文字列をイメージタグに変換します
     *
     * <pre>smartyのoutputフィルターなどに使用します。$uaで指定したエージェント
     * (無指定の場合は使用しているエージェント）の絵文字はバイナリ出力されます。
     * PC(_BAER_UA_PC)を指定すると全ての絵文字がイメージタグ表示されます。</pre>
     *
     * @param string $string
     * @param string $ua
     * @return string
     * @static
     * @deprecated
     * @ignore
     */
    public function imageTag($string, $ua = false)
    {
        if (!$ua) {
            $ua = BEAR::$ua;
        }
        $agent_piev = & PEAR::getStaticProperty('BEAR_Emoji', 'agent_piev');
        $agent_piev = $ua;
        //Docomo/Ezweb変換
        $regex = '/&#(\d{5});/is';
        $func = array('BEAR_Emoji', 'onEmojiImage');
        $string = preg_replace_callback($regex, $func, $string);
        //Softbank変換
        if (BEAR::$ua != BEAR_Agent::UA_SOFTBANK) {
            $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
            $string = preg_replace_callback($regex, $func, $string);
        }
        $result = preg_replace_callback($regex, $func, $string);
        return $result;
    }

    /**
     * AU絵文字変換
     *
     * <pre>local img形式のAU絵文字を10進エンティティ表記に変換します。</pre>
     *
     * @return string
     */
    public function localimg2entity()
    {
        //<img localsrc="334" />
        $regex = '/(<img [^>]*localsrc\s*=\s*["\']?)([^>"\']+)(["\']?[^>]*>)/is';
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', 'onConvertLocalSrcEmoji'), $this->_string);
        return $this->_string;
    }

    /**
     * デフォルトイメージタグを指定する
     *
     * イメージタグの先頭部分を指定します。絵文字文字画像のURLの先頭部分です。
     *
     * Example 1. http://www.example.com/jp/mobile/emoji/に絵文字画像が入っている場合
     *
     * <code>
     * //App_Pageクラスなどで指定
     * BEAR_Emoji::setDefaultImgTag('<img width="12" height="12" boder="0" src="http://www.example.com/jp/mobile/emoji/');
     * </code>
     *
     * @param string $imgTag
     * @return void
     */
    public function setDefaultImgTag($imgTag)
    {
        BEAR_Emoji::$imgTag = $imgTag;
    }

    /**
     * 絵文字を除去する
     *
     * @param string $string
     * @return string
     */
    public function removeEmoji($string)
    {
        $log['before'] = $string;
        $ua = BEAR::$ua;
        switch ($ua) {
            // iモード, EZweb
            case BEAR_Agent::UA_DOCOMO :
            case BEAR_Agent::UA_AU :
                $bear_emoji = BEAR_Emoji::getInstance($string, $ua);
                /* @var $bear_emoji BEAR_Emoji */
                $dec_entity = $bear_emoji->makeDecEntity();
                $regex = '/&#(\d{5});/is';
                $string = preg_replace($regex, "", $dec_entity);
                break;
            // SBモバイル
            case BEAR_Agent::UA_SOFTBANK :
                $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
                $string = preg_replace($regex, "", $string);
                break;
            default :
                break;
        }
        $log['after'] = $string;
        //BEAR_Log::appLog('removeEmoji', $log);
        return $string;
    }

    /**
     * AU絵文字変換コールバック
     *
     * BEAR_Emoji::localimg2entity()で使用するコールバック関数です。
     *
     * @param array $matches
     * @return array
     * @access private
     */
    private function onConvertLocalSrcEmoji($matches)
    {
        static $local_table;
        if (!isset($local_table)) {
            $moji_aucnv_tbl = BEAR_Emoji_Map::ka_au_no2emoji_tbl_make();
        }
        $idx = $matches[2];
        $result = $moji_aucnv_tbl[$idx];
        return $result;
    }

    /**
     * 絵文字変換コールバック
     *
     * @param array $matches
     * @return string
     * @access private
     */
    private function onConvertEmoji($matches = false)
    {
        static $convert_map;
        //変換マップ読み込み
        if (!is_array($convert_map)) {
            $convert_map = BEAR_Emoji_Map::getEmojiConvertArray();
        }
        $to = & PEAR::getStaticProperty('BEAR_Emoji', 'to');
        //SB携帯連続絵文字分解
        //
        //最初の文字が1Bで6文字以上の文字列を連続絵文字とする
        //
        if (substr($matches[0], 0, 1) == chr((0x1b)) && (strlen($matches[0]) > 5)) {
            $stirng = $matches[0];
            $voda_emoji = array();
            for($i = 3; $i < strlen($stirng) - 1; $i++) {
                $voda_emoji[] = $stirng[$i];
            }
            $emojis = array();
            $j = 0;
            foreach($voda_emoji as $emoji) {
                $webcode_decimal_high = ord($stirng[2]);
                $webcode_decimal_low = ord($emoji);
                //1B24 (ESC開き)
                $emojis[$j] = pack("C*", 0x1b);
                $emojis[$j] .= pack("C*", 0x24);
                $emojis[$j] .= pack("C*", $webcode_decimal_high);
                $emojis[$j] .= pack("C*", $webcode_decimal_low);
                //0F (ESC閉じ)
                $emojis[$j] .= pack("C*", 0x0f);
                $j++;
            }
            //コードの数値配列を文字に
            $result = $emoji = "";
            foreach($emojis as $emoji) {
                $converted = $convert_map[$emoji][$to];
                $no_emoji = App::$debug ? "＊NOEMOJI*" : "";
                $result .= ($converted) ? $converted : $no_emoji;
            }
            return $result;
        }
        $emoji = $matches[0];
        $converted = $convert_map[$emoji][$to];
        // docomo推奨バイナリ絵文字
        if (($to == BEAR_Agent::UA_DOCOMO || $to == BEAR_Agent::UA_AU) && preg_match('/&#(\d{5});/', $converted)) {
            $dec_code = (int)preg_replace('/&#(\d{5});/', '$1', $converted);
            $len = strlen($dec_code);
            if ($len > 5) {
                $result = '';
                for($i = 0; $i < $len / 5; $i++) {
                    $result .= pack('n', substr($dec_code, $i * 5, 5));
                }
            } else {
                $result = pack('n', $dec_code);
            }
        } else {
            //            $encode =& PEAR::getStaticProperty('BEAR_Emoji', 'encode');
            $encode = mb_detect_encoding($converted);
            $converted = mb_convert_kana($converted, 'ak', $encode);
            $converted = str_replace(' ', '', $converted);
            $no_emoji = App::$debug ? "＊NOEMOJI*" : "";
            $result = ($converted) ? $converted : $no_emoji;
        }
        return $result;
    }

    /**
     * エスケープされた文字列の解除
     *
     * <pre>QuciFormバリデーションNGの場合valuesに入った文字列がエスケープされます。
     * SBの絵文字では"（ダブルクオーテーション）などを使用したものがあり、誤動作してしまいます。
     * この関数をsamrtyのoutputfilterで使用して誤表示を防ぎます。
     *　HTMLとしては誤った表記になるのでPCでの表示はうまくできませんがSB端末では正しく表示されます</pre>
     *
     * @param string $html
     * @return string
     * @static
     *
     */
    public static function unescapeSBEmoji($html)
    {
        $regex = '/\x1b\x24(.*?)\x0f/is';
        $result = preg_replace_callback($regex, array('BEAR_Emoji', 'onSBEmoji'), $html);
        return $result;
    }

    /**
     * unescapeSBEmoji用コールバック関数
     *
     * @param array $match
     * @return string
     * @access private
     */
    private static function onSBEmoji($match)
    {
        $emoji = $match[1];
        $result = pack('c*', 0x1b, 0x24) . html_entity_decode($emoji) . pack('c*', 0x0f);
        return $result;
    }

    /**
     * 絵文字を全て除去する
     *
     * QuickFormのフィルターなどに使います。
     *
     * @param string $string
     * @return string
     */
    public static function removeEmojiEntity(&$string)
    {
        // iモード絵文字消去
        // EZ絵文字消去
        // SB絵文字消去
        $regex = '/(&#(\d{5});)|(\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f)/is';
        $string = preg_replace($regex, "", $string);
    }

    /**
     * SB3GC端末UTF絵文字をWebコード絵文字に変換（コールバック用関数）
     *
     * <pre>
     * コールバック用SB 3GCWebコード変換関数
     * _BEAR_CONVERT_EMOJI_3GC_WEB_ENCODEがオンのときBEAR_Pageで$_POSTに対して使用しています
     * </pre>
     *
     * @param string $string
     */
    public static function onWebEncode(&$string)
    {
        $log['before'] = $string;
        $string = BEAR_Emoji::encodeWebCode($string);
        $log['after'] = $string;
        BEAR_Log::appLog('WebCode', $log);
        return $string . "@";
    }

    /**
     * 絵文字をエンティティに変換（コールバック用関数）
     *
     * @param string $string
     */
    public static function onEntityEmoji(&$string)
    {
        $log['before'] = $string;
        $bear_emoji = BEAR_Emoji::getInstance($string, BEAR::$ua);
        $string = $bear_emoji->makeDecEntity();
        //    if (BEAR::$ua == BEAR_Agent::UA_AU){
        //        $string = $bear_emoji->makeHexEntity();
        //    }
        $log['after'] = $string;
        BEAR_Log::appLog('Entity Emoji', $log);
        return $string;
    }
}
<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Vo
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * バリューオブジェクトクラス
 *
 * <pre>
 * リソースクラスの結果のオブジェクトクラスです。
 * ボディ情報（リソース状態）、メタ情報（リソースヘッダー）、リソースリンクの３つのプロパティを持ちます
 * </pre>
 * 
 * @category    BEAR
 * @package     BEAR_Vo
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 */
class BEAR_Vo
{

    /**
     * バリュー
     *
     * @var mixed
     */
    private $_body;

    /**
     * メタ情報
     *
     * @var array
     */
    private $_headers;

    /**
     * リンク情報
     *
     * @var array
     */
    private $_links;

    /**
     * コンストラクタ
     */
    function __construct($body, $headers = null, $links = null)
    {
        $this->_body = $body;
        $this->_headers = $headers;
        $this->_links = $links;
    }

    /**
     * @return mixed
     */
    public function getBody()
    {
        return $this->_body;
    }

    /**
     * @return array
     */
    public function getHeaders()
    {
        return $this->_headers;
    }

    /**
     * @return array
     */
    public function getLinks()
    {
        return $this->_links;
    }

    /**
     * @param mixed $_body
     */
    public function setBody($_body)
    {
        $this->_body = $_body;
    }

    /**
     * @param array $_headers
     */
    public function setHeaders($_headers)
    {
        $this->_headers = $_headers;
    }

    /**
     * @param array $_links
     */
    public function setLinks($_links)
    {
        $this->_links = $_links;
    }

    /**
     * 文字列化
     *
     * @return string
     */
    function __toString()
    {
        return serialize(array('body' => $this->_body, 'headers' => $this->_headers, 'links' => $this->_links));
    }
}
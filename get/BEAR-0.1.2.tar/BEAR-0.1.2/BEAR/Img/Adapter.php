<?php

/**
 * BEAR
 *
 * @package BEAR
 * @subpackage class
 */

/**
 * イメージアダプタークラス
 *
 * <pre>
 * GOF Factory
 * </pre>
 *
 * @package     BEAR
 * @subpackage class
 * @author      koriyama
 * @version     $Id: BEAR_Img.php 320 2008-06-22 19:41:58Z koriyama $
 * @since       2007 fall
 *
 */
abstract class BEAR_Img_Adapter
{
    /**
     * イメージリソース
     *
     * @var resource
     */
    public $image;

    /**
     * 元画像の幅
     *
     * @var integer
     */
    public $srcWidth;

    /**
     * 元画像の高さ
     *
     * @var integer
     */
    public $srcHeight;

    /**
     * 元画像の属性
     *
     * @var string
     */
    public $srcAttr;

    /**
     * 画像のタイプ
     *
     * <pre>
     * IMAGETYPE_GIF | IMAGETYPE_JPEG | IMAGETYPE_PNG
     * </pre>
     *
     * @var string
     */
    public $type;

    /**
     * デストラクタで消去するファイルリスト
     *
     * @var array
     */
    static $deleteFiles = array();

    /**
     * シングルトンオブジェクト
     *
     * @var object
     */
    private $singletone;

    /**
     * ファイルの消去
     *
     * 作業用のファイルを消去リストに追加します。
     *
     * @param string $file
     */
    public function deleteFile($file)
    {
        static $cnt = 0;
        
        BEAR_Img::$deleteFiles[$cnt] = $file;
        $cnt++;
    }

    /**
     * 画像情報の取得
     *
     * <pre>
     * getimagesizeで得られる画像情報を以下のプロパティに格納します。
     *
     * srcWidth    int
     * srcHeight   int
     * srcType     int
     * srcAttr     string
     * </pre>
     *
     * @param void
     * @return void
     */
    protected function getImageInfo()
    {
        list($width, $height, $type, $attr) = $info = getimagesize($this->file);
        $this->srcWidth = $width;
        $this->srcHeight = $height;
        $this->srcType = $type;
        $this->srcAttr = $attr;
    
    }

    /**
     * ヘッダー出力
     *
     * @param int $format
     */
    protected function header($format = false)
    {
        if ($format) {
            $mime_type = 'image/' . strtolower($format);
        } else {
            $mime_type = image_type_to_mime_type($this->srcType);
        }
        header("Content-type: " . $mime_type);
    }

    /**
     * 一時ファイル名を取得
     *
     * <pre>一時画像ファイル名を生成します。
     * $deleteオプションがtrueの場合、デストラクタでテンポラリーファイルは消去されます
     * </pre>
     *
     * @return string
     */
    public function getTmpFileName($file = false, $delete = true)
    {
        $file = ($file) ? $file : uniqid();
        // ファイル名生成
        $file_name = self::TMP_DIR . 'bear-img-' . App::$name . md5($file);
        // 削除ファイルとしてマーク
        if ($delete) {
            $this->deleteFile($file_name);
        }
        return $file_name;
    }

    /**
     * モバイル端末エージェントの画面サイズ
     *
     * <pre>
     * 判別できない場合はQVGAサイズを返します
     * </pre>
     *
     * @return array
     */
    protected function getMobileAgentDisplaySize()
    {
        $agent = & Net_UserAgent_Mobile::factory();
        $display = $agent->getDisplay();
        list($width, $hight) = $size = $display->getSize();
        if ($width == 0) {
            $size = array(240, 320);
        }
        return $size;
    }

    /**
     * モバイル端末に合わせた画像の最大リサイズ
     *
     * @param void
     */
    public function resizeMobile()
    {
        /**
         * PEAR Net/UserAgent/Mobileライブラリ読み込み
         */
        require_once ('Net/UserAgent/Mobile.php');
        
        $agent = & Net_UserAgent_Mobile::factory();
        $display = $agent->getDisplay();
        list($width, $hight) = $size = $display->getSize();
        if ($width == 0) {
            //サイズが取れないときはQVGA
            $width = 240;
            $hight = 320;
        }
        //縮小のみ
        if ($this->srcWidth > $width) {
            $this->resize($width);
        }
    }

    /**
     * ファイルの読み込み
     *
     * <pre>ローカル・リモートファイルにかかわらずファイルを読み込みます。
     * リモートファイルの場合はローカルにテンポラリーファイルが作成されその名前が返されます。
     * 作られたテンポラリーファイルはデストラクタで消去されます。キャッシュはされません。
     * </pre>
     *
     * @param string $file
     * @return string
     */
    function loadRemoteFile($file)
    {
        if (strpos($file, 'http') !== false) {
            $tmpFile = $this->getTmpFileName($file);
            if (!file_exists($tmpFile)) {
                //リモートファイルの取得
                $remoteFile = file_get_contents($file);
                if ($remoteFile === false) {
                    $this->error("loadRemoteFile file=[{$remoteFile}]");
                }
                file_put_contents($tmpFile, $remoteFile);
            }
            $file = $tmpFile;
        }
        return $file;
    }

    /**
     * エラー終了
     *
     */
    private function Error($errorFunc)
    {
        //エラーヘッダー
        header('HTTP/1.0 503 Service Temporarily Unavailable');
        $isRes = (is_resource($this->image)) ? 'true' : 'false';
        if (App::$debug) {
            $errMsg = "BEAR_Img error! func=[{$errorFunc}] is_resource=[{$isRes}] ";
            header("x-imgcairo-error: {$errMsg}");
            trigger_error($errMsg, E_USER_WARNING);
            exit();
        } else {
            exit();
        }
    }
}

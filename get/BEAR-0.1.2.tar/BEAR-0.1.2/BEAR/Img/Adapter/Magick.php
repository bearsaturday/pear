<?php
/**
 * BEAR
 *
 * @package BEAR
 * @subpackage class
 */

/**
 * イメージ抽象クラス
 */
require_once('BEAR/class/BEAR_Img.php');

/**
 * iMagickクラス
 *
 * <pre>Image MagicおよびGraphich MagickをサポートしたPECLのiMagickをサポートするクラスです
 *
 * Example 1. 画像のリサイズ表示
 *</pre>
 * <code>
 *  $bear_img = BEAR_Img::getInstance();
 *  $img = $bear_img->factory('Magick');
 *  $img->load(LOCAL_IMG_FILE);　/　/http://ではじまるリモートファイルも可
 *  $img->resize(30);
 *  $img->show
 * </code><pre>
 *
 * Example 2. 携帯エージェントの画面サイズに合わせて表示
 *
 * </pre><code>
 *   $bear_db = BEAR_DB::getInstance();
 *   $bear_db->connectDSN(DSN_SESSION);
 *   $query = "SELECT value FROM bear_session WHERE id=?";
 *   $params = array($id);
 *   $values = $bear_db->getAll($query, $params);
 * </code><pre>
 *
 * Example 3. キャッシュDBを利用
 *
 * </pre><code>
 *      //ローカルファイルの取得
 *       $bear_img = BEAR_Img::getInstance();
 *       $img = $bear_img->factory('Magick');
 *       $name = "testCacheShow";
 *       $size = 99;
 *       $cache_id = $name.$size;
 *       $has_cache = $img->hasCache($cache_id);
 *       if (!$has_cache){
 *           $img->load(REMOTE_IMG_FILE);
 * //            $img->load(LOCAL_IMG_FILE);
 *           $img->resize($size);
 * //                        $img->show();
 *       }
 *       $img->showCache($cache_id); * </code>
 *
 * ※　二重処理防止にはセッション使用が必要
 *
 *
 * @package      BEAR
 * @subpackage   class
 * @author       koriyama
 * @version      $Id: BEAR_Img_Magick.php 320 2008-06-22 19:41:58Z koriyama $
 * @see         http://www.php.net/manual/ja/ref.imagick.php
 * @since        Mon Aug 06 11:06:33 GMT+09:00 2007
 */
class BEAR_Img_Magick extends BEAR_Img_abst
{
    /**
     * アニメGIFではない
     *
     * @var bool
     */
    protected $_is_anim_gif = false;

    /**
     * アニメGIFファイル名
     *
     * @var bool
     */
    protected $_anim_gif = '';
    /**
     * コンストラクタ
     *
     */

    /**
     * コンストラクタ
     *
     */
    public function __construct()
    {
        //インストールチェック
        if(!function_exists("imagick_readimage")) {
            trigger_error('Error: You need iMagick Library', E_ERROR);
            exit();
        }
    }

    /**
     * ファイルのロード
     *
     * <pre>$fileにはローカルファイルのパスまたはリモートファイルのURLを指定します。
     * リモートファイルの読み込みにはphp.iniでallow_url_fopen =Onの設定が必要です。</pre>
     *
     * @param string $file
     */
    public function load($file)
    {
        $this->file = $file;
        if (strpos($file, 'http') !== false){
            //リモートファイルの取得
            $remote_file = file_get_contents($file);
            if (!$remote_file){
                $this->error('load', "file_get_contents file is [{$file}]");
            }
            $file = $this->getTmpFileName();
            file_put_contents($file, $remote_file);
        }
        //ファイルサイズのチェック
        $file_size = filesize($file);
        if ($file_size == 0){
            $this->Error('load', "filze size is zero.file is [{$file}]");
        }
//        print_b($file_size);
        $this->image = imagick_readimage($file) ;
        if (imagick_iserror($this->image)){
            $this->Error('load', "imagick_readimage file is [{$file}]");
        }
        $this->getImageInfo();
        //アニメGIF
        if (imagick_getlistsize($this->image) >= 2){
            $this->_is_anim_gif = true;
            $this->_anim_gif = $file;
        }
        //            print $file;exit();
    }
    /**
     * DBから画像の読み込み
     *
     * <pre>BLOBに格納したイメージをDBから読み取ります。</pre>
     *
     * @param string $dsn
     * @param string $id
     */
    public function loadDB($dsn, $key, $bear_img_select_mode=BEAR_IMG_SELECTMODE_ID)
    {
        $table_name = $this->table_name;
        $query_info = "SELECT
`bear_img`.`tag3`,
`bear_img`.`tag2`,
`bear_img`.`tag1`,
`bear_img`.`etag`,
`bear_img`.`format`,
`bear_img`.`status`,
`bear_img`.`update_time`,
`bear_img`.`insert_time`,
`bear_img`.`name`,
`bear_img`.`id`
FROM
`bear_img`
 WHERE id = ?";
        if ($bear_img_select_mode == BEAR_IMG_SELECTMODE_ID){
            $query_img = "SELECT image FROM {$table_name} WHERE id = ?";
        } else {
            $query_img = "SELECT image FROM {$table_name} WHERE etag = ?";
        }
        require_once 'DB.php';
        $db = DB::connect($dsn);
        if (!PEAR::isError($db)){
            $result_info = $db->getRow($query_info, array($key), DB_FETCHMODE_ASSOC);
            $this->_format = $result_info['format'];
            $this->_insert_time = $result_info['insert_time'];
            $this->_update_time = $result_infols['update_time'];
            $result_img = $db->getOne($query_img,array($key));
            $this->image = $result = imagick_blob2image($result_img);
            if ($this->image === false){
                $this->Error('loadDB');
            }
        }
    }

    /**
     * 画像をキャッシュDBに保存
     *
     * 画像をキャッシュDBに保存します
     *
     * @param string $cache_id　キャッシュID
     */
    protected function saveCacheDB($cache_id)
    {
        require_once('BEAR/class/BEAR_Mdb2.php');
        $mdb2 = BEAR_Mdb2::singleton($this->dsn_cache);
        $table_name = "bear_img_cache";
        $cache_id = $mdb2->quote($cache_id,   'text');
        $blob = imagick_image2blob($this->image);
        //        $this->header();print $blob;exit(); //test print
        $blob = $mdb2->quote($blob, 'blob');
        //        $query = "REPLACE INTO {$table_name} SET image={$blob}, time=now(), cache_id={$cache_id}";
        $query = "REPLACE INTO {$table_name} SET image={$blob}, time=now(), cache_id={$cache_id}, format={$this->src_type}";
        $mdb2->query($query);
    }

    /**
     * 画像をキャッシュDBから読み込み
     *
     * 画像をキャッシュDBから読み込みます
     *
     * @param string $cache_id
     * @return bool
     */
    function loadCacheDB($cache_id)
    {
        assert(is_string($cache_id));
        require_once('BEAR/class/BEAR_Mdb2.php');
        $mdb2 = BEAR_Mdb2::singleton($this->dsn_cache);
        $table_name = "bear_img_cache";
        $cache_id = $mdb2->quote($cache_id,   'text');
        $query = "SELECT image, format FROM {$table_name} WHERE cache_id={$cache_id}";
        $row = $mdb2->queryRow($query);
        if ($row){
            $this->cache_image = imagick_blob2image($row['image']);
            $this->src_type =$row['format'];
            $result = true;
        } else {
            $this->cache_image = false;
            $result = false;
        }
        if ($this->image === false){
            $this->Error('loadCacheDB');
        }
        return $result;

    }

    /**
     * キャッシュを持っているかを返す
     *
     * 画像がキャッシュを持っているかを返します。
     *
     * @param string $cache_id
     * @return bool
     */
    public function hasCache($cache_id)
    {
        assert(is_string($cache_id));
        $result = $this->loadCacheDB($cache_id);
        return $result;
    }

    /**
     * キャッシュ利用して画像を表示
     *
     * キャッシュDB画像で画像を表示します
     *
     *
     * @param string $cache_id
     */
    public function showCache($cache_id, $format=false)
    {
        assert(is_string($cache_id));
        if (is_resource($this->cache_image)){
            $this->image = $this->cache_image;
        } else {
            $this->saveCacheDB($cache_id);
        }
        $this->show($format);
    }


    /**
     * ヘッダーを出力
     *
     * <pre>イメージリソースの内容をみてHTTPヘッダーを出力します。
     * 他の画像タイプと違い画像タイプを出力する必要がありません
     * imagick_getmimetypeを使用
     * </pre>
     *
     * @param void
     * @return void
     * @access public
     *
     */
    public function header(){
        if (headers_sent($filename, $linenum)) {
            $msg =  "header is send in [$filename] , line [{$linenum}]";
            $this->Error('header', $msg);
            exit();
        }
        if ($this->_is_anim_gif){
            header("Content-type: image/gif");
        } else {
            $mime_type = imagick_getmimetype($this->image);
            if ($mime_type){
                header("X-Content-type: " . $mime_type);
                header("Content-type: " . $mime_type);
            } else {
                $this->Error('header', "image type=[{$mime_type}]");
            }
        }
    }

    /**
     * 画像のリサイズ
     *
     * <pre>画像をリサイズします。アニメーションGIFもリサイズできます。
     * リサイズ時に$filterを指定することもできます。$filterはIMAGICK_FILTER_*形式で指定します。</pre>
     *
     * @param int $width
     * @param int $height
     * @access public
     * @see http://jp2.php.net/manual/ja/ref.imagick.php
     */
    public function resize($width=240, $src_height=false, $filter=IMAGICK_FILTER_UNKNOWN) {
        //        if (!imagick_sample ($this->image, $width, $this->src_height)){
        //            $this->Error();
        //        }
        //imagick_getlistsize
        if ($this->_is_anim_gif){
            if ($this->src_width > $width){
                $this->_resizeAnim($width);
            }
        } else {
            if (!imagick_resize($this->image, $width, $this->src_height, $filter, 0)){
                print "w={$width},";
                $is_res = (is_resource($this->image) ) ? 1: 0;
                print "rsc=".$is_res;
                $this->Error('resize');
            }
        }
    }

    /**
     * アニメーションGIFのリサイズ
     *
     * <pre>アニメーションGIFをリサイズします。magic関数には用意されていない機能なのでシェルでconvertコマンドを実行しています</pre>
     *
     * @param int $width
     */
    protected function _resizeAnim($width=240) {
        //        convert animt.gif -coalesce -resize 640 -deconstruct resized.gif
        $from_file = $this->getTmpFileName();
        $this->save($from_file);
        $to_file = $this->getTmpFileName();
        $command = "convert {$from_file} -resize {$width} {$to_file}";
        system($command, $result);
        if ($result){
            trigger_error("imagemagick convert error result=[$result]", E_USER_WARNING);
        }
        $this->_anim_gif = $to_file;
    }

    /**
     * 画像表示
     *
     * 画像を表示します。
     *
     * @param void
     * @return void
     *
     */
    public function show(){
        $this->header();
        if ($this->_is_anim_gif){
            readfile($this->_anim_gif);
        } else {
            $blob = imagick_image2blob($this->image);
            echo $blob;
        }
        if ($return){
            return $blob;
        } else{
            //            exit();
        }
//        exit();
    }

    /**
     * 画像保存
     *
     * <pre>指定のパスに画像を保存します</pre>
     *
     * @param string $file_path  保存画像のファイルパス
     */
    public function save($file_path){
        $result = imagick_writeimage($this->image, $file_path);
        if (!$result){
            trigger_error("Image file write error [$file_path]");
        }
    }

    /**
     * エラー終了
     *
     * <pre>エラー終了します。運用でクローラーにキャッシュされないために503ヘッダーを出力しています</pre>
     *
     * @param string $error_func コール元のメソッド名
     * @param string $msg エラーメッセージ
     */
    private function Error($error_func, $msg=null)
    {
        //エラーヘッダー
        header ('HTTP/1.0 503 Service Temporarily Unavailable');
        $reason      = (is_resource($this->image)) ? imagick_failedreason($this->image) : "no image resource";
        $description = (is_resource($this->image)) ? imagick_faileddescription($this->image) : "no image resource";
        $is_res = (is_resource($this->image)) ? 'true' : 'false';
        if (App::$debug || 1){
            $err_msg = "imagick error! func=[{$error_func}] msg=[{$msg}] is_resource=[{$is_res}] Reason=[{$reason}] Description=[{$description}]";
            header("x-imgmagick-error: {$err_msg}");
            trigger_error($err_msg, E_USER_WARNING);
            exit() ;
        } else {
            exit() ;
        }
    }
}


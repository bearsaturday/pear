<?php
/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Smarty
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * Smartyライブラリ読み込み
 */
require_once 'BEAR/inc/Smarty/libs/Smarty.class.php';

/**
 * Smartyクラス
 *
 * <pre>
 * BEARで使うテンプレートエンジンのSmartyです。コンストラクタで初期設定をしています。<br/>
 * ページのSmartyはBEAR_Page::$smartyです。
 * </pre>
 * 
 * @category    BEAR
 * @package     BEAR_Smarty
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Smarty.php 406 2008-07-02 06:41:10Z koriyama $
 */
class BEAR_Smarty extends Smarty
{

    /**
     * outputフィルターを一度しか実行しないためのコントロール値
     * 
     * <pre>
     *   0 未実行
     *   1 実行
     *   2 実行済み
     * </pre>
     * 
     * 　@var interger
     * 
     */
    public static $doEmojiOutputFilter = 0;

    /**
     * コンストラクタ
     */
    function __construct()
    {
        //親コンストラクタ
        Smarty::Smarty();
        //フォルダパス設定
        $this->template_dir = _BEAR_APP_HOME . '/App/views/';
        $this->config_dir = _BEAR_APP_HOME . '/App/smarty/configs/';
        $this->compile_dir = _BEAR_APP_HOME . '/tmp/smarty_templates_c/';
        $this->cache_dir = _BEAR_APP_HOME . '/tmp/smarty_cache/';
        $this->plugins_dir = array('plugins', 'App/smarty/plugins/', 'BEAR/BEAR/smarty/plugins/');
        // デバックモード
        if (App::$debug) {
            // テンプレートキャッシュなし
            $this->caching = 0;
            // テンプレートキャッシュは常に再生成
            $this->force_compile = true;
        }
    }

    /**
     * 絵文字用アオウトプットフィルター
     *
     * <pre>
     * 絵文字を画像表示します。ネイティブ表示できる場合はそちらを優先します。
     * </pre>
     *
     * @param object $smarty
     * @return string
     * @static 
     */
    static function emojiOutputFilter($html, &$smarty)
    {
        if (self::$doEmojiOutputFilter != 1) {
            return $html;
        }
        self::$doEmojiOutputFilter = 2; //済み
        assert(class_exists('BEAR_Emoji'));
        $bear_agent = BEAR_Agent::getInstance();
        $is3GC = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) && $bear_agent->isType3GC();
        if (BEAR::$ua != BEAR_Agent::UA_PC && !$is3GC || (defined('_BEAR_IS_MOBILE_ROBOT') && _BEAR_IS_MOBILE_ROBOT)) {
            $html = mb_convert_encoding($html, 'SJIS-win', 'UTF-8');
        }
        // SBの場合のvalidation=""の中に入った文字のアンエスケープ
        if (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) {
            $html = BEAR_Emoji::unescapeSBEmoji($html);
        }
        // QFによりエスケープされてしまった絵文字エンティティをアンエスケープ
        // (フィルターによりバイナリにパックされる）
        $regex = '/&amp;#(\d{5});/s';
        $html = preg_replace($regex, "&#$1;", $html);
        // PC
        if (BEAR::$ua == BEAR_Agent::UA_PC){
            $html = BEAR_Emoji::ImageTag($html);
        }
        return $html;
    }
}
<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Session
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * セッションクラス
 *
 * <pre>
 * セッションを取り扱います。詳細設定は.htaccess(またはphp.ini)でも行う必要があります。
 * セッションはデフォルトのファイルセッション、webクラスターシステムのためのDBまたはmemchacheを選択します</pre>
 *
 * @category    BEAR
 * @package     BEAR_Session
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Session.php 406 2008-07-02 06:41:10Z koriyama $
 */
class BEAR_Session extends HTTP_Session2
{

	const SESSION_KEY = '_s';

	/**
	 * セッション不使用
	 */
	const ENGINE_NONE = -1;

	/**
	 * ファイルセッション（クラスター不可）
	 */
	const ENGINE_FILE = 0;

	/**
	 * DBセッション
	 */
	const ENGINE_DB = 1;

	/**
	 * memchacheセッション
	 */
	const ENGINE_MEMCACHE = 2;

	/**
	 * セッションスタート
	 *
	 * @param void
	 * @param void
	 */
	function start()
	{
		static $has_started = false;

		if (App::SESSION_ENGINE == self::ENGINE_NONE || $has_started) {
			return;
		}
		if (!$session_started) {
			self::init();
			// セッションスタート
			HTTP_Session2::start(self::SESSION_KEY);
			// セッションを通じた固定トークン
			if (HTTP_Session2::isNew()) {
				HTTP_Session2::set('stoken', substr(md5(uniqid()), 0, 4));
			}
			// 有効期限
			//            HTTP_Session2::setExpire(App::$sessionOptions['expire'], true);
			// アイドル時間
			//            HTTP_Session2::setIdle(App::$sessionOptions['idle'], true);
			BEAR_Log::appLog('Session Start', array(
                    'module' => session_module_name() . '/' . App::SESSION_ENGINE, 
                    'id' => session_id()));
		}
		$has_started = true;
	}

	/**
	 * セッションクラス初期化
	 *
	 * セッションエンジンを指定し初期化します。
	 *
	 * @param void
	 * @return void
	 * @static
	 * @ignore
	 *
	 */
	public static function init()
	{
		//セッションハンドラ初期化
		switch (App::SESSION_ENGINE) {
			case self::ENGINE_MEMCACHE :
				ini_set("session.save_handler", 'memcache');
				ini_set("session.save_path", App::$sessionOptions['path']);
				break;
			case self::ENGINE_DB :
				self::_initSessionDb();
				break;
			case self::ENGINE_FILE :
				// ファイルセッションに関するPHPのバグ対応
				// @link http://bugs.php.net/bug.php?id=25876
				ini_set('session.save_handler', 'files');
				if (App::$sessionOptions['path']) {
					ini_set("session.save_path", App::$sessionOptions['path']);
				}
				break;
			case self::ENGINE_NONE :
				break;
			default :
				// error
				PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, 0, 'error', array(
                        'engine' => App::SESSION_ENGINE), 'Invalid Session Engine.');
		}
	}

	/**
	 * セッションDB初期化
	 *
	 * @access private
	 */
	private function _initSessionDb()
	{
		HTTP_Session2::useTransSID(false);
		HTTP_Session2::useCookies(true);
		// DSN を指定します
		HTTP_Session2::setContainer('MDB2', array(
                'dsn' => App::$sessionOptions['path'], 
                'table' => 'sessiondata', 
                'autooptimize' => true));
	}

	/**
	 * セッション変数取得
	 *
	 * <pre>
	 * セッション変数を取得します。変数の無い場合に$defaultを指定することができます
	 * </pre>
	 *
	 * @param    string  $name   セッション変数名
	 * @return   mixed   セッション変数値
	 * @static
	 */
	public static function &get($name, $default = null)
	{
		self::start();
		$values = parent::get($name, $default);
		BEAR_Log::appLog('Session[R]', array('name' => $name, 'val' => $values));
		return $values;
	}

	/**
	 * セッション変数セット
	 *
	 * <pre>
	 * セッション変数をセットします。
	 * </pre>
	 *
	 * @param $name string セッションキー
	 * @param $values mixed 値
	 */
	public function set($name, $values)
	{
		self::start();
		$return = parent::set($name, $values);
		BEAR_Log::appLog('Session[W]', array('name' => $name, 'val' => $values,
                'result' => $return));
		return $result;
	}

	public function merge($name, $values)
	{
		self::start();
		$old = parent::get($name, $default);
		if (is_array($old)){
			$values = $values + $old;
		}
		$return = parent::set($name, $values);
		BEAR_Log::appLog('Session[Merge]', array('name' => $name, 'val' => $values,
                'result' => $return));
	}

	/**
	 * セッション変数消去
	 *
	 * <pre>
	 * セッション変数を消去します。
	 * </pre>
	 *
	 * @param $name string セッションキー
	 **/
	static public function unregister($name)
	{
		parent::unregister($name);
		BEAR_Log::appLog('Session[DEL]', array('name' => $name));
	}
}
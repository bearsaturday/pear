<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Content
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEAR_Contentクラス
 *
 * <pre> 
 * リソースアクセスで使用するリソースコンテントクラスです。リソースに対する4つのインターフェイスを提供します。
 * 4つのインターフェイス(create, read, update, delete)に対するメソッド(onCreate, onRead, onUpdate, onDelete)で必要なものを実装します。
 * 
 * 以下は指定したフォーマットで時間を取得できるmyTimeリソースの実装例です。
 * <code>
 * class myTime extends BEAR_Content
 * {
 *   public function onRead($values){
 *      $format = $values['format'];
 *      retruen date($format);
 *   }
 * }
 * </code>
 * ※時間は削除、変更、作成はできないので読み込みメソッドだけが実装されています。
 * 
 * returnで返す出力は2種類あります。RAWデータ（配列など）かバリューオブジェクトです。
 * データだけを返せば十分なときはRAWデータでデータにヘッダーやリンクなどの付帯情報をつけて返したい場合はバリューオブジェクト(BEAR_VOオブジェクト）で返します。
 *
 * @category    BEAR
 * @package     BEAR_Content
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 */
class BEAR_Content
{

    /**
     * 結果コード
     *
     * @var integer
     */
    public $result_code = BEAR_Resource::RESULT_CODE_200_OK;

    /**
     * リソース読み込み
     *
     * @param array $values
     * @return mixed
     */
    public function onRead($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * リソース作成
     * 
     * リソースを作成します。このメソッドはキャッシュオプションが使えます。
     *
     * @param array $values
     * @return mixed
     */
    public function onCreate($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * リソース変更
     * 
     * リソースを変更します。このメソッドはPOEオプション（一度だけ実行する）オプションが使えます。
     *
     * @param array $values
     * @return mixed
     */
    public function onUpdate($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * リソース消去
     * 
     * リソースを消去します。このメソッドはPOEオプション（一度だけ実行する）オプションが使えます。
     *
     * @param array $values
     * @return mixed
     */
    public function onDelete($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * DBリザルトをリソースリザルトに変更します
     *
     * @access protected
     * @param object $db_result
     * @return unknown
     */
    protected function dbResult($dbResult)
    {
        return PEAR::isError($dbResult) ? BEAR_Resource::RESULT_200_OK : BEAR_Resource::RESULT_500_ERROR;
    }
}
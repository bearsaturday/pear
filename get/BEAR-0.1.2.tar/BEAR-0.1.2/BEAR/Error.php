<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Error
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * エラークラス
 *
 * <pre>
 * エラーを取り扱います。エラーページ表示、エラーログ等の機能があります。
 *
 * Example 1. 重大エラー
 * 
 * <code>
 * PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('page_class' => $page_class),'Page class is not defined.（ページクラスが定義されていません)');
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Error
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version    $Id: BEAR_Error.php 417 2008-07-02 12:03:30Z koriyama $
 */
class BEAR_Error
{

    /**
     * PHPエラーパッケージ名
     *
     */
    const PACKAGE_PHP = 'PHP_Error';

    /**
     * BEARエラーパッケージ名
     *
     */
    const PACKAGE_BEAR = 'BEAR_Error';

    /**
     * ログ
     *
     * @var mixed
     * @access private
     */
    public $_log = false;

    /**
     * エラー統計
     * 
     * @var integer
     */
    public static $errorStat;

    /**
     * レポート済みエラー
     *
     * (BEAR使用)
     * 
     * @internal 
     * @ignore 
     */
    public static $_reportedError;

    /**
     * デバック用アサートハンドラー
     * 
     * <pre>
     * (BEAR使用)
     * デバック用のアサートハンドラです。
     * </pre>s
     *
     * @param string $file
     * @param integer $line
     * @param integer $code
     * @ignore 
     */
    public static function handleAssertDebug($file, $line, $code)
    {
        $array = array('File' => $file, 'Line' => $line, 'Code' => $code);
        if (BEAR_Page::isAjaxRequest()) {
            BEAR_Log::appLog(array('!Assert' => $array));
            BEAR_Log::writeHTMLLog();
            BEAR_Error::ajaxError();
        } else {
            BEAR_Log::appLog(array('!Assert' => $array));
            //トレースログ
            $log["Trace"] = debug_backtrace();
            unset($log["Trace"][0]);
            $trace = debug_backtrace();
            unset($trace[0]);
            print_a($trace, "label:Assert in {$trace[1]['file']} on line {$trace[1]['line']}");
            //            Var_Dump::displayInit(array('display_mode' => 'Table'));
        }
    }

    /**
     * ライブ用エラーハンドラー
     * 
     * <pre>
     * (BEAR使用)
     * ライブ用のエラーハンドラーです。
     * </pre>
     *
     * @param object $error
     * @return mixed
     * @ignore 
     */
    public static function handleErrorLive($error)
    {
        $appError = App::onError($error);
        if ($appError === false) {
            return $appError;
        }
    }

    /**
     * エラーハンドラー
     *
     * <pre>
     * (BEAR使用)
     * ライブ用のエラーハンドラーです。
     * </pre>
     * 
     * @param object $error
     * @return mixed
     * @ignore
     */
    public static function handleErrorDebug($error)
    {
        static $reported = array();
        
        $appError = App::onError($error);
        if ($appError === false) {
            return $appError;
        }
        //ログの内容
        //パッケージ毎の処理
        $errorStringData = array(E_ERROR => 'E_ERROR', E_WARNING => 'E_WARNING', E_PARSE => 'E_PARSE', E_NOTICE => 'E_NOTICE', E_CORE_ERROR => 'E_CORE_ERROR', E_CORE_WARNING => 'E_CORE_WARNING', E_COMPILE_ERROR => 'E_COMPILE_ERROR', E_COMPILE_WARNING => 'E_COMPILE_WARNING', E_USER_ERROR => 'E_USER_ERROR', E_USER_WARNING => 'E_USER_WARNING', E_USER_NOTICE => 'E_USER_NOTICE', E_STRICT => 'E_STRICT', E_RECOVERABLE_ERROR => 'E_RECOVERABLE_ERROR');
        $errorString = $errorStringData[$error['code']];
        switch (strtolower($error['package'])) {
            case 'php_error':
                //同じエラーは無視=ignore_repeated_errors 0と同様の処理
                $key = ("{$error['params']['file']}{$error['params']['line']}");
                if (isset($reported[$key])) {
                    $result = PEAR_ERRORSTACK_IGNORE;
                    return $result;
                } else {
                    $reported[$key] = true;
                }
                $location = "{$error['params']['file']} on Line {$error['params']['line']}";
                $trace = debug_backtrace();
                $trace = $trace[5];
                $traceClass = isset($trace['class']) ? "{$trace['class']}::" : '';
                $log['message'] = $error['message'];
                $log['location'] = $location;
                $class = (isset($trace['class'])) ? ", {$trace['class']}{$trace['type']}{$trace['function']}()" : '';
                $log['trace'] = "{$trace['file']} on Line {$trace['line']}{$class}";
                if ($log['trace'] == $log['location']) {
                    unset($log['trace']);
                }
                //レベル別処理
                switch ($error['code']) {
                    case E_ERROR :
                    case E_USER_ERROR :
                        BEAR_Error::error503();
                         $result = PEAR_ERRORSTACK_LOG;                        
                    case E_USER_WARNING :
                    case E_WARNING :
                        BEAR_Log::appLog($errorString, $log);
                        $result = PEAR_ERRORSTACK_LOG;
                        break;
                    case E_USER_NOTICE :
                    case E_NOTICE :
                        BEAR_Log::appLog($errorString, $log);
                        $result = PEAR_ERRORSTACK_IGNORE;
                        break;
                    case E_STRICT :
                    default :
                        $result = PEAR_ERRORSTACK_IGNORE;
                        break;
                }
                break;
            case 'exception' :
                BEAR_Log::appLog("Exception", $log);
                $result = PEAR_ERRORSTACK_IGNORE;
                break;
            case 'bear_error' :
                $trace = debug_backtrace();
                $class = isset($error['context']['class']) ? "{$error['context']['class']}::" : '';
                $location = "{$error['context']['file']} on Line {$error['context']['line']}, {$class}{$error['context']['function']}()";
                BEAR_Error::$errorStat |= E_ERROR;
                if (App::$debug) {
                    $info = "";
                    foreach($error['params'] as $key => $value) {
                        if (is_array($value)) {
                            $value = self::_printR($value);
                        }
                        $info[] .= "<b>$key</b>&nbsp;&nbsp;$value&nbsp;";
                    }
                    $info = implode(' , ', $info);
                    BEAR_Error::showBoxMessage('A System Error Occured.', $error['message'], $info);
                }
                $result = PEAR_ERRORSTACK_LOG;
                break;
            case 'mdb2_error' :
                BEAR_Error::$errorStat |= E_ERROR;
                if (App::$debug) {
                    BEAR_Error::showBoxMessage('A DB Error Occured.', $error['message'], $error['params']['user_info']);
                }
                $result = PEAR_ERRORSTACK_IGNORE;
                break;
            case 'pear_error' :
                BEAR_Error::$errorStat |= $error['code'];
                $log['code'] = $error['code'];
                $log['message'] = $error['message'];
                $log['location'] = $error['params']['location'];
                $log['PEAR debug info'] = $error['params']['PEAR debug info'];
                BEAR_Log::appLog("{$error['package']}", $log);
                $result = PEAR_ERRORSTACK_PUSH;
                break;
            default :
                BEAR_Log::appLog("{$error['package']}", $error);
                $result = PEAR_ERRORSTACK_PUSH;
        }
        return $result;
    }

    /**
     * ロガー
     * 
     * <pre>
     * (BEAR使用)
     * エラーのログを記録します
     * </pre>
     *
     * @param object $error
     */
    public static function logger($error)
    {
        // ログレベル
        switch ($error['code']) {
            case E_ERROR :
            case E_USER_ERROR :
            case E_CORE_ERROR :
                $level = PEAR_LOG_CRIT;
                break;
            case E_USER_WARNING :
            case E_WARNING :
            case E_COMPILE_WARNING :
                $level = PEAR_LOG_ERR;
                break;
            case E_USER_NOTICE :
            case E_NOTICE :
            case E_RECOVERABLE_ERROR :
                break;
            default :
                $level = PEAR_LOG_NOTICE;
        }
        //ログ内容
        $conf = array('mode' => 0644);
        $logger = &Log::singleton('file', _BEAR_APP_HOME . '/logs/bear.log', 'error', $conf);
        $user_agent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : "CLI";
        $class = isset($error['context']['class']) ? "{$error['context']['class']}::" : '';
        $log = "{$error['message']} in {$error['context']['file']} {$error['context']['line']} {$class}{$error['context']['function']}, agent=$user_agent";
        $logger->log($log, $level);
    }

    /**
     * 配列を文字列にする
     * 
     * <pre>
     * エラー情報などの配列で受け取った値をweb画面で表示するためにシリアライズします。
     * </pre>
     *
     * @param array $array
     * @access private 
     */
    static private function _printR($array)
    {
        $result = array();
        foreach($array as $key => $var) {
            if (is_string($key)) {
                $result[] .= "<b>{$key}<b>:{$var}&nbsp";
            } else {
                $result[] .= "{$var}";
            }
        }
        $result = implode(',&nbsp;', $result);
        return $result;
    }

    /**
     * PEARエラーハンドラー
     * 
     * PEARエラーがレイズされるとError_Stackにしてレイズしなおす
     *
     * @param object $error
     * @return void
     * @ignore 
     */
    static function handlePearError($error)
    {
        $trace = debug_backtrace();
        $trace = $trace[7];
        $location = "in {$trace['file']} on Line {$trace['line']}";
        PEAR_ErrorStack::staticPush('PEAR_Error', $error->getCode(), 'error', array('location' => $location, 'PEAR debug info' => $error->getDebugInfo()), $error->getMessage());
    }

    /**
     * PHPエラーハンドラー debugモード
     * 
     * <pre>
     * PHPエラーをPEAR_ErrorStackとしてパッケージしなおします
     * </pre>
     *
     * @param int $code
     * @param string $message
     * @param string $file
     * @param int $line
     * @return object
     * @ignore 
     */
    static function handlePhpErrorDebug($code, $message, $file, $line)
    {
        
        BEAR_Error::$errorStat |= $code;
        PEAR_ErrorStack::staticPush(self::PACKAGE_PHP, $code, 'error', array('file' => $file, 'line' => $line), $message);
    }

    /**
     * PHPエラーハンドラー liveモード
     * 
     * <pre>
     * PHPエラーをPEAR_ErrorStackとしてパッケージしなおします
     * </pre>
     *
     * @param int $code
     * @param string $message
     * @param string $file
     * @param int $line
     * @return object
     * @ignore 
     */
    static function handlePhpErrorLive($code, $message, $file, $line)
    {
        PEAR_ErrorStack::staticPush(self::PACKAGE_PHP, $code, 'error', array('file' => $file, 'line' => $line), $message);
    }

    /**
     * キャチされなかった例外ハンドラー（デバック）
     * 
     * キャッチされなかった例外の詳細を表示します。Fatalエラー扱いで例外元への復帰はされません。
     *
     * @param object $exception
     */
    static function handleExceptionDebug(Exception $e)
    {
        print 'Uncaught ' . get_class($e) . ', code: ' . $e->getCode() . ">Message: " . htmlentities($e->getMessage()) . PHP_EOL;
        print_a((array)$e, 'label:Exception detail');
    }

    /**
     * キャチされなかった例外ハンドラー（ライブ）
     * 
     * @ignore 
     */
    static function handleExceptionLive($exception)
    {}

    /**
     * エラーチェック
     * 
     * PEAR_ErrorStackエラーオブジェクトかチェックします。
     *
     * @param object $error
     * @return bool
     */
    function isError($error)
    {
        return (is_object($error) && is_a($error, 'PEAR_ErrorStack')) ? true : false;
    }

    /**
     * アサーションハンドラー
     * 
     * デバックモードのときのみ動作します
     *
     * @param string $file
     * @param int $line
     * @param string $code
     * @ignore
     */
    public static function bearAssertHandler($file, $line, $code)
    {
        $array = array('File' => $file, 'Line' => $line, 'Code' => $code);
        if (BEAR_Page::isAjaxRequest()) {
            BEAR_Log::appLog(array('!Assert' => $array));
            BEAR_Error::ajaxError();
        } else {
            print_a(array('!Assert' => $array));
            //トレースログ
            $array = array();
            $array["Trace"] = array(debug_backtrace());
            print_a($array, 'assert', false);
        }
    }

    /**
     * AJAXエラー終了
     *
     * <pre>bear.jsでのリクエストでAJAXコールをエラー終了する時に使います。
     * 開発時のみつかう機能です</pre>
     *
     * @param void
     * @return void
     * @ignore 
     *
     */
    function ajaxError()
    {
        if (BEAR_Page::isAjaxRequest()) {
            // bear.js AJAX エラー
            $page = App_Page::getInstance();
            /* @var $page BEAR_Page */
            $page->addAjaxOption('ajaxerror', 'AJAX Error');
            $page->outputAjax();
            BEAR_Main::outputHeader();
            BEAR_Main::end();
        }
    }

    /**
     * エラーハンドル初期化
     *
     * BEAR_Errorを初期化します。フレームワークのみが使用します。
     *
     * @param void
     * @return void
     * @ignore
     *
     */
    public static function init()
    {
        if (App::$debug == true) {
            error_reporting(E_ALL);
            
            // アサーションを有効
            assert_options(ASSERT_ACTIVE, 1);
            assert_options(ASSERT_WARNING, 0);
            assert_options(ASSERT_QUIET_EVAL, 1);
            assert_options(ASSERT_CALLBACK, (array('BEAR_Error', 'handleAssertDebug')));
            //PHP エラーハンドル
            set_error_handler(array('BEAR_Error', 'handlePhpErrorDebug'));
            //例外デフォルトハンドル
            set_exception_handler(array('BEAR_Error', 'handleExceptionDebug'));
            //PEAR_Errorハンドル
            PEAR::setErrorHandling(PEAR_ERROR_CALLBACK, array('BEAR_Error', 'handlePearError'));
            //PEAR_ErrorStackハンドル
            PEAR_ErrorStack::setDefaultCallback(array('BEAR_Error', 'handleErrorDebug'));
            //ロガー, PEAR::Log を用いたログ出力を設定する
            $log = Log::Factory('file', _BEAR_APP_HOME . '/logs/bear.log', 'bear');
            PEAR_ErrorStack::setDefaultLogger($log);
        } else {
            // エラーレポートはE_WARNING
            error_reporting(E_WARNING);
            // 開発環境ではアサーションを無効にする
            assert_options(ASSERT_ACTIVE, 0);
            // 運用環境エラーハンドラー
            set_error_handler(array('BEAR_Error', 'handlePhpErrorLive'));
            //例外デフォルトハンドル
            set_exception_handler(array('BEAR_Error', 'handleExceptionLive'));
            //PEAR_Errorハンドル
            PEAR::setErrorHandling(PEAR_ERROR_CALLBACK, array('BEAR_Error', 'handlePearError'));
            //PEAR_ErrorStackハンドル
            PEAR_ErrorStack::setDefaultCallback(array('BEAR_Error', 'handleErrorLive'));
            //ロガー, PEAR::Log を用いたログ出力を設定する
            $log = Log::Factory('file', _BEAR_APP_HOME . '/logs/bear.log', 'bear');
            PEAR_ErrorStack::setDefaultLogger($log);
        }
        return;
    }

    /**
     * 503エラー出力
     *
     * <pre>
     * 503エラーヘッダーを出力します。
     * エラーヘッダーを出力するとクローラーにキャッシュされません。
     * </pre>
     * <code>
     * BEAR_Error::error503();
     * </code>
     *      *
     */
    function error503()
    {
        header('HTTP/1.0 503 Service Temporarily Unavailable .');
    }

    /**
     * ボックスメッセージを表示
     * 
     * PHPエラーや404メッセージなどを特別に画面表示したいときに使います
     * <code>
     * BEAR_Error::showBoxMessage('404 Not Found', 'request can not proceeded.');
     * </code>
     * 
     * @param $heading 見出し
     * @param $message メッセージ
     * @access static
     * @ignore 
     * 
     */
    public function showBoxMessage($heading, $subheading, $message1 = "", $message2 = "")
    {
        if (App::$debug) {
            echo '<div align="left" style=" background-color: #f9f9f9; border: 1px solid #D0D0D0;margin: 14px 0 14px 0; padding: 12px 10px 12px 10px; display:block;">';
            echo '<div style="font-size: 16px; color: #ff0000;margin: 10px 0 10px 0;">' . $heading . '</div>';
            echo '<div style="font-size: 14px; color: #000000;margin: 10px 0 10px 0;";">' . $subheading . '</div>';
            if ($message1) {
                echo '<div style="font-size: 12px; color: #201010;margin: 10px 0 10px 0;";">' . $message1 . '</div>';
            }
            if ($message2) {
                echo '<div style="font-size: 12px; color: #201010;margin: 10px 0 10px 0;";">' . $message2 . '</div>';
            }
            echo '</div>';
        }
    }

    /**
     * エラーハンドラ関数（運用環境）
     *
     * @param int $errno
     * @param string $errstr
     * @param string $errfile
     * @param string $errline
     * @return void
     * @ignore 
     */
    function errorHandleLive($errno, $errstr, $errfile, $errline)
    {
        switch ($errno) {
            case E_ERROR :
            case E_CORE_ERROR :
            case E_USER_ERROR :
            case E_PARSE :
            case E_COMPILE_ERROR :
                //503 error
                BEAR_Error::error503();
                exit();
                break;
            case E_WARNING :
            case E_CORE_WARNING :
            case E_USER_WARNING :
                //503 error
                break;
            case E_NOTICE :
            case E_USER_NOTICE :
            default :
                break;
        }
    }
}
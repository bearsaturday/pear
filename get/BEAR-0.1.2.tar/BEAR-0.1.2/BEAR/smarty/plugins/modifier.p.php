<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Smarty
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * Smarty printa modifier
 *
 * <pre>
 * デバック用表示（print_a）します
 *
 * Example
 * </pre>
 * 
 * <code>
 * {$body|printa}
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Smarty
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 * @param string $string
 * @return $string
 */
function smarty_modifier_p($string)
{
    $string = print_a($string, "return:true");
    return $string;
}
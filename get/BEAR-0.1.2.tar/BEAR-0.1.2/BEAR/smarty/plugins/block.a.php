<?php

/**
 * App Smarty plugin
 * @package App
 * @subpackage smarty
 */

/**
 * 拡張aタグ
 *
 * <pre>
 * 拡張した属性のaタグを提供します。
 * 
 * click string onClickイベント
 * value mixed スカラー値、配列、オブジェクト（プロパティのみ）
 *
 * Example.1 配列やオブジェクトを渡す
 * 
 * {a href="/" val=$values}
 * 
 * Example.2 ページのonClickハンドラをコール。自分に向けるときはhrefを省略できます
 * 
 * {a click=print}
 * 
 * Example.3 標準aタグと共存できます
 * 
 * {a click="print" val=$values class="href"}
 * 
 * Type:     block function<br>
 * Name:     sample<br>
 *
 * @author      koriyama
 * @version     $Id:$
 * 
 * @param array
 *  + val: mixed 変数（スカラー値、配列、オブジェクト） 
 *  + click: string クリックイベント
 * @param string $params
 * @param string $content
 * @param object $smarty object
 * @return string
 */
function smarty_block_a($params, $content, &$smarty)
{
    if (!$content) {
        return;
    }
    $query = null;
    $values = null;
    //active link
    if (isset($params['click'])) {
        $query[BEAR_Page::ACTIVE_LINK_KEY] = $params['click'];
        unset($params['click']);
    }
    // hrefが省略されたときは$_SERVER['REQUEST_URI'];
    $params['href'] = (isset($params['href'])) ? $params['href'] : $_SERVER['REQUEST_URI'];
    // value
    if (is_array($query) && $params[BEAR_Page::VALUES_KEY]) {
        $params[BEAR_Page::VALUES_KEY] += $query;
    } else {
        $params[BEAR_Page::VALUES_KEY] = $query;
    }
    $params['href'] = $params['href'] . '?' . http_build_query($params[BEAR_Page::VALUES_KEY]);
    unset($params[BEAR_Page::VALUES_KEY]);
    foreach($params as $key => $value) {
        $result .= ' ' . $key . '=' . $value;
    }
    $result = "<a{$result}>{$content}</a>";
    return $result;
}

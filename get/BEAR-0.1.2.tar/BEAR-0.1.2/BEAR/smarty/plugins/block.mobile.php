<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Smarty
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */


/**
 * Smarty mobile block plugin
 *
 * 携帯エージェントによって表示/非表示を制御します。キャリアの指定は大文字でも小文字でも可。
 *
 * Type:     block function<br>
 * Name:     mobile<br>
 * @param array
 * + in: string カンマ区切りで含まれていたら表示。
 * + out: string カンマ区切りで含まれていなかったら表示
 * + func: mobile string ユーザー関数
 * -----------------------------------------
 *
 * Example
 *
 * <code>
 * {mobile in='i,e'}ドコモとＡＵだけ表示{/mobile}<br>
 * {mobile out='s'}SBのみ非表示{/mobile}<br>
 * {mobile in='i' func='upper_case'}ドコモのみ大文字で{/mobile}<br>
 * </code>
 *
 * @author      $Author :$
 * @version     $Id: block.mobile.php 193 2008-09-04 12:36:17Z koriyama $
 * @param array $params
 * @param string $content
 * @param object $smarty
 * @return string
 */
function smarty_block_mobile($params, $content, &$smarty, &$repeat)
{
	$ua = strtolower(BEAR::$ua);
	//開始タグ
	if(is_null($content)){
		$valid = false;

		if(array_key_exists('in', $params)){
			$in = explode(',', $params['in']);
			if(in_array($ua, $in)){
				$valid = true;
			}
		}
		if(!$valid){
			if(array_key_exists('out', $params)){
				$out = explode(',', $params['out']);
				if(!in_array($ua, $out)){
					$valid = true;
				}
			}
		}

		if(!$valid){
			$repeat = false;
		}
	}else{
		if(array_key_exists('func', $params)){
			assert( function_exists($params['func']) );
			return call_user_func($params['func'], $content);
		}
		else{
			return $content;
		}
	}
	return '';
}
?>
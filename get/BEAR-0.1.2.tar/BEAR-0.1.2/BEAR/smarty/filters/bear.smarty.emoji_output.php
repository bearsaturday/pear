<?php

/**
 * BEAR
 * 
 * @category    BEAR
 * @package     BEAR_Smarty
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * 絵文字用アオウトプットフィルター
 *
 * <pre>絵文字を画像表示します。ネイティブ表示できる場合はそちらを優先します</pre>
 *
 * @category    BEAR
 * @package     BEAR_Smarty
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: bear.smarty.emoji_output.php 398 2008-06-30 07:33:09Z koriyama $
 * @param string $html
 * @param object $smarty
 * @return string
 */
function bear_smarty_emoji_output($html, &$smarty)
{
    assert(class_exists('BEAR_Emoji'));
    $bear_agent = BEAR_Agent::getInstance();
    $is3GC = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) && $bear_agent->agent->isType3GC();
    if (BEAR::$ua != BEAR_Agent::UA_PC && !$is3GC || BEAR_Agent::$isBot) {
        $html = mb_convert_encoding($html, 'SJIS-win', 'UTF-8');
    }
    // SBの場合のvalidation=""の中に入った文字のアンエスケープ
    if (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) {
        $html = BEAR_Emoji::unescapeSBEmoji($html);
    }
    // QFによりエスケープされてしまった絵文字エンティティをアンエスケープ
    // (フィルターによりバイナリにパックされる）
    $regex = '/&amp;#(\d{5});/s';
    $html = preg_replace($regex, "&#$1;", $html);
    $html = BEAR_Emoji::ImageTag($html);
    return $html;
}
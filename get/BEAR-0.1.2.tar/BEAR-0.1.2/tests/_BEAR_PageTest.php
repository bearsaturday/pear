<?php

//include_once 'BEAR/BEAR.php';
require_once 'BEAR/BEAR/Page.php';
require_once 'BEAR/BEAR/Smarty.php';
require_once 'App.php';
require_once 'PHPUnit/Framework/TestCase.php';

class Sample_Test_Page extends BEAR_Page
{

    function __construct()
    {
        parent::__construct();
    }
}

/**
 * BEAR_Page test case.
 */
class BEAR_PageTest extends PHPUnit_Framework_TestCase
{

    /**
     * @var BEAR_Page
     */
    private $BEAR_Page;

    /**
     * Prepares the environment before running a test.
     */
    protected function setUp()
    {
        parent::setUp();
        
        // TODO Auto-generated BEAR_PageTest::setUp()
        

        $this->BEAR_Page = new Sample_Test_Page(/* parameters */);
    
    }

    /**
     * Cleans up the environment after running a test.
     */
    protected function tearDown()
    {
        // TODO Auto-generated BEAR_PageTest::tearDown()
        

        $this->BEAR_Page = null;
        
        parent::tearDown();
    }

    /**
     * Constructs the test case.
     */
    public function __construct()
    {// TODO Auto-generated constructor
}

    /**
     * Tests BEAR_Page->__construct()
     */
    public function test__construct()
    {
        // TODO Auto-generated BEAR_PageTest->test__construct()
        $this->markTestIncomplete("__construct test not implemented");
        
        $this->BEAR_Page->__construct(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->header()
     */
    public function testHeader()
    {
        // TODO Auto-generated BEAR_PageTest->testHeader()
        $this->markTestIncomplete("header test not implemented");
        
        $this->BEAR_Page->header(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onAction()
     */
    public function testOnAction()
    {
        // TODO Auto-generated BEAR_PageTest->testOnAction()
        $this->markTestIncomplete("onAction test not implemented");
        
        $this->BEAR_Page->onAction(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onAjax()
     */
    public function testOnAjax()
    {
        // TODO Auto-generated BEAR_PageTest->testOnAjax()
        $this->markTestIncomplete("onAjax test not implemented");
        
        $this->BEAR_Page->onAjax(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onApp()
     */
    public function testOnApp()
    {
        // TODO Auto-generated BEAR_PageTest->testOnApp()
        $this->markTestIncomplete("onApp test not implemented");
        
        $this->BEAR_Page->onApp(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onCache()
     */
    public function testOnCache()
    {
        // TODO Auto-generated BEAR_PageTest->testOnCache()
        $this->markTestIncomplete("onCache test not implemented");
        
        $this->BEAR_Page->onCache(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onGarbageCollect()
     */
    public function testOnGarbageCollect()
    {
        // TODO Auto-generated BEAR_PageTest->testOnGarbageCollect()
        $this->markTestIncomplete("onGarbageCollect test not implemented");
        
        $this->BEAR_Page->onGarbageCollect(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onGet()
     */
    public function testOnGet()
    {
        // TODO Auto-generated BEAR_PageTest->testOnGet()
        $this->markTestIncomplete("onGet test not implemented");
        
        $this->BEAR_Page->onGet(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onInit()
     */
    public function testOnInit()
    {
        // TODO Auto-generated BEAR_PageTest->testOnInit()
        $this->markTestIncomplete("onInit test not implemented");
        
        $this->BEAR_Page->onInit(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onOutput()
     */
    public function testOnOutput()
    {
        // TODO Auto-generated BEAR_PageTest->testOnOutput()
        $this->markTestIncomplete("onOutput test not implemented");
        
        $this->BEAR_Page->onOutput(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onPost()
     */
    public function testOnPost()
    {
        // TODO Auto-generated BEAR_PageTest->testOnPost()
        $this->markTestIncomplete("onPost test not implemented");
        
        $this->BEAR_Page->onPost(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->onTimer()
     */
    public function testOnTimer()
    {
        // TODO Auto-generated BEAR_PageTest->testOnTimer()
        $this->markTestIncomplete("onTimer test not implemented");
        
        $this->BEAR_Page->onTimer(/* parameters */);
    
    }

    /**
     * Tests BEAR_Page->getTemplate()
     */
    public function testGetTemplate()
    {
        $base = _BEAR_APP_HOME .'/App/views/pages/';
        $result = $this->BEAR_Page->getTemplate('/index.tpl');
        print "result=$result]";
        $this->assertTrue($result == $base . '/index');
        $result = $this->BEAR_Page->getTemplate('/some/index.tpl');
        $this->assertTrue($result == $base . '/some/index');
        $result = $this->BEAR_Page->getTemplate();
        // Sample_Test_Page
        $this->assertTrue($result == $base . 'sample/test/page');
        $result = $this->BEAR_Page->getTemplate('help.tpl');
        $this->assertTrue($result == $base . 'sample/test/help');
        $result = $this->BEAR_Page->getTemplate('some/action.tpl');
        $this->assertTrue($result == $base . 'sample/test/some/action');
        //        $condition = ($tplName == _BEAR_APP_HOME . '/App/views/pages/index.tpl');
    //        $this->assertTrue($condition);
    
    }

    public function testGetTemplateMobile()
    {
        BEAR::$ua = BEAR_Agent::UA_PC;
        $result = $this->BEAR_Page->getTemplate('index.tpl');
        print "result=$result]";
        BEAR::$ua = BEAR_Agent::UA_DOCOMO;
        $result = $this->BEAR_Page->getTemplate('index.tpl');
        print "result=$result]";
    }
}


<?php
require_once 'PHPUnit/Framework.php';
require_once 'BEAR/BEAR.php';
require_once 'Config.php';
require_once 'Config/Container/XML.php';
require_once 'Config/Container/PHPConstants.php';

/**
 * BEAR test case.
 */
class BEARTest extends PHPUnit_Framework_TestCase
{

    /**
     * @var BEAR
     */
    private $BEAR;

    /**
     * Prepares the environment before running a test.
     */
    protected function setUp()
    {
        parent::setUp();
        
        // TODO Auto-generated BEARTest::setUp()
        

        $this->BEAR = new BEAR(/* parameters */);
    
    }

    /**
     * Cleans up the environment after running a test.
     */
    protected function tearDown()
    {
        // TODO Auto-generated BEARTest::tearDown()
        

        $this->BEAR = null;
        
        parent::tearDown();
    }

    /**
     * Constructs the test case.
     */
    public function __construct()
    {// TODO Auto-generated constructor
}

    /**
     * Tests BEAR->__toString()
     */
    public function test__toString()
    {
        // TODO Auto-generated BEARTest->test__toString()
        $this->markTestIncomplete("__toString test not implemented");
        
        $this->BEAR->__toString(/* parameters */);
    
    }

    /**
     * Tests BEAR::autoload()
     */
    public function testAutoload()
    {
        $img = BEAR_Page::SUPPORT_IMG;
        $this->assertTrue($img == 1);
        
    //        BEAR::autoload(/* parameters */);
    

    }

    /**
     * Tests BEAR::autoload()
     */
    public function testAutoload2()
    {
//        $this->assertTrue(class_exists('BEAR_Page'));
        $this->assertTrue(class_exists('BEAR_Cache_Adapter_None'));
    }

    /**
     * Tests BEAR::init()
     */
    public function testInit()
    {
        // TODO Auto-generated BEARTest::testInit()
        $this->markTestIncomplete("init test not implemented");
        
        BEAR::init(/* parameters */);
    
    }

    /**
     * Tests BEAR::loadValues()
     */
    public function testLoadValues()
    {
        $values = BEAR::loadValues(realpath(__FILE__ . '/../files/example.ini'));
        $this->assertTrue($values['first_section']['animal'] == 'BIRD');
    
    }

    /**
     * Tests BEAR::loadValues()
     */
    public function testLoadValuesPHP()
    {
        $values = BEAR::loadValues(realpath(__FILE__ . '/../files/example.php'));
        $this->assertTrue($values['CAR'] == 'ROADERSTER');
    }

    /**
     * Tests BEAR::loadValues()
     */
    public function testLoadValuesXML()
    {
        $values = BEAR::loadValues(realpath(__FILE__ . '/../files/example.xml'));
        $this->assertTrue($values['conf']['firstname'] == 'John');
    }

    /**
     * Tests BEAR::loadValues()
     */
    public function testLoadValuesURL()
    {
        $values = BEAR::loadValues('http:://www.example.com/index.html?id=bear&pass=1234');
        $this->assertTrue($values['id'] == 'bear' && ($values['pass'] == 1234));
    }

    /**
     * Tests BEAR::registerShutdownFunction()
     */
    public function testRegisterShutdownFunction()
    {
        // TODO Auto-generated BEARTest::testRegisterShutdownFunction()
        $this->markTestIncomplete("registerShutdownFunction test not implemented");
        
        BEAR::registerShutdownFunction(/* parameters */);
    
    }

    /**
     * Tests BEAR->setDebugFunction()
     */
    public function testSetDebugFunction()
    {
        // TODO Auto-generated BEARTest->testSetDebugFunction()
        $this->markTestIncomplete("setDebugFunction test not implemented");
        
        $this->BEAR->setDebugFunction(/* parameters */);
    
    }

}


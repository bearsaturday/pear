<?php
/**
 * BEAR_Session
 * 
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Session
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Session.php 430 2009-01-14 10:37:04Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Session/BEAR_Session.html
 */

/**
 * セッションクラス
 *
 * <pre>
 * セッションを取り扱います。
 * PEAR::HTTP_Session2を利用していて、デフォルトのファイルセッション、
 * webクラスターシステムのためのDBまたはmemchacheが選択できます。
 * また詳細設定は　htdocs/.htaccess(またはphp.ini)でも行う必要があります。
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Session
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Session.php 430 2009-01-14 10:37:04Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Session/BEAR_Session.html
 */
class BEAR_Session extends HTTP_Session2
{

    const SESSION_KEY = '_s';

    /**
     * セッション不使用
     */
    const ENGINE_NONE = 0;

    /**
     * ファイルセッション（クラスター不可）
     */
    const ENGINE_FILE = 1;

    /**
     * DBセッション
     */
    const ENGINE_DB = 2;

    /**
     * memchacheセッション
     */
    const ENGINE_MEMCACHE = 3;

    /**
     * セッションスタート
     *
     * @return bool
     */
    public function start()
    {
        static $hasStarted = false;
        
        if (App::$config['session']['engine'] == self::ENGINE_NONE || $hasStarted) {
            return;
        }
        if (!$hasStarted) {
            self::init();
            // セッションスタート
            HTTP_Session2::start(self::SESSION_KEY);
            // セッションを通じた固定トークン
            if (HTTP_Session2::isNew()) {
                HTTP_Session2::set('stoken', substr(md5(uniqid()), 0, 4));
            }
            // 有効期限
            //  HTTP_Session2::setExpire(App::$config['session']['expire'], true);
            // アイドル時間
            // HTTP_Session2::setIdle(App::$config['session']['idle'], true);
            $log           = array();
            $log['id']     = session_id();
            $log['module'] = session_module_name() . '/' . App::$config['session']['engine'];
            BEAR_Log::appLog('Session Start', $log);
        }
        $hasStarted = true;
    }

    /**
     * セッションクラス初期化
     *
     * セッションエンジンを指定し初期化します。
     *
     * @return void
     * @static
     * @ignore
     */
    public static function init()
    {
        //セッションハンドラ初期化
        switch (App::$config['session']['engine']) {
        case self::ENGINE_MEMCACHE :
            ini_set("session.save_handler", 'memcache');
            ini_set("session.save_path", App::$config['session']['path']);
            break;
        case self::ENGINE_DB :
            self::_initSessionDb();
            break;
        case self::ENGINE_FILE :
            // ファイルセッションに関するPHPのバグ対応
            // @link http://bugs.php.net/bug.php?id=25876
            ini_set('session.save_handler', 'files');
            if (isset(App::$config['session']['path'])) {
                ini_set("session.save_path", App::$config['session']['path']);
            } else {
                ini_set("session.save_path",  _BEAR_APP_HOME . '/tmp/session');
            }
            break;
        case self::ENGINE_NONE :
            break;
        default :
            // error
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, 0, 'error', array(
                    'engine' => App::$config['session']['engine']), 'Invalid Session Engine.');
        }
    }

    /**
     * セッションDB初期化
     *
     * @return void
     */
    private function _initSessionDb()
    {
        HTTP_Session2::useTransSID(false);
        HTTP_Session2::useCookies(true);
        // DSN を指定します
        HTTP_Session2::setContainer('MDB2', array(
                'dsn' => App::$config['session']['path'], 
                'table' => 'sessiondata', 
                'autooptimize' => true));
    }

    /**
     * セッション変数取得
     *
     * <pre>
     * セッション変数を取得します。変数の無い場合に$defaultを指定することができます
     * </pre>
     *
     * @param string $key     セッション変数名
     * @param string $default デフォルト
     * 
     * @return   mixed   セッション変数
     * @static
     */
    public static function &get($key, $default = null)
    {
        self::start();
        $values = parent::get($key, $default);
        BEAR_Log::appLog('Session[R]', array('name' => $key, 'val' => $values));
        return $values;
    }

    /**
     * セッション変数セット
     *
     * <pre>
     * セッション変数をセットします。
     * </pre>
     *
     * @param string $key    セッションキー
     * @param mixed  $values 値
     * 
     * @return mm
     */
    public function set($key, $values)
    {
        self::start();
        $return = parent::set($key, $values);
        $log    = array('name' => $key, 'val' => $values, 'return' => $return);
        BEAR_Log::appLog('Session[W]', $log);
    }

    /**
     * セッション変数マージ
     * 
     * 既存の値とマージしてセッション保存します。
     * 
     * @param string $key    キー
     * @param mixed  $values 値
     * 
     * @return void
     */
    public function merge($key, $values)
    {
        self::start();
        $old = parent::get($key);
        if (is_array($old)) {
            $values = $values + $old;
        }
        $return = parent::set($key, $values);
        $log    = array('name' => $key, 'val' => $values, 'result' => $return);
        BEAR_Log::appLog('Session[Merge]', $log);
    }

    /**
     * セッション変数消去
     *
     * <pre>
     * セッション変数を消去します。
     * </pre>
     *
     * @param string $key セッションキー
     * 
     * @return void
     */
    static public function unregister($key)
    {
        parent::unregister($key);
        BEAR_Log::appLog('Session[DEL]', array('name' => $key));
    }
}
<?php
/**
 * BEAR
 * 
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Cache
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Cache.php 470 2009-02-18 10:11:46Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Cache/BEAR_Cache.html
 */

/**
 * BEAR_Cache
 *
 * <pre>
 * 指定したキャッシュエンジンでキャッシュを扱うクラスです。
 * 
 * </pre>
 *  * Example 1. キャッシュ保存
 * </pre>
 * <code>
 *   $cache = BEAR_Cache::facotry(BEAR_Cache::ENGINE_MEMCACHE);
 *   $cache->set('topRanking', $ranking);
 * </code>
 *
 * Example 2 キャッシュ取得
 *
 * <code>
 *   $cache = BEAR_Cache::facotry(BEAR_Cache::ENGINE_MEMCACHE);
 *   $cache->get('topRanking');
 * </code>
 *
 * Example 3 キャッシュ削除
 *
 * <code>
 *   $cache = BEAR_Cache::facotry(BEAR_Cache::ENGINE_MEMCACHE);
 *   $cache->delete('topRanking');
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Cache
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Cache.php 470 2009-02-18 10:11:46Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Cache/BEAR_Cache.html
 * @see       PECL::Memcache, PEAR::Cache_Lite
 */
class BEAR_Cache extends BEAR_Base
{

    const CONFIG_ENGINE = 'engine';

    /**
     * キャッシュなし
     */
    const ENGINE_NONE = 0;

    /**
     * memcahced
     */
    const ENGINE_MEMCACHE = 1;

    /**
     * Cache_Lite
     */
    const ENGINE_LITE = 2;

    /**
     * Cache_Lite
     */
    const ENGINE_APC = 3;

    /**
     * キャッシュライフタイム無期限
     *
     */
    const LIFE_UNLIMITED = null;

    /**
     * キャッシュライフタイムなし
     *
     */
    const LIFE_NONE = 0;

    /**
     * キャッシュライフタイムアプリ共通
     *
     * @var int sec
     */
    public $defaultLife = 10;

    /**
     * シングルトンインスタンス
     *
     * @var BEAR_Memcache
     */
    private static $_instance;

    /**
     * コンストラクタ
     * 
     * @param array $config 設定
     * 
     * @return void
     * 
     */
    function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * キャッシュエンジンファクトリー
     *
     * <pre>
     * 指定のキャッシュエンジンでキャッシュオブジェクトを返します
     * 
     * $options
     * 
     * engine string キャッシュエンジン
     * </pre>
     * 
     * @param array $options キャッシュオプション
     * 
     * @return BEAR_Cache_Adapter
     */
    public static function factory(array $config = array())
    {
        $adapter = isset($config['engine']) ? $config['engine'] : App::$config['cache']['engine'];
        switch ($adapter) {
        case self::ENGINE_MEMCACHE :
            self::$_instance = new BEAR_Cache_Adapter_Memcache();
            break;
        case self::ENGINE_LITE :
            self::$_instance = new BEAR_Cache_Adapter_Lite();
            break;
        case self::ENGINE_APC :
            self::$_instance = new BEAR_Cache_Adapter_Apc();
            break;
        default :
            self::$_instance = new BEAR_Cache_Adapter_None();
        }
        return self::$_instance;
    }

    /**
     * インスタンス消去
     * 
     * @return void
     */
    public static function destoryInstance()
    {
        self::$_instance = null;
    }
}
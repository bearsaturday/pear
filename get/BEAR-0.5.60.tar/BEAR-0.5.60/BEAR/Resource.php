<?php
/**
 * BEAR_Resource
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Resource.php 537 2009-03-10 06:50:01Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * BEAR_Resourceクラス
 *
 * <pre>
 * リソース操作を取り扱うクラスです。
 * リソースの作成、取得、編集、削除などをリソースコンテントに
 * 対するインターフェイスを持ちます。
 *
 * BEAR_Resourceは内部リソース（DB、ファイル等）と外部リソース
 * （RSS, API通信、デーモン等)をスクリプトから区別せずに使用でき、
 * ステートレスで統一されたインターフェイスを持ちます。リソースはURIと
 * 同様のリソーソパス形式で表す事ができ他のリソーソパスのリンクを
 * 持つ事もできます。
 *
 * 操作の動作をオプションで指定します。キャッシュ、ページング処理、
 * コールバック関数によるポストプロセス、作成時の二重動作禁止のための
 * トークン処理などの機能があります。リソースファイル（リソースをアクセス
 * するファイル）は単純関数とクラス形式の２つがあります。
 * PROJECT_ROOT/App/resource以下にフォルダの階層も持って配置されます。
 *
 * Example 1. ユーザーのブログリソース取得
 *
 * リソース名
 * user/blog
 *
 * 関数型リソースファイル
 * App/resource/user/createBlog.php
 * App/resource/user/readBlog.php
 * ...
 *　
 * クラス型リソースファイル
 * App/resource/user/blog.php
 *
 * <code>
 * // 関数型
 * function readBlog($values)
 * {
 *   $db = App_DB::getInstance();
 *   $db->quote($values['id'], 'integer);
 *   $sql  = "SELECT * FROM blog WHERE id={$values{'id'} ORDER BY id DESC LIMIT 5";
 *   $result = $db->queryAll($sql);
 *   return $result;
 * }
 * </code>
 *
 * <code>
 * //クラス型
 * class Blog extends BEAR_Content
 * {
 *   public function onCreate($values){}
 *   public function onRead($values){
 *     // ...
 *     $result = $db->queryAll($sql);
 *     return $result;
 *   }
 *   public function onUpdate($values){}
 *   public function onDelete($values){}
 * }
 * </code>
 *
 * <pre>
 * Example. 取得したデータが配列でなければエラーで返す
 * </pre>
 * <code>
 * function readBlog($values){
 *   //エラー
 *   $result = (is_array($result)) ? $result : PEAR::raiseError('error message');
 *   return $result;
 * }
 * </code>
 *
 * <pre>
 * ページからのリソース読み出し
 * /usr/blog.php
 * </pre>
 *
 * <code>
 * $resoure = new BEAR_Resource('/usr/blog');
 * $values['key'] = 'hoge_id';
 * $blog = $resoruce->read($values);
 * </code>
 *
 * <pre>
 * Example. キャッシュの使用<br>
 *
 * </pre>
 * <code>
 * $options['cache']['key'] = 'cacheid_foo'; //省略できます
 * $options['cache']['life'] = 30;
 * $blog = $resoruce->read($values, $options);
 * </code>
 *
 * <pre>
 * Example. 二重実行防止にはPOE(Post Once Exactly)オプションを指定します
 *
 * <code>
 * //二重送信されたものを一度しか実行しない
 * $resoure = new BEAR_Resource('/usr/blog');
 * $options['poe'] = true;
 * $resource->create($values, $options);
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Resource.php 537 2009-03-10 06:50:01Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */
class BEAR_Resource
{

    /**
     * リソースメソッド - create(POST, INSERT)
     */
    const METHOD_CREATE = 'create';

    /**
     * リソースメソッド - read(GET, SELECT)
     */
    const METHOD_READ = 'read';

    /**
     * リソースメソッド - update(PUT, UPDATE)
     */
    const METHOD_UPDATE = 'update';

    /**
     * リソースメソッド - delete(DELETE, DELETE)
     */
    const METHOD_DELETE = 'delete';

    /**
     * リソースオプション ページャー
     */
    const OPTION_PAGER = 'pager';

    /**
     *　リソースキャッシュ　キャッシュキー
     */
    const OPTION_CACHE_KEY = 'key';

    /**
     * リソースオプションキー　キャッシュ時間
     */
    const OPTION_CACHE_LIFE = 'life';

    /**
     * リソースオプションキー スタティックリソースキー
     *
     */
    const OPTION_RESOURCE_FILE_EXTENTION = 'extention';

    /**
     * オプション　POE (Post Once Exactly)
     */
    const OPTION_POE = 'poe';

    /**
     * オプション　トークン無視
     */
    const OPTION_IGNORE_TOKEN = 'ignore_token';

    /**
     * リンクキー pager
     *
     */
    const LINK_PAGER = 'pager';

    /**
     * アクセスメソッド
     *
     * @var string
     */
    public static $isReadMethod = false;

    /**
     * URI(リソースパス)
     *
     * @var string
     */
    private $_uri;

    /**
     * 引数
     *
     * @var array
     */
    private $_values = array();

    /**
     * オプション
     *
     * @var array
     */
    private $_options = array();

    /**
     * アクセスメソッド
     *
     * @var string
     */
    private $_method;

    /**
     * コード
     *
     * @var int
     */
    private $_code;

    /**
     * 結果ヘッダー
     *
     * @var array
     */
    private $_headers = array();

    /**
     * 結果
     *
     * @var mixed
     */
    private $_body;

    /**
     * 結果リンク
     *
     * @var array
     */
    private $_links;

    /**
     * バリューオブジェクト
     *
     * @var BEAR_Vo
     */
    private $_vo;

    /**
     * ファイルタイプ
     *
     * @var int
     */
    private $_resourceFileType;

    /**
     * トークン
     *
     * @var string
     * @access private
     */
    private $_token;

    /**
     * URIセット
     *
     * <pre>
     * URIに?name=val形式のクエリーがついてるとURIと引数に分離します。
     * リソースリクエストのときに指定された引数が上書きされてリソースリクエストされます。
     * </pre>
     *
     * @param string $uri URI
     *
     * @return void
     */
    private function _setUri($uri)
    {
        if (!is_string($uri)) {
            return;
        }
        $parse = parse_url($uri);
        $query  = isset($parse['query']) ? $parse['query'] : '';
        $values = array();
        parse_str($query, $values);
        if ((bool)$values === false) {
            $this->_uri = $uri;
        } else {
            // ?の前を_uriにock
            $this->_uri =$parse['path'];
            // 後ろは配列にして_valuesに
            $this->_values = $values;
        }
    }

    /**
     * URIをセット
     *
     * オブジェクトのプロパティを初期化して新しいURIにアクセスする準備をします。
     *
     * @param string $uri URI
     *
     * @retrun void
     */
    //    public function setUri($uri)
    //    {
    //        BEAR_Resource::$isReadMethod = false;
    //        $this->_headers = $this->_values = $this->_options = array();
    //        $this->_body = $this->_links = $this->_vo = null;
    //        $this->__construct($uri);
    //    }

    /**
     * ページャー情報の取得
     *
     * <pre>ページャーで生成されたナビゲーションHTMLを取得します。
     * DBページャーの場合はページャー情報も取得されます
     * ['links']にナビゲーションリンクが
     * ['info']のページャー情報がはいります
     *
     * DBページャーの場合は結果がバリューオブジェクトになっているので、
     * リンクとメタ情報からページャー情報を生成しています</pre>
     *
     * @return array
     */
    public function getPager()
    {
        $result = array('links' => $this->_links['pager'], 'info' => $this->_headers);
        return $result;
    }

    /**
     * AJAX用ページャーリンクを取得
     *
     * <pre>paging()等で作成されたページャーのリンクをbear.jsを使った
     * AJAXのページャーリンクにします。
     *
     * @param string $links リンク
     *
     * @return string
     * @ignore
     */
    public function getAjaxPagerLinks($links)
    {
        $array = array();
        foreach ($links as $key => $value) {
            $value       = preg_replace('/<a\s/is', '<a rel="bear" ', $value);
            $array[$key] = $value;
        }
        return $array;
    }

    /**
     * 結果の取得
     *
     * @return  string
     */
    function getBody()
    {
        return $this->_body;
    }
    
    /**
     * 結果の取得
     *
     * @return  string
     * @deprecated 
     */
    function getResult()
    {
        return $this->_body;
    }

    /**
     * ヘッダーの取得
     *
     * @return mixed
     */
    function getHeaders()
    {
        return $this->_headers;
    }

    /**
     * リンクの取得
     *
     * @return mixed
     */
    function getLinks()
    {
        return $this->_links;
    }

    /**
     * 結果コードの取得
     *
     * @return int
     */
    public function getCode()
    {
        return $this->_code;
    }

    /**
     * リソース作成
     *
     * <pre>
     * リソースを作成します。
     *
     * $params
     * 'uri'     string URI
     * 'values'  array  引数
     * 'options' array  オプション
     * 
     * </pre>
     *
     * @param array $params リクエストパラメータ
     *
     * @return BEAR_Vo
     */
    public function create(array $params)
    {
        $values        = isset($params['values']) ? $params['values'] : array();
        $options       = isset($params['options']) ? $params['options'] : array();
        $this->_method = self::METHOD_CREATE;
        $this->_setUri($params['uri']);
        $result = $this->_request($values, $options);
        return $result;
    }

    /**
     * リソース読み込み
     *
     * <pre>
     * リソースを読み込みます。
     *
     * $params
     * 'uri'     string URI
     * 'values'  array  引数
     * 'options' array  オプション
     * 
     * $params['options']
     *  'cache' 'id'   string キャッシュID
     *  'cache' 'life' int    キャッシュ時間（秒）
     *
     * @param array $params 引数
     *
     * @return BEAR_Vo
     */
    public function read(array $params)
    {
        $values             = isset($params['values']) ? $params['values'] : array();
        $options            = isset($params['options']) ? $params['options'] : array();
        $this->_method      = self::METHOD_READ;
        self::$isReadMethod = true;
        BEAR::required(array('uri'), $params);
        $this->_setUri($params['uri']);
        $this->_vo =& $this->_request($values, $options);
        return $this->_vo;
    }

    /**
     * リソース更新
     *
     * リソースを更新します。
     *
     * $options
     *
     *  'poe'            bool   二重実行防止
     * </pre>
     *
     * @param array $params 引数
     *
     * @return BEAR_Vo
     */
    public function update(array $params)
    {
        $values        = isset($params['values']) ? $params['values'] : array();
        $options       = isset($params['options']) ? $params['options'] : array();
        $this->_method = self::METHOD_UPDATE;
        $this->_setUri($params['uri']);
        $result = $this->_request($values, $options);
        return $result;
    }

    /**
     * リソース削除
     *
     * リソースを削除します。
     *
     * $params
     * 'uri'     string URI
     * 'values'  array  引数
     * 'options' array  オプション
     * </pre>
     *
     * @param array $params 引数
     *
     * @return BEAR_Vo
     */
    public function delete(array $params)
    {
        $values        = isset($params['values']) ? $params['values'] : array();
        $options       = isset($params['options']) ? $params['options'] : array();
        $this->_method = self::METHOD_DELETE;
        $this->_setUri($params['uri']);
        $result = $this->_request($values, $options);
        return $result;
    }

    /**
     * リソース操作
     *
     * 外部リソース（DB、ファイル等）に対しての操作を行います。
     * リソース名に対応するリソースファイルがApp/resouce/フォルダから
     * 読み込まれ$valuesで受け取った値を渡します。
     * 帰り値はgetResult()メソッドで取得できます。
     *
     * <pre>
     * DB、ファイルなどの外部リソースからデータを取得します。リソースファイルを
     * App/resourceフォルダに用意したものが使われます。
     * 引数から外部リソースを操作した値を連想配列で返します。
     *
     * キャッシュオプションを指定することでキャッシュが使用できます。キーは自動で
     * 生成されるのでキャッシュ時間を指定するだけの透過的な使用ができます。
     * リモートリソースの場合もキャッシュは有効です。
     *
     * ビューの作成に失敗した場合はPEARのエラーを返すとキャッシュが生成されません。
     *
     * $options
     *

     *  'callback'       string コールバック関数名
     *  'poe'            bool   二重実行防止
     *
     * <pre>
     * Example 1.ビュー取得
     * </pre>
     * <code>
     * $values['key'] = 'hoge_id';
     * $res = new BEAR_Resource('usr/entries');
     * $topic = $res->read($values);
     * </code>
     *
     * <pre>
     * Example 2　600秒有効のキャッシュ
     * </pre>
     * <code>
     * $values['key'] = 'hoge_id';
     * $options['cache']['key'] = hoge';            //省略化
     * $options['cache']['life'] = 600;
     * $res = new BEAR_Resource('usr/entries');
     * $topic = $res->read($values, $options);
     * </code>
     *
     * <pre>
     * Example 4　ページングリソースの取得(一旦結果を全て収得して分割）
     * </pre>
     * <code>
     * $app = new BEAR_Resource('usr/entries');
     * $app->make('$values);
     * $app->makePager(5)
     * $view = $app->getBody();
     * $links = $app->getPager();
     * </code>
     *
     * <pre>
     * Example 5　ページングリソースの取得(DBページャー使用）
     * </pre>
     * <code>
     * $res = new BEAR_Resource('usr/entries');
     * $res->r(, $values);
     * $entries = $app->getBody();
     * $links = $app->getPager();
     * </code>
     *
     * リソース名 hoge1の場合
     *
     * リソースファイル名：
     * </pre>
     * <samp>
     * /action/app.action.hoge1.php
     * </samp>
     *
     * リソース関数：
     * <code>
     * function hoge1($values){
     * }
     * </code>
     *
     * @param string $values  引数
     * @param mixed  $options オプション
     *
     * @return  BEAR_Vo
     */
    private function _request(array $values, array $options = array())
    {
        // reset to  array()
        $this->_headers = array();
        // reset to null
        $this->_body = $this->_links = $this->_vo = null;
        // URIのクエリーと$valuesをmerge
        $this->_mergeQuery($values);
        $this->_options = $options;
        // トークン
        if (isset($options['notoken']) && !$options['notoken']) {
            if ($this->_isTokenValid($options) === false) {
                return false;
            }
        }
        $config = array('method' => $this->_method, 'uri' => $this->_uri, 'values' => $this->_values, 'options' => $this->_options);
        // リクエストクラスを注入
        $this->resoueceRequest = BEAR::dependency('BEAR_Resource_Request', $config);
        // 返り値はエラーありなしに関わらずBEAR_Voコンテナになっている
        $vo = $this->resoueceRequest->request($this->_uri, $this->_values, $this->_method);
        BEAR_Log::resourceLog($this->_method, $this->_uri, $this->_values, $options);
        /* @var $vo BEAR_Vo */
        $this->_body    = $vo->getBody();
        $this->_links   = $vo->getLinks();
        $this->_headers = $vo->getHeaders();
        $this->_code    = $vo->getCode();
        $this->_vo      = $vo;
        return $vo;
    }

    /**
     * URIについたクエリーをmergeする
     *
     * <pre>
     * usr?id=1というURIはuriがuserでvaluesが　array('id'=>1)として扱われます。
     * </pre>
     *
     * @param array $values 引数
     *
     * @return void
     */
    private function _mergeQuery(array $values = array())
    {
        if (!$this->_values) {
            $this->_values = $values;
        } else {
            // URIにクエリー引数がついていて場合にはmergeする
            if (is_array($this->_values) && is_array($values)) {
                $this->_values = array_merge($this->_values, $values);
            }
        }
    }

    /**
     * HTTP出力
     *
     * 指定されたフォーマットでHTTP出力します。
     * 指定フォーマットのアウトプットファイルを以下の順（BEAR, App)で探します。
     *
     * 1) /BEAR/Resource/output/
     * 2) /App/output/
     *
     * @param string $format  フォーマット
     * @param mixed  $options オプション
     *
     * @return void
     */
    public function outputHttp($format = 'php', array $options = array())
    {
        if (file_exists(_BEAR_BEAR_HOME . '/BEAR/Resource/output/' . $format . '.php')) {
            $formatFile = _BEAR_BEAR_HOME . '/BEAR/Resource/output/' . $format . '.php';
        } elseif (file_exists(_BEAR_APP_HOME . '/App/Resource/output/' . $format . '.php')) {
            $formatFile = _BEAR_APP_HOME . '/App/output/' . $format . '.php';
        } else {
            $vo = new BEAR_Vo();
            $vo->setCode(BEAR::CODE_BAD_REQUEST);
            $vo->httpOutput();
        }
        include_once $formatFile;
        if (!function_exists('output' . $format)) {
            $info = array('format' => $format);
            $msg  = 'Output format is unavailable.（アウトプットフォーマットが利用できません)';
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', $info, $msg);
        }
        $code = $this->_vo->getCode();
        $body = $this->_vo->getBody();
        $vo   = call_user_func('output' . $format, $body, $options);
        $vo->setCode($code);
        /* @var $vo BEAR_Vo */
        $vo->outputHttp();
        exit();
    }

    /**
     * バリューオブジェクトの取得
     *
     * <pre>
     * BEAR_Resource内で生成されたリソースの結果であるバリューオジェクトを返します。
     *　</code>
     *
     * @return void
     */
    public function getVo()
    {
        return $this->_vo;
    }
}


<?php
/**
 * BEAR_Resource
 * 
 * PHP versions 5
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Output
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: ajax.php 470 2009-02-18 10:11:46Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * JSON出力
 *
 * @param array $values 無効
 * @param array $options 無効
 * 
 * @return BEAR_Vo
 */
function outputAjax($values, $options = null)
{
    $values  = BEAR_Page::getAjaxValues();
    $json    = json_encode($values);
    BEAR_Log::appLog('AJAX', $values);
    $headers = array('X-BEAR-Output: AJAX', 'Content-Type: text/javascript+json; charset=utf-8');
    return new BEAR_Vo($json, $headers);
}
<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @link      http://api.bear-project.net/BEAR/BEAR.html
 */
require 'Panda.php';
require 'Panda/Debug/util.php';
require 'Panda/inc/FirePHPCore/FirePHP.class.php';
require 'Panda/inc/FirePHPCore/fb.php';
/**
 * パーミッションチェック
 */
$config = new PEAR_Config();
$pearDataPath = $config->get('data_dir');
if (strpos(_BEAR_BEAR_HOME, $pearDataPath)) {
    $dataDir = "$pearDataPath/BEAR";
} else {
    $dataDir = _BEAR_BEAR_HOME . '/data/';
}

if (file_exists("$pearDataPath/BEAR")) {
    $dataDir = '$pearDataPath/BEAR';
} elseif (file_exists($pearDataPath . '/data')) {
    $dataDir = 'BEAR/data';
}
if (PHP_SAPI !== 'cli') {
    $isBearInfo = isset($_GET['_bearinfo']);
    $isWritable = is_writable(_BEAR_APP_HOME . '/logs') && is_writable(_BEAR_APP_HOME . '/tmp/smarty_templates_c');
    $isBearDirExists = file_exists(_BEAR_APP_HOME . '/htdocs/__bear');
    $isPandaExists = file_exists(_BEAR_APP_HOME . '/htdocs/__panda');
    if (isset($_GET['_bearinfo']) || !$isWritable) {
        $heading = 'BEAR Ver. ' . BEAR::VERSION;
        $info = '<h3>BEAR Path</h3><div><code>' . _BEAR_BEAR_HOME . '</code></div>';
        $info .= '<h3>App Path</h3><div><code>' . _BEAR_APP_HOME . '</code></div>';
        $info .= '<h3>Include Path</h3><div><code>' . get_include_path() . '</code></div>';
        Panda::message($heading, '', $info);
        exit();
    }
    $subHeading = $info = '';
    if (!$isWritable) {
        $info .= '<div><code>sudo chmod -R 777 ' . _BEAR_APP_HOME . '/logs;</code></div>';
        $info .= '<div><code>sudo chmod -R 777 ' . _BEAR_APP_HOME . '/tmp;</code></div>';
    }
    if (!$isWritable) {
        $subHeading = '現在開発環境で動作しています。このコードをシェルで実行して環境の';
        $subHeading .= 'セットアップを完了させてください。';
        Panda::message('セットアップを完了させてください', $subHeading, $info);
        exit();
    }
    if (isset($_GET['_error'])) {
        error_reporting(E_ALL | E_STRICT);
        ini_set('display_errors', 1);
        return;
    }
}

/**
 * Do Nothing
 * 
 * @return void
 */
function bearDoNothing(){
}

// to avoid "Class __PHP_Incomplete_Class has no unserializer" error 
ini_set('unserialize_callback_func', 'bearDoNothing');
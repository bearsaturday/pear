/*
 * BEAR Log
 *
 */
Ext.onReady(function(){
    var bearLogTabs = new Ext.TabPanel({
        renderTo: 'bearlog',
        activeTab: 0,
        width:1000,
        height:"auto",
        plain:true,
        defaults:{autoScroll: true, autoHeight: true},
        items:[{
                title: 'Resource',
                disabled:true
            },{
                title: 'PHP',
                autoLoad:'/beardev/phpinteractive_0.2/'
            }
        ]
    });
});
/*
 * BEAR Log
 *
 */
Ext.onReady(function(){
    var bearLogTabs = new Ext.TabPanel({
        renderTo: 'bearlog',
        activeTab: 0,
        width:1000,
        height:"auto",
        plain:true,
        defaults:{autoScroll: true, autoHeight: true},
        items:[{
                title: 'Page',
                autoLoad:'/beardev/var.php?log=app'
            },{
                title: 'Smarty',
                autoLoad:'/beardev/var.php?log=smarty'
            },{
                title: 'Vars',
                autoLoad:'/beardev/var.php?log=var'
            },{
                title: 'Previous',
                autoLoad:'/beardev/var.php?log=prev'
            },{
                title: 'Ajax',
                disabled:true
            }
        ]
    });
});
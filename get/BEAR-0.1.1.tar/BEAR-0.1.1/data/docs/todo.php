<?php
/**
 * @todo BEAR_PAGE::saveSaveState(); //ページスタテートの保存
 * @todo BEAR_PAGE::loadSaveState();　
 * 
 */
?>
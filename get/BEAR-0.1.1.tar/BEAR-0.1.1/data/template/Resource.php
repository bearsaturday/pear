<?php

/**
 * Untitled Resource
 * 
 * description here...
 *
 */
class User extends BEAR_Content
{

    /**
     * テーブル名
     */
    private $_table = "users";

    public function create($values)
    {
        //assert & mapping
        // BEAR_Mdb2::assert(is_string($values['name']));
        //db
        $db = App_DB::getInstance();
        $extended = & $db->extended;
        /* @var $extended MDB2_Extended */
        $values['created'] = BEAR::$datetime; //現在時刻
        $result = $extended->autoExecute($this->_table, $values, MDB2_AUTOQUERY_INSERT);
        $id = $db->lastInsertId($this->_table);
        return $id;
    }

    public function update($values)
    {
        //assert & mapping
        //BEAR_Mdb2::assert(is_string($values['id']));
        //BEAR_Mdb2::assert(is_string($values['name']));
        $db = App_DB::getInstance();
        $extended = & $db->extended;
        $values['updated'] = BEAR::$datetime;
        /* @var $extended MDB2_Extended */
        $where = 'id = ' . $db->quote($values['id'], 'integer');
        $result = $extended->autoExecute($this->_table, $values, MDB2_AUTOQUERY_UPDATE, $where);
        return $result;
    }

    public function read($values)
    {
        //assert & mapping
        $db = App_DB::getInstance();
        if (isset($values['id'])) {
            $sql = "SELECT * FROM {$this->_table} WHERE id = " . $db->quote($values['id'], 'integer');
            $result = $db->queryRow($sql);
        } else {
            $sql = "SELECT * FROM {$this->_table}";
            $result = $db->queryAll($sql);
        }
        return $result;
    }

    public function delete($values)
    {
        //BEAR_Mdb2::assert(is_string($values['id']));
        $db = App_DB::getInstance();
        $extended = & $db->extended;
        $values['updated'] = BEAR::$datetime;
        $values['enabled'] = false;
        /* @var $extended MDB2_Extended */
        $where = 'id = ' . $db->quote($values['id'], 'integer');
        $result = $extended->autoExecute($this->_table, $values, MDB2_AUTOQUERY_UPDATE, $where);
        return $result;
    }
}
?>

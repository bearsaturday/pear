<?php
/**
 * @package App
 * @subpackage page
 */
require_once 'App.php';

/**
 * Untitled Page
 * 
 * description here...
 *
 * @package     App
 * @subpackage  page
 * @author      $Author: $
 * @version     $Id: $
 */
class Example_Page extends App_Page
{

    function onInit()
    {}

    function onOutput()
    {
        $this->display();
    }

    function onAction($submit)
    {
        $this->set('submit', $submit);
        $this->display();
    }
}

new BEAR_Main('Example_Page');
<?php

/**
 * @category    BEAR
 * @package     BEAR_Cache
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * キャッシュアダプタークラス
 * 
 * @category    BEAR
 * @package     BEAR_Cache
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Cache.php 406 2008-07-02 06:41:10Z koriyama $
 */
abstract class BEAR_Cache_Adapter
{

    /**
     * 
     * キャッシュアクティブ
     * 
     * @var bool
     * 
     */
    protected $_active = true;

    /**
     * 
     * キャッシュ時間
     * 
     * @var int
     * 
     */
    protected $_life = 0;

    /**
     * コンストラクタ.
     * 
     * @param array $config ユーザーコンフィグ
     */
    public function __construct($config = array('active'=>true, 'life'=>0))
    {
        $this->_active = (bool)$config['active'];
        $this->_life = (int)$$config['life'];
    }

    /**
     * キャッシュアクティブ
     * 
     * @param bool $flag trueでオン, falseでオフ
     * 
     */
    public function setActive($flag = true)
    {
        $this->_active = (bool)$flag;
    }

    public function isActive()
    {
        return (bool)$this->_active;
    }

    /**
     * キャッシュ保存
     * 
     * "insert"または"update"でキャッシュにデータを保存します。
     * 
     * @param string $key　キャッシュキー
     * @param mixed $value　値
     * @param integer $life 秒数
     * @return bool
     */
    abstract public function set($key, $value, $life = 0);

    /**
     * キャッシュを取得
     *
     * キーを基にキャッシュデータを取得します。無い場合にはデフォルト<var>$default</var>sが使われます。
     * 
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    abstract public function get($key, $default = null);

    /**
     * キャッシュの削除
     *
     * @param string $key
     */
    abstract public function delete($key);

    /**
     * キャッシュの全削除
     * 
     */
    abstract public function deleteAll();
}
<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Cache
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * Memcacheクラス
 *
 * @category    BEAR
 * @package     BEAR_Cache
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Cache.php 392 2008-06-30 07:05:44Z koriyama $
 * @see         http://jp2.php.net/manual/ja/ref.memcache.php
 */
class BEAR_Cache_Adapter_Memcache extends BEAR_Cache_Adapter
{

    /**
     * memcacheサーバーホスト配列
     */
    const CONFIG_SERVERS = 'servers';

    /**
     * ポート番号
     */
    const PORT_MEMCACHED = 11211;

    public $memcache;

    /**
     * インスタンス取得
     *
     * @return object
     * @see http://jp.php.net/manual/ja/function.memcache-addserver.php
     */
    function __construct($config)
    {
        if (!extension_loaded('memcache')) {
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', null, "Memcached extention is not loaded");
        }
        parent::__construct();
        $config = BEAR::values($config);
        $this->memcache = new Memcache();
        //キャッシュサーバー追加
        foreach($config[self::CONFIG_SERVERS] as $host) {
            // １台でもconnectでなくaddServerを使う
            $this->memcache->addServer($host, self::PORT_MEMCACHED);
        }
        if (App::$debug) {
            $version = $this->memcache->getversion();
            BEAR_Log::appLog('Memcache', $version);
            if (!$version) {
                PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('Server' => $config[self::CONFIG_SERVERS]), "Invalid Memcache Server");
            }
        }
        return $this->memcache;
    }

    /**
     * キャッシュを保存
     *
     * @param string $key　キャッシュキー
     * @param mixed $value　値
     * @param integer $life 秒数
     * @return bool
     */
    public function set($key, $value, $life = 0)
    {
        $result = $this->memcache->replace(App::ID . $key, $value, $this->memcache->flag, $life);
        if (!$result) {
            $result = $this->memcache->set(App::ID . $key, $value, null, $life);
        }
        return $result;
    }

    /**
     * キャッシュを取得
     *
     * キーを基にキャッシュデータを取得します
     * 
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function get($key, $default = null)
    {
        if (!$this->_active) {
            return null;
        }
        $result = $this->memcache->get(App::ID . $key);
        if (!$result) {
            $result = $default;
        }
        return $result;
    }

    /**
     * キャッシュの削除
     *
     * @param string $key
     */
    public function delete($key)
    {
        if (!$this->_active) {
            return null;
        }
        $result = $this->memcache->delete(App::ID . $key);
        return $result;
    }

    /**
     * キャッシュの全削除
     * 
     */
    public function deleteAll()
    {
        if (!$this->_active) {
            return;
        }
        $this->memcache->flush();
    }
}
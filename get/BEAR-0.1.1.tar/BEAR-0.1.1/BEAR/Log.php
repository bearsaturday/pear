<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Log
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * ログ
 *
 * <pre>ログを記録するクラスです</pre>
 * 
 * Example 1. debugモードのときにアプリケーションログを画面出力
 *
 * <code>
 * BEAR_Log::appLog($label, $data);
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Log
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Log.php 414 2008-07-02 10:42:38Z koriyama $
 */
class BEAR_Log
{

    /**
     * アプリケーションログ
     */
    const TYPE_APP = 0;

    /**
     * エラーログ
     */
    const TYPE_ERROR = 1;

    /**
     * リソースアクセスログ
     */
    const TYPE_RESOURCE = 2;

    /**
     * アプリケーションログ
     *
     * @var array
     */
    public static $log;

    /**
     * エラーログ
     *
     * @var array
     */
    public static $errorLog;

    /**
     * リソースログ
     *
     * @var array
     */
    public static $resoruceLog;

    /**
     * Smartyにアサインされた変数
     *
     * @var array
     */
    public static $smartyLog;

    /**
     * エラー統計
     *
     * @var int
     */
    public static $errorStat;

    /**
     * アプリユーザー
     * 
     * ユーザーの特定につながる情報をストアします。
     */
    public static $user = "nobody";

    /**
     * アプリケーションログを記録
     *
     * アプリケーションログを記録します。$valueは配列可です。
     *
     * @param string $label ラベル
     * @param mixed $value  値
     * @access public
     * @static
     */
    public static function appLog($label, $log)
    {
        self::$log[][$label] = $log;
    }

    /**
     * エラーログを保存
     * 
     */
    public static function errorLog($label, $log)
    {
        self::$errorLog[][$error_type][$label] = $log;
    }

    /**
     * エラーログを保存
     * 
     */
    public static function resourceLog($label, $log)
    {
        self::$resoruceLog[][$error_type][$label] = $log;
    }

    function __construct()
    {
        if (App::$debug) {
            self::appLog(array('URI' => $_SERVER['REQUEST_URI'], 'time' => date('r')));
        }
    }

    /**
    }
     * アプリケーションログを表示
     *
     * アプリケーションログをHTML表示します。フレームワーク内で使用されます。
     *
     * @param   void
     * @return  void
     * @access  public
     * @static
     * @ignore
     */
    public function displayScreenLog()
    {
        if (!App::$debug) {
            return;
        }
        // エラー統計
        $errorFgColor = "white";
        if (BEAR_Error::$errorStat & E_ERROR) {
            $errorBgColor = "red";
            $errorMsg = "Fatal Error";
        } elseif (BEAR_Error::$errorStat & E_WARNING) {
            $errorBgColor = "yellow";
            $errorFgColor = "black";
            $errorMsg = "Warning";
        } elseif (BEAR_Error::$errorStat & E_NOTICE) {
            $errorBgColor = "#2D41D7";
            $errorMsg = "Notice";
        } else {
            $errorBgColor = "green";
        }
        // デバック情報表示HTML
        // bear.jsを使用する場合はbear_debuggingがtrueになる
        $html = '<!--BEAR Debug Info--><div style=" font-size: 9px; position: absolute;  top: 0px;  right: 0px; text-align: right;"><a href="/beardev/log/" accesskey="b" target="bearlog" name="' . $errorMsg . '" style="padding:5px 3px 3px 3px;background-color:' . $errorBgColor . ';color:' . $errorFgColor . ';font:bold 8pt Verdana; margin-top:100px; border: 1px solid #dddddd">BEAR</a></div>' . '</div><!--/BEAR Debug Info-->';
        print $html;
    }

    /**
     * スクリプトシャットダウン時のログ処理
     * 
     * <pre>
     * アプリケーションログ、smartyアサインログ、グローバル変数ログ、リクエストURIをシリアライズしてファイル保存します。
     * デバックモードの時のみ使用します。保存されたログは/beardev/logs/でブラウズできます。
     * シャットダウン時実行のメソッドとしてフレームワーク内で登録され、スクリプト終了時に実行されます。
     * フレームワーク内で使用されます。
     * </pre>
     * 
     * 
     */
    public static function shutDownLogDebug()
    {
        if (App::$debug != true) {
            return;
        }
        $log = array();
        if (file_exists(_BEAR_APP_HOME . '/logs/page.log')) {
        	BEAR::$enableAutoLoader = false;
            $previousPageLog = unserialize(file_get_contents(_BEAR_APP_HOME . '/logs/page.log'));
            $log['prev'] = $previousPageLog['app'];
            $log['panda'] = 1;
        }
        $log += array('app' => BEAR_Log::$log, 'smarty' => BEAR_Page::$smarty->_tpl_vars, 'var' => DbugL::css . show_vars('trim_tabs:2;show_objects:0;max_y:30;avoid@:1; return:1') . '$_SERVER' . print_a($_SERVER, 'return:1'), 'uri' => $_SERVER['REQUEST_URI']);
        $result = file_put_contents(_BEAR_APP_HOME . '/logs/page.log', serialize($log));
        if (!$result) {
            BEAR_Error::showBoxMessage('Log folder permission denied.（ログフォルダに書き込めません)', '<code>chmod 777 ' . _BEAR_APP_HOME . '/logs</code><br>' . '<code>chmod -R 777 ' . _BEAR_APP_HOME . '/tmp</code>', 'webからの書き込み権限を与えてください');
        }
        if (!file_exists(_BEAR_APP_HOME . '/htdocs/beardev')) {
            BEAR_Error::showBoxMessage('no beardev symlink.（/beardev/のリンクがありません)', '<code>ln -s  ' . _BEAR_BEAR_HOME . '/data/htdocs/beardev ' . _BEAR_APP_HOME . '/htdocs</code>', 'htdocsにbeardev(デバックツール)のリンクを張ってください');
        }
    }

    /**
     * スクリプトシャットダウン時のログ処理
     *
     * @todo syslogにリソースログを残す 
     */
    public static function shutDownLogLive()
    {}
}
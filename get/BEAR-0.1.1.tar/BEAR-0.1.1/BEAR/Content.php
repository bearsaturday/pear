<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Content
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEAR_Contentクラス
 *
 * <pre> 
 * リソースファイルで使用するリソースコンテントクラスです。リソースに対する4つのインターフェイスを提供します。
 * create, read, update, deleteで作成、読み込み、変更、変更、削除の４つのメソッドいずれかでリソースにアクセスします。
 * </pre>
 *
 * @category    BEAR
 * @package     BEAR_Content
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 */
class BEAR_Content
{

    /**
     * 結果コード
     *
     * @var integer
     */
    public $result_code = BEAR_Resource::RESULT_CODE_200_OK;

    /**
     * リソース読み込み
     *
     * @param array $values
     * @return mixed
     */
    public function onRead($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * リソース作成
     *
     * @param array $values
     * @return mixed
     */
    public function onCreate($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * リソース変更
     *
     * @param array $values
     * @return mixed
     */
    public function onUpdate($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * リソース消去
     *
     * @param array $values
     * @return mixed
     */
    public function onDelete($values)
    {
        $this->result_code = BEAR_Resource::RESULT_CODE_400_BAD_REQUEST;
        return null;
    }

    /**
     * DBリザルトをリソースリザルトに変更します
     *
     * @access protected
     * @param object $db_result
     * @return unknown
     */
    protected function dbResult($dbResult)
    {
        return PEAR::isError($dbResult) ? BEAR_Resource::RESULT_200_OK : BEAR_Resource::RESULT_500_ERROR;
    }
}
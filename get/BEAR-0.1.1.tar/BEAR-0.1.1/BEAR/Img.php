<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Img
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEAR_Imgクラス
 *
 * <pre>
 * 未実装です
 * </pre>
 *
 * @category    BEAR
 * @package     BEAR_Img
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Log.php 414 2008-07-02 10:42:38Z koriyama $
 *
 */
class BEAR_Img
{

    /**
     * テンポラリーファイル作成場所
     *
     */
    const TMP_DIR = '/tmp/image/';

    /**
     * シングルトンオブジェクト
     *
     * @var object
     * @access public
     */
    static $singleton;

    /**
     * 消去用テンポラリーファイルリスト配列
     *
     * @var array
     */
    static $deleteFiles;

    /**
     * インスタンス取得
     *
     * @return object
     */
    public function getInstance()
    {
        if (!isset(self::$singleton)) {
            self::$singleton = new BEAR_Img();
        }
        return self::$singleton;
    }

    /**
     * コンストラクタ
     *
     * テンポラリー画像ファイルの消去関数をスクリプト終了時に関数予約する
     *
     */
    protected function __construct()
    {
        //テンポラリーファイルの削除
        register_shutdown_function(array(
                'BEAR_Img', 'onShutdown'));
    }

    /**
     * テンポラリーファイルの消去
     *
     * <pre>画像変換などに使用するテンポラリーファイルを消去します。
     * コンストラクタでシャットダウン時に実行する関数として登録され実行されます。
     * </pre>
     *
     * @param void
     * @return void
     * @access private
     *
     */
    public function onShutdown()
    {
        if (is_array(BEAR_Img::$deleteFiles)) {
            foreach(BEAR_Img::$deleteFiles as $delete_file) {
                if (is_string($delete_file)) {
                    $result = unlink($delete_file);
                    if (!$result && App::$debug) {
                        header("X-BEAR-Img-Error: file not deleted..[{$delete}]");
                        trigger_error("unlink failed error: [$delete_file]", E_USER_WARNING);
                    }
                }
            }
        }
    }

    /**
     * キャッシュエンジンファクトリー
     *
     * 指定のキャッシュエンジンでキャッシュオブジェクトを返します
     *
     * @return object
     * @return BEAR_Cache_Adapter
     */
    public static function getInstance($config = array('engine' => BEAR_Cache::ENGINE_NONE, 'options' => null))
    {
        if (self::$_instance) {
            return null;
        }
        $config = BEAR::values($config);
        switch ($config['engine']) {
            case self::ENGINE_MEMCACHE :
                $config = array('servers' => App::$memcache);
                self::$_instance = new BEAR_Cache_Adapter_Memcache($config);
                break;
            case self::ENGINE_NONE :
                self::$_instance = new BEAR_Cache_Adapter_Cache_Lite();
                break;
            case self::ENGINE_NONE :
            default :
                self::$_instance = new BEAR_Cache_Adapter_None();
        }
        return self::$_instance;
    }

    /**
     * インスタンス消去
     */
    public static function destoryInstance()
    {
        self::$_instance = null;
    }
}

<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Form
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEARフォームクラス
 *
 * PEAR::HTML_QuickFormクラスのラッパークラスです。
 *
 * @category    BEAR
 * @package     BEAR_Form
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Form.php 406 2008-07-02 06:41:10Z koriyama $
 * @see         PEAR::HTML_QuickForm
 */
class BEAR_Form extends HTML_QuickForm
{

    /**
     * '静的な' Smarty テンプレートのためのレンダラ
     * @see http://pear.php.net/manual/ja/package.html.html-quickform.html-quickform-renderer-arraysmarty.php
     */
    const RENDERER_SMARTY_ARRAY = 0;

    /**
     * 完全に妥当な XHTML を出力するレンダラ
     * 
     * @see http://pear.php.net/manual/ja/package.html.html-quickform-renderer-tableless.intro.php
     *
     */
    const RENDERER_DHTML_TABLELESS = 1;

    /**
     * JS Alertのメッセージ
     *
     */
    const JS_WARNING = '入力内容に誤りがあります';

    /**
     * 必須項目メッセージ
     *
     */
    const REQUIRE_NOTES = '<span style="font-size:80%; color:#ff0000;">*</span><span style="font-size:80%;">の項目は必ず入力してください。</span>';

    /**
     * エラーテンプレート
     *
     */
    const TEMPLATE_ERROR = '{if $error}<font color="red">{$label}</font>{/if}';

    /**
     * 必須項目テンプレート
     *
     */
    const TEMPLATE_REQUIRED = '{$html}{if $required}<font color="#FF0000">*</font>{/if}';

    /**
     * フォームエラーSmarty変数アサイン名
     * 
     */
    const FORM_ERRORS = 'form_errors';
    
    /**
     * Submit値
     * 
     * Quick_Form::getSubmitValue()の値
     *
     * @var array
     */
    public static $submitValue;

    /**
     * Export値
     * 
     * Quick_Form::getExportValue()の値
     * 
     */
    public static $exportValue;

    /**
     * AJAXフォーム用フラグ
     *
     * @var bool
     * @access private
     */
    private $_is_ajax_form = false;

    /**
     * エラーテンプレート
     * 
     * @var string
     */
    public static $error_template = self::TEMPLATE_ERROR;

    /**
     * 必須項目テンプレート
     * 
     * @var string
     */
    public static $require_template = self::TEMPLATE_REQUIRED;

    /**
     * 必須項目説明表示
     * 
     * @var string
     */
    public static $requireNotes = self::REQUIRE_NOTES;

    /**
     * JS警告
     */
    public static $jsWarning = self::JS_WARNING;

    /**
     * フォームレンダラ
     * 
     * @var string
     */
    private static $_renderer = self::RENDERER_SMARTY_ARRAY;

    /**
     * フォーム名
     */
    public static $form = 'form';

    /**
     * 送信方法
     *
     * @var string
     */
    public static $method = 'post';

    /**
     * シングルトン
     */
    private static $_instance = null;
        
    /**
     * BEAR_Formインスタンス取得
     *
     * @param string $formNames
     * @param string $method
     * @param string $action
     * @param string $target
     * @param string $attributes
     * @return BEAR_Form
     */
    //    public static function getInstance($formNames = 'form', $method = 'post', $action = '', $target = '', $attributes = null)
    public static function getInstance($formNames = 'form', $options = array('method' =>'post', 'action' => '', 'target' => '', 'attributes' => null))
    {
        //        $formNames = $config['form'];        
        self::$form = $formNames;
        if (!is_array($formNames)) {
        	// 単数フィーム
            if (self::$_instance === null) {
                $options['trackSubmit'] = false;
                self::$_instance = self::_factory($formNames, $options);
            }
        } else {
        	// 複数フォーム
            $options['trackSubmit'] = true;
            foreach($formNames as $formName) {
                self::$_instance[$formName] = self::_factory($formName, $options);
            }
        }
        self::$method = $method;
        return self::$_instance;
    }

    /**
     * ファクトリー
     * 
     * HTML_QuickFormインスタンス生成
     *
     * @param mixed $formName
     * @param array $options
     * @return HTML_QuickForm
     * @access private
     */
    function _factory($formName, $options)
    {
        // QuickForm作成
        $form = new self($formName, $options['method'], $options['action'], $options['target'], $options['attributes'], $options['trackSubmit']);
        // 必須項目メッセージ日本語化
        $form->setRequiredNote(BEAR_Form::$requireNotes);
        // JSメッセージ日本語化
        $form->setJsWarnings(BEAR_Form::$jsWarning, '');
        // BEAR使用hidden項目
        $newToken = self::_saveToken($form);
        $log = $options;
        $log['formNames'] = $formName;
        $log['token'] = $newToken;
        BEAR_Log::appLog('Form', $log);
        return $form;
    }

    /**
     * @ignore 
     */
    public function __clone()
    {
        trigger_error('Singleton.Clone is not allowed.', E_USER_ERROR);
    }

    /**
     * BEAR_FORMがインスタンスをもつか返す
     *
     * @return bool
     */
    public static function hasInstance()
    {
        return (self::$_instance) ? true : false;
    }

    /**
     * インスタンス解放
     * 
     * ページの再生成で使用されます
     */
    public static function init()
    {
        self::$_instance = null;
    }

    public static function setRenderer($renderer)
    {
        self::$_renderer = $renderer;
    }
    
    public static function getRenderer()
    {
        return self::$_renderer;
    }
    
    /**
     * トークンの保存
     * 
     * 二重送信防止とCSSF防止のため、セッションとhiddenに埋め込みます
     *
     * @param array $formNames
     * @param object $form
     * @param bool $is_single_form
     * @return string $newToken
     * @access private
     */
    private function _saveToken(&$form)
    {
        $newToken = self::makeToken();
        $form->addElement('hidden', '_token', $newToken);
        return $newToken;
    }

    /**
     * トークン生成
     *
     * <pre>14桁の16進数トークンを生成。
     * 前12桁がデータ、残り2桁がチェックサム。
     * スタティックコールできます。
     *
     * データ例）
     * 8486ab282a8f37
     * <--data----><check sum>
     * </pre>
     *
     * @return string
     * @static
     */
    public static function makeToken($isAjax = false)
    {
        if ($isAjax) {
            $token_body = 'a' . HTTP_Session2::get('stoken') . substr(md5(uniqid(rand(), true)), 0, 8);
        } else {
            $token_body = '0' . HTTP_Session2::get('stoken') . substr(md5(uniqid(rand(), true)), 0, 8);
        }
        $result = $token_body . self::makeAuthKey();
        return $result;
    }
    
    /**
     * セッショントークンの取得
     * 
     * セッション開始時につくられるトークンを取得します
     * 
     * @param void
     * @return string
     * @static 
     */
    public static function getSessionToken()
    {
        $result = HTTP_Session2::get('stoken');
        return $result;
    }
    
    /**
     * トークン用認証キー生成
     *
     * @return string
     */
    public static function makeAuthKey()
    {
        return substr(md5(session_id() . App::AUTH_KEY), 0, 4);
    }

    /**
     * フォームをAJAX用にする
     *
     * <pre>QuickFormのフォームをAJAX対応にします。formタグにrel=bearという属性が追加され
     * postがAJAXリクエストに変わります</pre>
     *
     * Example.1 ページ内でフォームをAJAXフォームに変換
     *
     * <code>
     * $this->form->ajax();
     * </code>
     *
     * @param void
     * @return void
     *
     */
    public function ajax()
    {
        $token_ref = & $this->getElement('_token');
        if (!PEAR::isError($token_ref)) {
            $token_ref->_attributes['value'] = BEAR_Main::makeToken(true);
        } else {
            BEAR_Log::appLog('BEAR_Error', array(
                    'Erro no token for AJAX'));
        }
        $attr = $this->_attributes;
        $attr['rel'] = "bear";
        $this->setAttributes($attr);
        $this->_is_ajax_form = true;
    }

    /**
     * AJAXフォームかどうかを返す
     *
     * フォームがAJAXか
     *
     * @return bool
     */
    public function isAjaxForm()
    {
        return $this->_is_ajax_form;
    }
    
    /**
     * フォームエラーを返す
     * 
     * 配列でバリデーションエラーを返します
     */
    public function getErrors()
    {
        return $this->_errors;
    }
}
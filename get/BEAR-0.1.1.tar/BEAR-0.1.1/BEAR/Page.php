<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Page
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEAR_Pageクラス
 *
 * <pre>
 * ページの抽象クラスです。onで始まるメソッドがイベントドリブンでコールされます。
 * 以下が基本3メソッドです。
 *
 * onInit($args)        初期化
 * onOutput()           ページ出力処理
 * onAction($submit)    フォーム送信後の処理
 *
 * Example 1. テンプレートにアサインしてページ表示
 *
 * </pre>
 * <code>
 * // ページ実行
 * class Admin_Index extends App_Page
 * {
 *     function onInit()
 *     {
 *         // $viewにアサインする変数
 *         $this->set('view', $view);
 *     }
 *
 *     function onOutput()
 *     {
 *         $this->display();
 *     }
 * }
 * new BEAR_Main('Admin_Index');
 * </code>
 *
 * Example 2. フォーム投稿
 *
 * <code>
 * // ページ実行
 * class Page_Register extends App_Page
 * {
 *     onAction($submit)
 *     {
 *         print "{$submit['name']}さんを登録しました";
 *         $this->display('admin/registered.tpl');
 *     }
 * }
 * BEAR_Main('Admin_Index');
 * </code>
 *
 * Example 3. initキャッシュ
 *
 * <code>
 * function onCache()
 * {
 *      function onCache{
 *          $config = array('key' => '', 'life'=>5);
 *          return $config;
 *      }
 * }
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Page
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Page.php 417 2008-07-02 12:03:30Z koriyama $
 * @abstract
 */
abstract class BEAR_Page
{

    /**
     * アクティブリンククエリーキー
     *
     */
    const ACTIVE_LINK_KEY = '_a';

    /**
     * 携帯サポート
     * 
     * SUPPORT_NONE 対応なし
     * SUPPORT_IMG 絵文字IMG対応
     * 
     * @todo SUPPORT_CONV
     * @todo SUPPORT_NO_EMOJI
     */
    const SUPPORT_NONE = 0;

    const SUPPORT_IMG = 1;

    const SUPPORT_CONV = 2;

    const MOBILE_SUBMIT_PASS = 0;

    const MOBILE_SUBMIT_ENTITY = 1;

    const MOBILE_SUBMIT_REMOVE_EMOJI = 2;

    /**
     * HTTP出力ヘッダー
     *
     * @var array
     */
    public static $headers;

    /**
     * Click名
     *
     * @var string
     */
    public static $onClick = null;

    /**
     * onInit()でSmartyアサインされた値
     *
     * @var array
     */
    public static $initValue = null;

    /**
     * 携帯サポート
     *
     * @var integer
     */
    protected $mobilSupport = self::SUPPORT_NONE;

    /**
     * Smartyオブジェクト
     *
     * 継承したPageクラスでfalseにするとSmartyを使用しません
     *
     * @var mixed
     */
    public static $smarty = null;

    /**
     * サブミット文字列を変換するか
     * 
     * @var bool
     */
    private static $submitConvert = false;

    private static $_codeFromMoble;

    private static $_convert3gcWebEncode = false;

    /**
     * ページキャッシュ
     *
     * @var string
     */
    private $_cache = array('use_cache' => false, 'headers' => null, 'html' => null);

    /**
     * AJAX QuickFormで使用
     *
     * @var array
     */
    private static $_formElement;

    /**
     * ページコンストラクタ
     *
     * <pre>Smarty,HTMLHTML_QuickFormオブジェクトをプロパティとして生成し、携帯端末からPOSTされた文字のコード、絵文字を処理します。
     * _BEAR_POST_CONVERTをtrueにしてるとsubmitされた文字が'UFT-8'エンコード文字列に変換されます。
     * query_methodプロパティがGETでクエリーがあるとき(count($_GET) > ))にはクエリー文字列も同様に変換されます。</pre>
     *
     * @return void
     * @param void
     */
    function __construct()
    {
        // smarty生成
        if (self::$smarty !== false) {
            //smartyオブジェクト生成
            self::$smarty = new BEAR_Smarty();
        }
        // PC/Mobile対応
        $this->_initMobileSupport(App::MOBILE_SUPPORT);
        // 入力文字を変換
        $hasPost = self::$submitConvert && count($_POST) > 0;
        $hasGet = self::$submitConvert && (BEAR_Form::$method == 'GET') && count($_GET) > 0;
        // 携帯UAで$_POST変換
        if (($hasPost || $hasGet) && !BEAR_Page::isAjaxRequest()) {
            if ($hasPost) {
                $_POST = $this->_mobileSubmit($_POST);
            }
            if ($hasGet) {
                $_GET = $this->_mobileSubmit($_GET);
            }
        }
    }

    /**
     * アプリケーション初期化
     *
     * アプリケーション共通イベント
     *
     * @param    void
     * @return   void
     * @access   public
     */
    public function onApp()
    {}

    /**
     * Ajaxリクエストのときにコールされます
     *
     * @todo 実装
     */
    public function onAjax()
    {}

    /**
     * アプリケーションがタイマー指定しているときにコールされます
     *
     * @todo 実装
     */
    public function onTimer($datetime)
    {}

    /**
     * $_GETクエリーが付けられたときにコールされます
     *
     * @todo 実装
     */
    public function onGet()
    {}

    /**
     * $_POSTがあるときにコールされます
     *
     * @todo 実装
     */
    public function onPost()
    {}

    /**
     * キャッシュ使用しているときにコールされます
     *
     */
    public function onCache()
    {}

    /**
     * セッションディストロイのときにコールされます
     *
     */
    public function onGarbageCollect()
    {}

    /**
     * ページ初期化
     *
     * ページの初期化を行います。onOutput()で出力させる変数を全て用意しsetします。<br/>
     * setした変数はキャッシュ可能です。
     *
     * @access   public
     * @abstract
     */
    public function onInit($args)
    {}

    /**
     * ページ表示
     *
     * <pre>onInit()で実行された後、フォーム送信されてない、またはバリデーションNGのときにコールされます</pre>
     *
     * @access   public
     * @abstract
     */
    public function onOutput()
    {
        $this->display();
    }

    /**
     * バリデーションOKの処理
     *
     * <pre>フォーム送信されバリデーションOKの場合にonInit()の後にコールされます</pre>
     *
     * @param    mixed  $submit フォーム送信
     * @return   bool
     * @access   public
     */
    public function onAction($submit)
    {
        unset($submit);
        trigger_error('action method is not implemented.', E_USER_WARNING);
    }

    /**
     * アクティブリンク追加
     *
     * アクティブリンクを追加します。リンクをクリックするとページの"on$eventName"がコールされます<br/>
     *
     * @param string $eventName
     * @param string $title
     * @todo AJAXオプション実装
     */
    protected function addActiveLink($eventName, $title, $isAjax = false)
    {
        static $alink;
        $get = $_GET;
        $get[self::ACTIVE_LINK_KEY] = $eventName;
        $alink[$eventName] = '<a href="?' . http_build_query($get) . '">' . $title . '</a>';
        self::$smarty->assign('alink', $alink);
    }

    /**
     * ページ出力
     *
     * <pre>指定したテンプレートをsmartyオブジェクトとquickformオブジェクトをアサインして画面出力します。
     * 画面出力の代わりにHTMLを文字列として取得する場合はfetch()メソッドを使用します。
     * 引数を省略するとページクラスからパスが生成されたテンプレートが使用されます
     *
     * Example.
     * MyBLog_Top_Newsクラスならmyblog/top/news.tpl
     * </pre>
     *
     * @param    string $tplName   テンプレートファイル名
     * @param    mixed  $values アサインする連想配列(BEARbバリュー)
     * @return   mixed
     * @access   public
     */
    protected function display($tplName = null, $options = null)
    {
        
        $path = $this->_getTemplateNameByPageClass($tplName); // ex) user.ceate.preview
        // mobile
        $path = (BEAR::$ua) ? $this->_getTemplateNameByMobile($path, BEAR::$ua) : $path;
        $matches = array();
        preg_match('/(.+?)[\.]/', $path, $matches);
        $firstWordForConfig = ($matches[0]) ? $matches[0] : $path . '.';
        $templatePath = 'pages/' . $path . '.tpl';
        $configFileHead = _BEAR_APP_HOME . '/App/views/pages/' . $firstWordForConfig;
        // 設定ファイル
        if (file_exists($configFileHead . 'yml')) {
            $configFile = $configFileHead . 'yml';
        } elseif (file_exists($configFileHead . 'ini')) {
            $configFile = $configFileHead . 'ini';
        } else {
            $configFile = false;
        }
        // yml,iniファ
        if (!$configFile) {
            BEAR_Smarty::$doEmojiOutputFilter = 1;
            $html = $this->fetch($templatePath);
        } else {
            $config = BEAR::values($configFile);
            $layoutValues = $config['default'];
            //携帯config
            if (isset($config['mobile']) && (BEAR::$ua != BEAR_Agent::UA_PC)) {
                $layoutValues = (is_array($layoutValues)) ? array_merge($layoutValues, $config['mobile']) : $config['mobile'];
            }
            if (is_array($options) && is_array($layoutValues) && is_array($config[$options['override']])) {
                $layoutValues = array_merge($layoutValues, $config[$options['override']]);
            }
            $this->set('layout', $layoutValues);
            if (isset($config['layout'])) {
                $contetForLayout = $this->fetch($templatePath);
                $this->set('content_for_layout', $contetForLayout);
                $layoutFile = 'layouts/' . $config['layout'];
                //モバイル用のレイアウトファイル
                if (BEAR::$ua != BEAR_Agent::UA_PC) {
                    $mobileLayoutNoExtention = $this->_removeExtention($layoutFile);
                    if (file_exists(_BEAR_APP_HOME . '/App/views/' . $mobileLayoutNoExtention . '.mobile.tpl')) {
                        $layoutFile = $mobileLayoutNoExtention . '.mobile.tpl';
                    }
                }
                BEAR_Smarty::$doEmojiOutputFilter = 1;
                $html = $this->fetch($layoutFile);
            }
        }
        $this->_output($html);
        // 使用テンプレートのログ
        $result = $this->onTemplateLog($tplName);
        if ($result !== false) {
            $display = array();
            $display['config'] = isset($configFile) ? $configFile : 'n/a';
            $display['page'] = $tplName;
            BEAR_Log::appLog('display', $display);
        }
    }

    /**
     * テンプレート名の取得
     * 
     * @param string $tplName テンプレート名（省略可）
     * @return array 
     *  +tpl テンプレートパス
     *  
     */
    private function _getTemplate($tplName = null)
    {
        $path = $this->_getTemplateNameByPageClass($tplName);
        // mobile
        $path = (BEAR::$ua) ? $this->_getTemplateNameByMobile($path, BEAR::$ua) : $path;
        return $path;
    }

    /**
     * ページクラスからパスを取得する
     * 
     * <pre>
     * /はじまりだと絶対パス、テンプレート名省略または相対パスならページクラスからパス名を組み立てる。
     * 相対パスでテンプレートを指定していれば指定したものにおきかわる。拡張子がのぞかれたものが返される。
     * 
     * 例
     * 絶対パス
     *  '/index.tpl'　=> '/index'
     *  '/some/index.tpl' => '/some/index'
     * 相対パス　Sample_Test_Pageクラスの場合
     *  '' =>　'sample/test/page'
     *  'help.tpl' => 'sample/test/help'
     *  'another/help.tpl' => 'sample/test/another/help'
     * </pre>
     * 
     * @param $tplName string
     * @param string
     */
    private function _getTemplateNameByPageClass($tplName)
    {
        // 絶対パス
        if (substr($tplName, 0, 1) == '/') {
            // 先頭の/を除いて返す
            $absPath = $this->_removeExtention($tplName);
            return substr($absPath, 1);
        }
        // 相対パスの場合はクラス名からベースパスを作成する
        $base = str_replace('_', '/', strtolower(get_class($this)));
        if ($tplName == null) {
            return $base;
        }
        $bodyTpl = $this->_removeExtention($tplName);
        //テンプレート名の指定があればページクラス名の相対パスで置換
        $result = ($tplName) ? preg_replace('/\/([\w]+)$/i', '/' . $bodyTpl, $base) : $base;
        return $result;
    }

    /**
     * ファイルの拡張子を除いたものを返します
     * 
     * @param $file 
     * @return string
     * 
     */
    private function _removeExtention($file)
    {
        $pathinfo = pathinfo($file);
        switch ($pathinfo['dirname']) {
            case '/' :
                $result = $pathinfo['filename'];
                break;
            case '.' :
                $result = $pathinfo['filename'];
                break;
            default :
                $result = $pathinfo['dirname'] . '/' . $pathinfo['filename'];
                break;
        }
        return $result;
    }

    /**
     * モバイルテンプレート名
     * 
     * index.tplに対してindex.mobile.tplという風に.mobile.というファイルが用意されていれば
     * モバイル用のテンプレート名を返します
     * 
     * @param string $file
     * @param string $ua
     * @return string 
     */
    private function _getTemplateNameByMobile($file, $ua)
    {
        //クリックメソッドの時はクリックテンプレート優先
        if ($ua == BEAR_Agent::UA_PC) {
            return $file;
        }
        if (file_exists(_BEAR_APP_HOME . '/App/views/pages/' . $file . '.mobile.tpl')) {
            $file = $file . '.mobile';
        }
        return $file;
    }

    /**
     * Smartyテンプレートに値をセットする
     * 
     * ここでsetされた値がSmartyテンプレートでアサインされる以外にinitキャッシュとして再利用することができます。
     * また他クラスからBEAR_Page::getInit($class, $args)としてInit値のみ取得することができます
     *
     * @param array|string $tplVar the template variable name(s)
     * @param mixed $value the value to assign
     * 
     * @todo cacheならBEAR_Page::$initValueに保存
     */
    protected function set($tplVar, $value)
    {
        self::$smarty->assign($tplVar, $value);
        BEAR_Page::$initValue[$tplVar] = $value;
    }

    /**
     * ページ文字列取得
     *
     * アサイン済みテンプレートのHTMLを文字列として取得します。
     *
     * @param string $tplName
     * @return string
     */
    protected 

    function fetch($tplName)
    {
        // プレフィックス付きテンプレートファイル優先
        // 無ければプレフィックス無しを使用
        $file = self::$smarty->template_dir . $tplName;
        if (!file_exists($file)) {
            //テンプレートファイルがない
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array(
                    'template_file' => $tplName), 'Template file is missing.（テンプレートファイルがありません)');
        }
        // フォーム
        if (BEAR_Form::hasInstance()) {
            $this->_renderForms();
        }
        $html = self::$smarty->fetch($file);
        return $html;
    }

    /**
     * http出力
     *
     * <pre>
     * HTTPヘッダーとコンテンツを出力します。
     * HTMLコンテンツ(text/html)やXMLコンテンツ(application/xml)などを
     * 出力します。出力バッファされているので実際に出力されるのはBEAR_Main::start()です。
     *
     *
     * Example 1. XML出力
     * </pre>
     * <code>
     * //XML出力
     * $option = array('header' => "Content-Type: application/xml");
     * $this->_output($contens, $option);
     * </code>
     *
     * Example 2. 複数ヘッダー出力
     *
     * <code>
     * $option[] = array('header' => "Content-Type: application/xml");
     * $option[] = array('x-hoge-time' => "{$time}");
     * $this->_output($contens, $option);
     * </code>
     *
     * @param string $body
     * @param array $option
     * @return mixed
     * @access private
     */
    private function _output($body, $headers = false)
    {
        // ヘッダーを出力
        BEAR_Page::header($headers);
        // ボディ出力
        echo $body;
    }

    /**
     * フォームレンダリング
     *
     * フォームをレンダリングします
     *
     * @param array $forms
     * @access private
     */
    private 

    function _renderForms()
    {
        $form = & BEAR_Form::getInstance();
        if (!is_array($form)) {
            //単数フォーム　
            $forms = array(
                    'form' => BEAR_Form::getInstance());
            $isSingleForm = true;
        } else {
            //複数フォーム
            $forms = BEAR_Form::getInstance();
            $isSingleForm = false;
        }
        $renderer = BEAR_Form::getRenderer();
        switch ($renderer) {
            case BEAR_Form::RENDERER_DHTML_TABLELESS :
                // DHTMLRulesTablelessレンダラ
                foreach($forms as $formName => $form) {
                    //単数フォーム
                    $renderer = & new HTML_QuickForm_Renderer_Tableless($form);
                    // onblur有効
                    $form->getValidationScript();
                    $form->accept($renderer);
                    // 完全なXHTML1.1に
                    $form->removeAttribute('name');
                    $formValue[$formName] = $renderer->toHtml();
                    $formErrors[$formName] = $form->getErrors();
                }
                $formValue = ($isSingleForm) ? $formValue['form'] : $formValue;
                $formErrors = ($isSingleForm) ? $formErrors['form'] : $formErrors;
                self::$smarty->assign('form', $formValue);
                self::$smarty->assign('form_errors', $formErrors);
                break;
            case BEAR_Form::RENDERER_SMARTY_ARRAY :
            default :
                // HTML_QuickForm_Renderer_ArraySmartyレンダラ
                foreach($forms as $formName => $form) {
                    //フォーム描画
                    $renderer = & new HTML_QuickForm_Renderer_ArraySmarty(self::$smarty);
                    $renderer->setRequiredTemplate(BEAR_Form::$require_template);
                    $renderer->setErrorTemplate(BEAR_Form::$error_template);
                    $form->accept($renderer);
                    //                    self::$smarty->assign($formName, $renderer->toArray());
                    $formValue[$formName] = $renderer->toArray();
                }
                $formValue = ($isSingleForm) ? $formValue['form'] : $formValue;
                self::$smarty->assign('form', $formValue);
                break;
        }
    }

    /**
     * ヘッダー出力
     *
     * <pre>ヘッダーを出力用にバッファリングします。引数は配列または文字列で指定できます。
     * スタティック変数として保存されBEAR_Mainで出力バッファをフラッシュする時に送出されます。
     * 同じ</pre>
     *
     * @param mixed $header
     * @return void
     * @access protected
     * @static
     */
    public 

    function header($header)
    {
        if (!$header) {
            return;
        }
        $header_ref = & PEAR::getStaticProperty('BEAR_Page', 'header');
        $static_header = $header_ref;
        if (!is_array($static_header)) {
            $static_header = array();
        }
        if (is_array($header)) {
            $static_header = array_merge($static_header, $header);
        } else {
            $static_header[] = $header;
        }
        $header_ref = $static_header;
    }

    /**
     * PC/モバイル両用の設定を行う
     *
     * <pre>以下の使用のWebアプリに設定を行います。
     *
     * 1)PCおよびSB/3GCはUTF-8出力その他携帯はSJIS
     * 2)スクリプトはUTF-8
     * 3)フォームから送られる$submitはUTF-8
     * 4)エージェントに応じたヘッダーを出力します</pre>
     *
     * @conf読み込みなどの機能を本当に必要になる直前に実行する
     *
     */
    private 

    function _initMobileSupport($mobileSupport)
    {
        if ($mobileSupport == self::SUPPORT_NONE) {
            return;
        }
        // 変換ON
        self::$submitConvert = true;
        // POSTエンコード変換コンバートスイッチ
        $bearAgent = BEAR_Agent::getInstance();
        BEAR::$ua = $bearAgent->getCarrierShortName();
        // ヘッダー
        $is3GC = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) && $bearAgent->isType3GC();
        if (BEAR_Agent::$isBot) {
            // Bot
            BEAR_Page::header('Content-Type: text/html; charset=Shift_JIS');
            
            self::$_codeFromMoble = 'SJIS-win';
            $this->set('charset', 'Shift_JIS');
        } elseif (BEAR::$ua == BEAR_Agent::UA_PC) {
            // PC
            BEAR_Page::header('Content-Type: text/html; charset=utf-8');
            $this->set('charset', 'utf-8');
        } elseif ($is3GC) {
            //3gc mobile
            BEAR_Page::header('Content-Type: text/html; charset=utf-8');
            self::$_codeFromMoble = 'SJIS-win';
            self::$_convert3gcWebEncode = true;
            $this->set('charset', 'Shift_JIS');
        } else {
            // Mobile General (Docomo/AU)
            BEAR_Page::header('Content-Type: application/xhtml+xml; charset=Shift_JIS');
            self::$_codeFromMoble = 'SJIS-win';
            $this->set('charset', 'Shift_JIS');
        }
        switch ($mobileSupport) {
            // 絵文字を表示できない時はイメージタグで表示
            case self::SUPPORT_IMG :
                // 絵文字出力アウトプットフィルター出力関数
                self::$smarty->register_outputfilter(array(
                        'BEAR_Smarty', 
                        'emojiOutputFilter'));
                break;
            case self::SUPPORT_CONV :
            case 2 :
            default :
                break;
        }
        // 絵文字エンティティconfig
        $emoji_config = _BEAR_BEAR_HOME . '/BEAR/smarty/config/emoji/' . BEAR::$ua . '/emoji.conf';
        self::$smarty->config_load($emoji_config);
    }

    /**
     * モバイルサブミット処理
     *
     * <pre>モバイル端末からの絵文字エンティティに変換、文字コード変換をします</pre>
     *
     * @param   void
     * @return  void
     */
    private function _mobileSubmit($input)
    {
        $bearAgent = BEAR_Agent::getInstance();
        $is3GC = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) && $bearAgent->agent->isType3GC();
        //SB絵文字WebCode変換
        if (BEAR::$ua == BEAR_Agent::UA_SOFTBANK && self::$_convert3gcWebEncode && $is3GC) {
            array_walk_recursive($input, array('Emoji', 
                    'callbackWebEncode'));
        }
        switch (self::$submitConvert) {
            // 何もしない
            case self::MOBILE_SUBMIT_PASS :
                break;
            // 絵文字除去
            case self::MOBILE_SUBMIT_REMOVE_EMOJI :
                array_walk_recursive($input, array(
                        'BEAR_Emoji', 
                        'removeEmoji'));
                $_POST = $input;
                break;
            // 絵文字をエンティティに変換
            case self::MOBILE_SUBMIT_ENTITY :
                //3GCsエンコード変換必須
                if (BEAR::$ua == BEAR_Agent::UA_DOCOMO || BEAR::$ua == BEAR_Agent::UA_AU) {
                    array_walk_recursive($input, array(
                            'BEAR_Emoji', 
                            'callbackEntityEmoji'));
                }
                break;
            default :
                trigger_error('Illigal App::MOBILE_SUPPORT error', E_USER_WARNING);
                break;
        }
        // UTF8に文字コード変換
        if (self::$_codeFromMoble && BEAR::$ua != BEAR_Agent::UA_PC && (self::$_convert3gcWebEncode == false)) {
            $input = BEAR_Data::convertEncoding($input, 'UTF-8', self::$_codeFromMoble);
        }
        return $input;
    }

    /**
     * AJAXリクエストか返す
     * 
     * @return 
     */
    public function isAjaxRequest()
    {
        return false;
    }

    /**
     * リダイレクト
     *
     * <pre>Locationヘッダーを用いてページの移動を行います。
     * クッキーが対応してないエージェントの場合はクエリーにセッションIDを付加します。
     * .(dot)を指定すると同一ページのリフレッシュになります。
     * ページが完全に移動した場合は$config['permanent']をtrueにすると301ヘッダーを付加してリダイレクトしボットなどに移転を知らせます。
     *
     * -----------------------------------------
     *
     * Example 1. リダイレクト
     * </pre>
     * <code>
     *  BEAR_Page::redirect('http://www.example.co.jp/');
     * </code>
     * <pre>
     * Example 2. リダイレクト（301 パーマネント)
     * </pre<
     * <code>
     * BEAR_Page::redirect('/', array('permanent'=>true));
     * </code>
     * <pre>
     * Example 2. リロード
     * </pre<
     * <code>
     * BEAR_Page::redirect('.');
     * </code>
     *
     * @param string $url
     * @param bool   $session
     *
     * @author      koriyama
     * @version     $Id: BEAR_Page.php 417 2008-07-02 12:03:30Z koriyama $
     * @since       Tue Sep 20 11:17:42 GMT+09:00 2005
     * @param       string $url
     * @return      void
     */
    public static function redirect($url, $options = array('session'=>true, 'permanent'=>false))
    {
        // .なら現在のファイル
        if ($url == '.' || $url == './') {
            $url = $_SERVER['PHP_SELF'];
        }
        // 相対パスならフルパスに変換
        $remote_addr = $_SERVER["HTTP_HOST"];
        if (strpos($url, "http") === false) {
            if ($_SERVER['HTTPS'] == 'on') {
                $url = "https://{$remote_addr}$url";
            } else {
                $url = "http://{$remote_addr}$url";
            }
        }
        // 携帯の場合などクッキーが使用できない環境ではセッションクエリーをURLに付加
        $session_name = session_name();
        $session_id = session_id();
        if (!isset($_COOKIE[$session_name]) && $session_id && isset($options['session']) && $options['session']) {
            // セッションクエリーが付いてれば消去
            //        $url = preg_replace("/&*{$session_name}=[^&]+/is", '', $url);
            $url = preg_replace("/([&\\?]){$session_name}=[^&]?/is", '$1', $url);
            $con = (strpos($url, "?")) ? '&' : '?';
            $url .= "{$con}{$session_name}={$session_id}";
            if (strlen($session_id) != 32) {
                trigger_error('session key error' . $url, E_USER_WARNING);
            }
        }
        BEAR_Log::appLog('Redirect', "Location:{$url}");
        if (isset($options['permanent']) && $options['permanent']) {
            header("HTTP/1.1 301 Moved Permanently");
        }
        //　ロケーションヘッダー出力
        header("Location:{$url}");
        exit();
    }
}
<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Main
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * ページ実行クラス
 *
 * <pre>
 * App_Pageの継承クラスで作られたページオブジェクトを実行します。
 * ページに実装されたメソッドを決められた順に実行します。ページメソッドには
 * App_Authで返された認証値($auth)が渡されます。またPOSTされたデータは
 * バリデーションチェックを通過しactionメソッドへ認証値と共に$submitとしてわたされます。
 * $submitにはPOSTトークンが付加され、二重送信防止処理とクロススクリプトサイトフォージェリー対策に
 * 使われます。外部サイトからのPOSTなどのアクセスは不正処理とみなし、$submitにはPEARエラーオブジェクトが
 * 代入されます。
 *
 * 以下のページメソッドを順に実行します。
 *
 * onApp()         アプリケーション初期化
 * auth()                    認証
 * onInit()                    初期化
 *
 * onOutput()                  上記の何れかでfalseが出た場合
 * または
 * onAction()                  POSTされたデータがあり、フォームバリデーションOKの場合
 *
 * onOutput()は通常自ページを表示に使用します。
 * onAction()は通常POSTされたデータでアクションをコールします。
 *
 * Example 1.キャッシュページの実行
 * </pre>
 * <code>
 * class Toppage extends App_Page{
 * }
 * new BEAR_Main("Toppage", false, 600);
 * //10分間のページキャッシュ
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Main
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Main.php 417 2008-07-02 12:03:30Z koriyama $
 */
class BEAR_Main
{

    /**
     * 最終出力
     *
     * @var unknown_type
     */
    public static $contents;

    /**
     * ページインスタンス
     *
     * @var object App_Page
     */
    public static $page = null;

    /**
     * セッション自動スタートスイッチ
     *
     * @var boolean
     * @access private
     */
    private $_session_auto_start = true;

    /**
     * キャッシュオプション
     * $_cache['life_time'] キャッシュ時間
     * $_cache['cache_id']        キャッシュID
     *
     * @var mixed
     * @access private
     */
    private $_cache = false;

    /**
     * タイマー開始時間
     *
     * デバックモードの時の時間計測表示用
     *
     * @var float
     * @access private
     */
    private static $_start_time;

    /**
     * サブミット値
     *
     * $_POSTか$_GETの内容が入ります
     * BEAR_Page::queryMethodプロパティの設定に依存します
     *
     * @var mixed
     * @access private
     */
    private $_submit = false;

    /**
     * コンストラクタ
     *
     * @param    string   $pageClass    ページクラス名
     * @return   void
     * @access   public
     */
    /**
     * コンストラクタ
     * 
     * 受け取ったページオブジェクトを実行します。<var>$lifeTime</var><pre>でページ全体のキャッシュ時間が指定できます。
     * （デフォルトは0=キャッシュしない）キャッシュのIDはURLとBEAR::$ua(PC,キャリア）で決まります。
     * 
     * ページ内から別のページを生成するために</pre><var>$new_page</var>ページオプションがあります。デフォルトのfalseの場合は
     * ページファイルを実行しないクラスファイルとして使用できるようになります
     *
     * @param App_Page $page_instance
     * @param int $lifeTime sec
     * @param bool $new_page true=new page | false=do not start()
     */
    function __construct($pageClass, $lifeTime = 0, $new_page = false)
    {
        if (!self::$page || ($new_page == true)) {
            // ページクラス存在チェック
            if (!$pageClass || class_exists($pageClass)) {
                PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('page_class' => $pageClass), 'Page class is not defined.（ページクラスが定義されていません)');
            }
            // フォーム初期化
            BEAR_Form::init();
            // ページ生成、実行
            self::$page = new $pageClass();
            if ($cash_time != 0) {
                $this->_cache['cache_id'] = md5($_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . BEAR::$ua);
                $this->_cache['life_time'] = $lifeTime;
            }
            $this->start();
        } else {
            BEAR_Log::appLog("Page Include", $pageClass);
        }
    }

    /**
     * ページキャッシュ使用
     *
     * <pre>ページ全体をキャッシュします。部分的に変更のあるコンテンツには使えません</pre>
     *
     * @param int $life_time　キャッシュ時間
     * @param mixed $cache_id　キャッシュID
     * @return void
     */
    function useCache($life_time, $cache_id = false)
    {
        $cache_id = ($cache_id) ? $cache_id : md5($_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'] . BEAR::$ua);
        $this->_cache['cache_id'] = $cache_id;
        $this->_cache['life_time'] = $life_time;
    }

    /**
     * セッションオートスタートセット
     *
     * @param bool $auto_start
     * @return void
     * @access public
     */
    function setSessionAutoStart($auto_start = true)
    {
        $this->_session_auto_start = $auto_start;
    }

    /**
     * ページ開始
     *
     * <pre>App_Pageクラスを継承して定義されたページを実行します。</pre>
     *
     * @todo    クロスサイトトスクリプトフォージェリー対策用IDの埋め込み
     * @param    String  $pageClass    ページクラス名
     * @return   void
     */
    function start()
    {
        if (App::$debug){
            // タイマー初期化
            self::$_start_time = microtime(true);
            BEAR_Log::appLog('start', array('URI'=>$_SERVER['REQUEST_URI'], 'time'=>date('r')));
        }
        BEAR_Session::start();
        // PHPバッファスタート
        ob_start();
        // エラー初期化
        BEAR_Error::init();
        // ページキャッシュ読み込み（キャッシュフラグ、またはクエリーで無効）
        $this->_cache = is_array($this->_cache) && App::$useCache && $this->_cache;
        $cached_html = is_array($this->_cache) ? $this->_readPageCache() : false;
        // キャッシュヒットェック
        if ($cached_html) {
            echo $cached_html;
            $this->_endPage();
            return;
        }
        $page = & self::$page;
        // 初期化
        if ($this->_cache) {
            self::$page->_cache['use_cache'] = true;
        }
        // onClick
        if (isset($_GET[BEAR_Page::ACTIVE_LINK_KEY]) && method_exists(self::$page, $on_method = 'onClick' . $_GET[BEAR_Page::ACTIVE_LINK_KEY])) {
            $result = self::$page->$on_method();
            BEAR_Page::$onClick = $_GET[BEAR_Page::ACTIVE_LINK_KEY];
            if ($result === false) {
                BEAR_Log::appLog('Terminated', "$on_method returns false");
                $this->_endPage();
                return;
            }
        }
        // onInit()
        //        $this->_get_args = ($_GET) ? $this->_getArgs() : array();
        $this->_get_args = ($_GET) ? $_GET : array();
        $init_result = self::$page->onInit($this->_get_args);
        //        echo 1;exit();
        if (isset($init_result) && $init_result === false) {
            BEAR_Log::appLog('Terminated', 'onInit returns false');
            $this->_endPage();
            return;
        }
        // submit ?
        $is_single_form = !is_array(BEAR_Form::$form);
        $this->_submit = count($_POST) > 0 ? $_POST : $_GET;
        $has_submit = ($this->_submit != false) ? true : false;
        // onOutput()
        if (!$has_submit) {
            self::$page->onOutput();
            $this->_endPage();
            return;
        }
        // form作成
        if ($is_single_form) {
            $form = & BEAR_Form::getInstance();
            $formName = 'form';
        } else {
            $formName = $this->_getSubmitFormName(self::$page);
            $multiForm = BEAR_Form::getInstance();
            $form = $multiForm[$formName];
        }
        // submitバリデーション
        if ($form->validate()) {
            // submit OK
            self::$page->is_ajax_submit = $this->isAjaxToken($this->_submit['_token']);
            if (self::$page->is_ajax_submit) {
                $this->_ajaxValidationOK($form);
            } else {
                $this->_formValidationOK($form, $formName);
            }
        } else {
            // submit NG
            BEAR_Log::appLog('Submit NG', array('Submit' => $form->_submitValues, 'Rules' => $form->_rules, 'Errors' => $form->_errors));
            if ($this->isAjaxToken($this->_submit['_token'])) {
                // AJAXバリデーションNG]
                $this->_ajaxValidationNG($form);
            } else {
                self::$page->onOutput();
            }
        }
        //end
        $this->_endPage();
    }

    /**
     * ページ終了処理
     * 
     * ヘッダーとコンテンツを出力して終了します。
     * start内からのみコールされます
     *
     * @access private
     */
    private function _endPage()
    {
        BEAR_Main::$contents = ob_get_contents();
        // ページキャッシュ書き込み
        if (is_array($this->_cache)) {
            $this->_writePageCache(BEAR_Main::$contents);
        }
        // ヘッダー出力
        $this->outputHeader();
        // ページ出力
        ob_end_flush();
        // 終了
        BEAR_Main::end(false);
    }

    /**
     * BEAR_Page::onInit()に渡す引数を作成
     *
     * @param array $get
     * @return array
     */
    private function _getArgs()
    {
        foreach($_GET as $key => $value) {
            $args[$key] = rawurldecode($value);
        }
        return $args;
    }

    /**
     * ページキャッシュの読み込み
     *
     * <pre>ページキャッシュが存在すれば返す。
     * ヘッダーがあればスタティックプロパティへ保存（BEAR_Page::headers)
     * </pre>
     *
     * @param void
     * @return void
     * @access private
     *
     */
    function _readPageCache()
    {
        //キャッシュ初期化
        $cache_id = $this->_cache['cache_id'];
        $cache = $this->_getCacheInstance();
        $pageCache = $cache->get($cache_id);
        $headers = $pageCache[0];
        $html = $pageCache[1];
        if ($html) {
            $result = $html;
            // ログ
            BEAR_Log::appLog('Page Cache [R]', array('ID' => $cache_id, "Cache Time" => $this->_cache['life_time']));
            /**
             * ヘッダーがあれば格納
             */
            if ($headers) {
                BEAR_Page::$headers = $headers;
            }
        } else {
            $result = false;
        }
        return $result;
    }

    /**
     * ページキャッシュ書き込み
     *
     * ヘッダーとコンテンツをキャッシュに保存
     *
     * @param string $html
     * @return void
     * @access private
     */
    function _writePageCache($html)
    {
        $cache = $this->_getCacheInstance();
        $headers = BEAR_Page::$headers;
        $cache->save(array($headers, $html), $this->_cache['cache_id']);
        BEAR_Log::appLog('Page Cache[W]', $this->_cache);
    }

    /**
     * ページクラス名取得
     *
     * <pre>
     * マルチページの場合、$_GET['_p']または$_GET['_p']が
     * ページクラス名として使用される。どちらも指定が無いときは
     * start()メソッドで使用されたページクラス名を返す（最初のページ）
     *
     *
     * 詳細:
     *　$_GET['_p']は$_POST['_p']より優先される
     *  $_GET['_p']はBEAR_Mulit_Page::locationで付与されるもの（ページの移動）
     *  $_POST['_p']はhiddenフォームで埋め込まれてるもの（ページのリロードやバリデーションNG）
     *
     * </pre>
     *
     * @param string $pageClass
     * @return boid
     * @access private
     */
    function _getPageClassName($pageClass)
    {
        /**
         * マルチページチェック
         * hiddenフォームに$_POSTか$_GETに_p変数（ページクラス指定変数）が
         * 存在するとその名前を実行ページクラスとして扱う
         */
        $getP = isset($_GET['_p']) ? $_GET['_p'] : false;
        $postP = isset($_POST['_p']) ? $_POST['_p'] : false;
        if ($getP) {
            $pageClassName = $getP;
        } elseif ($postP) {
            $pageClassName = $postP;
        } else {
            $pageClassName = $pageClass;
        }
        if (class_exists($pageClassName)) {
            //ページクラス決定
            BEAR_Log::appLog("Page Class", $pageClassName);
        } else {
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, 0, 'error', array('page class name' => $pageClassName), 'Undefined Page Class（ページクラスがありません）');
        }
        return $pageClassName;
    }

    /**
     * TokenがAJAXのものか検査
     *
     * @param string $token
     * @return bool
     */
    function isAjaxToken($token)
    {
        $ajax_token = BEAR_Form::makeToken(true);
        $result = ($token == $ajax_token) ? true : false;
        return $result;
    }

    /**
     * トークン有効チェック
     *
     * @param string $token
     * @return bool
     */
    function isTokenValid($token)
    {
        $md5short = substr($token, 1, 12);
        $tokenCheckSum = substr($token, 13, 2);
        $genuineCheckSum = substr(md5(hexdec($md5short) * 5 - 1), 0, 2);
        $result = ($tokenCheckSum == $genuineCheckSum) ? true : false;
        BEAR_Log::appLog('Token Status', $result ? "Secure" : "Unsecure");
        return $result;
    }

    /**
     * Submitされたフォームの名前を取得
     *
     * @param object $page
     * @return string
     * @access private
     */
    function _getSubmitFormName()
    {
        foreach($this->_submit as $post_name => $postValue) {
            if (preg_match('/^_qf__(.+)/', $post_name, $match) > 0) {
                $formName = $match[1];
                break;
            }
        }
        assert(is_string($formName));
        return $formName;
    }

    /**
     * フォームバリデーションOK
     *
     * トークンの検査を行い不正アクセスでなければonActionメソッドの引数に
     * POSTされたデータを与えてコールする。
     *
     * @param object $form
     * @param object $page
     * @return void
     * @access private
     */
    function _formValidationOk($form, $formName = null)
    {
        BEAR_Form::$submitValue = $submit = $form->exportValues();
        BEAR_Form::$exportValue = $form->getSubmitValues();
        BEAR_Log::appLog('Submit OK', $submit);
        /**
         * HTML_QuickForm::exportValues()
         * 
         * getSubmitValues()  とは異なり、この関数は フォームに追加された  要素に対応する値で実際に送信されたもののみを返します。 
         * 'はい'/'いいえ' を選択するラジオボタンがあった場合、'たぶん' は有効な送信値とはみなされません。
         * また、このメソッドでは file 要素の値を取得することもできません。
         * 
         * @todo getSubmitValuesに変更できる機能
         */
        // アンダースコア始まりのsubmitを消去
        foreach($submit as $submitKey => $value) {
            if (substr($submitKey, 0, 1) == '_') {
                unset($submit[$submitKey]);
            }
            if ($value === null) {
                $submit[$submitKey] = '';
            }
        }
        $actionMethodName = 'onAction' . $formName;
        self::$page->onAction($submit);
        //複数フォームの時にフォーム名を付加したアクションメソッドがあれば追加でコール
        if (method_exists(self::$page, 'onAction' . $formName)) {
            // onAction.フォーム名() コール
            self::$page->$actionMethodName($submit);
        }
    }

    /**
     * Mainクラスでのデバック用表示
     *
     * @param object $this  ページオブジェクト
     * @return void
     * @static
     */
    function showDebugInfo()
    {
        // 時間表示
        $endLog = array();
        $endLog['peak memory'] = (function_exists('memory_get_peak_usage')) ? number_format(memory_get_peak_usage(true)) : 'n/a';
        if (App::$debug) {
            $endLog['time'] = (self::$_start_time != 0) ? microtime(true) - self::$_start_time : 'n/a';
            //コンパイルオプション依存
        }
        BEAR_Log::appLog('End', $endLog);
        if (!App::$debug) {
            return;
        }
        //デバック用HTML表示
        BEAR_Log::displayScreenLog();
    }

    /**
     * ページ終了
     *
     * スタティックコールでデバック情報を表示してBEARを終了します
     *
     * @static 　
     * @internal ヘッダー出力はまだされてない場合のみされます
     */
    function end($exit = true)
    {
        // デバック情報
        if (App::$debug) {
            BEAR_Main::showDebugInfo();
        }
        //　ヘッダー出力
        //　BEAR_Mainではない直接コールの場合のみ
        BEAR_Main::outputHeader();
        if ($exit) {
            exit();
        }
    }

    /**
     * ヘッダー出力
     *
     * <pre>BEAR_Page::header()でバッファされていたヘッダーが出力されます
     * ページキャッシュ等に利用されます。
     * </pre>
     *
     * @param void
     * @return  void
     * @static
     *
     */
    function outputHeader()
    {
        static $hasOut = false;
        if (BEAR_Page::$headers && !$hasOut) {
            //出力フラグON
            $hasOut = true;
            //ヘッダー出力
            BEAR_Log::appLog('Header', BEAR_Page::$headers);
            foreach(BEAR_Page::$headers as $header) {
                //同じヘッダーは上書きされる
                header($header, true);
            }
        }
    }

    /**
     * AJAXフォームでバリデーションNG
     *
     * エラーフォームエレメント名とエラーメッセージの連想配列をJSONで返す
     *
     * @param  object
     * @return void
     * @access private
     *
     */
    function _ajaxValidationNG($form)
    {
        /**
         * ルール
         */
        foreach($form->_rules as $key => $value) {
            $rule_keys[] = $key;
        }
        $ajaxErrorResult = array('quickform' => array('form_id' => $form->_attributes['id'], 'rules' => $rule_keys, 'errors' => $form->_errors));
        print_b($ajaxErrorResult);
        $page->outputData('json', $ajaxErrorResult);
    }

    /**
     * AJAXフォームでバリデーションOK
     *
     * フォームエレメント名をJSONで返す
     *
     * @param   object
     * @return  void
     * @access  protected
     *
     */
    function _ajaxValidationOk($form)
    {
        // ルール
        foreach($form->_rules as $key => $value) {
            $rule_keys[] = $key;
        }
        BEAR_Page::$form_element = array('quickform' => array('form_id' => $form->_attributes['id'], 'rules' => $rule_keys));
    }
}

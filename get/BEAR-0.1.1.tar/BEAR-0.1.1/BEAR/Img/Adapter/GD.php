<?php
/**
 * BEAR
 *
 * @package BEAR
 * @subpackage class
 */

/**
 * GDクラス
 *
 * 画像ライブラリGDを取り扱うクラスです。
 *
 * @package      BEAR
 * @subpackage   class
 * @author       koriyama
 * @version      $Id: BEAR_Img_GD.php 286 2008-06-03 17:37:42Z akihito $
 * @since        Thu Aug 09 17:34:49 GMT+09:00 2007
 */
class BEAR_Img_Adapter_GD extends BEAR_Img_Adapter
{

    /**
     * コンストラクタ
     *
     */
    function __construct()
    {
        //make sure the GD library is installed
        if(!function_exists("gd_info")) {
            trigger_error('Error: You need GD Library', E_ERROR);
        }
        $bear_img = BEAR_Img::getInstance();
        $this->bear_img = $bear_img;
    }

    /**
     * ファイルのロード
     *
     * <pre>$fileにはローカルファイルのパスまたはリモートファイルのURLを指定します。
     * リモートファイルの読み込みにはphp.iniでallow_url_fopen =Onの設定が必要です。</pre>
     *
     * @param string $file
     */
    public function load($file)
    {
        assert(is_string($file));
        $this->file = $file;
        //check if gif
        if(stristr(strtolower($this->file),'.gif')){
            $this->format = 'gif';
        }
        //check if jpg
        elseif(stristr(strtolower($this->file),'.jpg') || stristr(strtolower($this->file),'.jpeg')){
            $this->format = 'jpeg';
        }
        //check if png
        elseif(stristr(strtolower($this->file),'.png')){
            $this->format = 'png';
            //unknown file format
        } else {
            trigger_error('Unknown file format', E_USER_WARNING);
        }
        //
        // イメージリソース作成
        //
        assert(is_string($this->format));
        switch($this->format) {
            case 'gif':
                $this->image_rsc = imagecreatefromgif($this->file);
                break;
            case 'jpeg':
                $this->image_rsc = imagecreatefromjpeg($this->file);
                break;
            case 'png':
                $this->image_rsc = imagecreatefrompng($this->file);
                break;
        }        list($width, $height, $type, $attr) = $size = getimagesize($this->file);
        //        print_a($size);
        $this->src_width = $width;
        $this->src_height = $height;
        $this->src_type = $type;
        $this->src_attr = $attr;
    }

    /**
     * DBから画像の読み込み
     *
     * <pre>BLOBに格納したイメージをDBから読み取ります。</pre>
     *
     * @param string $dsn
     * @param string $id
     */
    public function loadDB($dsn, $key, $bear_img_select_mode=BEAR_IMG_SELECTMODE_ID)
    {
//        $table_name = $this->table_name;
//        $query_info = "SELECT
//`bear_img`.`tag3`,
//`bear_img`.`tag2`,
//`bear_img`.`tag1`,
//`bear_img`.`etag`,
//`bear_img`.`format`,
//`bear_img`.`status`,
//`bear_img`.`update_time`,
//`bear_img`.`insert_time`,
//`bear_img`.`name`,
//`bear_img`.`id`
//FROM
//`bear_img`
// WHERE id = ?";
//        if ($bear_img_select_mode == BEAR_IMG_SELECTMODE_ID){
//            $query_img = "SELECT image FROM {$table_name} WHERE id = ? INTO DUMPFILE ?";
//        } else {
//            $query_img = "SELECT image FROM {$table_name} WHERE etag = ? INTO DUMPFILE ?";
//        }
//        require_once 'DB.php';
//        $db = DB::connect($dsn);
//        if (!PEAR::isError($db)){
//            $result_info = $db->getRow($query_info, array($key), DB_FETCHMODE_ASSOC);
//            BEAR_Log::appLog('IMG', $result);
//            $this->_format = $result_info['format'];
//            $this->_insert_time = $result_info['insert_time'];
//            $this->_update_time = $result_infols['update_time'];
//            $tmp_file = BEAR_IMG_TMP_DIR.'tmp_db_img_'.(md5(uniqid((isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : ''), true)));
//            $tmp_file .= ".{$this->_format}";
//            $result_img = $db->query($query_img,array($key, $tmp_file));
//            if (PEAR::isError($result)){
//                print_a($result);
//            }
//            $this->load($tmp_file);
//            //テンポラリーファイルはデスクトラクタで消去
//            if ($is_temporary){
//                $this->_delete_files[] = $tmp_file;
//            }
//        } else {
//            trigger_error('Image db error', E_ERROR);
//        }
    }

    /**
     * 画像のリサイズ
     *
     * 画像を横幅に合わせてリサイズします
     *
     * @param int $width
     * @param int $height
     */
//    public function resize($width=false, $height=false, $no_bigger=false) {
    public function resize($width=false) {
        if ($no_bigger && ($width &&  $width > $this->src_width) || ($height && $height > $this->src_height)){
            return ;
        }
        if (!$width && !$height || $this->src_width == $width && $this->src_height == $height){
            //大きさの変化がないときあるいは指定が無いときはなにもしない
            return;
        }elseif (!$height){
            //高さの指定が無いときは幅に合わせる
            $height = $this->src_height * ($width / $this->src_width);
        } elseif (!$width){
            //幅の指定が無いときは高さにあわせる
            $width = $this->src_width * ($height / $this->src_height);
        }
        $dst_im = imagecreatetruecolor($width, $height);
        imagealphablending($dst_im, false);
        imagesavealpha($dst_im, true);
        imagecopyresampled($dst_im, $this->image_rsc, 0, 0, 0, 0, $width, $height, $this->src_width, $this->src_height);
        $this->image_rsc = $dst_im;
        $this->new_width = $width;
        $this->new_height = $height;
    }

    /**
     * 画像表示
     *
     * ヘッダーと画像をhttp出力します。
     *
     * @param string $file_location     画像ファイルの場所(URL or fileパス)
     * @param string $width             画像の幅
     */
    public function show($format=false){
        if (!$format){
            $format = $this->format;
        } else {
            $format = strtolower($format);
        }
        switch($format) {
            case 'gif':
                $this->result = imagegif($this->image_rsc);
                break;
            case 'jpg':
            case 'jpeg':
                $this->result = imagejpeg($this->image_rsc);
                $format = 'jpeg';
                break;
            case 'png':
                $this->result = imagepng($this->image_rsc);
                break;
        }
        header('Content-Type: image/'.$format);
    }

    /**
     * 画像保存
     *
     * <pre>指定のフォーマットで画像をファイル保存します。
     * $is_temporaryがtrueの時は、ページ表示終了時にファイルを消去します。テンポラリーファイルの保存のときに使用します。
     * </pre>
     *
     * @param string $format     画像ファイルのフォーマット
     * @param string $file_path  保存画像のファイルパス
     */
    public function save($file_path, $format=false, $is_temporary=false){
        if ($is_temporary){
            $this->_delete_files[] = $file_path;
        }
        if (!$format){
            $format = $this->format;
        } else {
            $format = strtolower($format);
        }
        switch($format) {
            case 'gif':
                imagegif($this->image_rsc, $file_path);
                break;
            case 'jpg':
            case 'jpeg':
                imagejpeg($this->image_rsc, $file_path);
                $format = 'jpeg';
                break;
            case 'png':
                imagepng($this->image_rsc, $file_path);
                break;
        }
    }
}
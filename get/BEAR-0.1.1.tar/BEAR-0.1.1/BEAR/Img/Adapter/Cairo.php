<?php
/**
 * BEAR
 *
 * @package BEAR
 * @subpackage class
 */

/**
 * テキスト左寄せ
 *
 */
define('_BEAR_ALIGN_LEFT', 0);

/**
 * テキストセンタリング
 *
 */
define('_BEAR_ALIGN_CENTER', 1);

/**
 * テキスト右寄せ
 *
 */
define('_BEAR_ALIGN_RIGHT', 2);

/**
 * イメージ抽象クラス
 */
require_once('BEAR/class/BEAR_Img.php');

/**
 * Cairoクラス
 *
 * <pre>PECLのCairo Wrapperをサポートするクラスです
 *
 * Example 1. 画像のリサイズ表示
 * </pre>
 *
 * <code>
 *  $bear_img = BEAR_Img::getInstance();
 *  $img = $bear_img->factory('Magick');
 *  $img->load(LOCAL_IMG_FILE);
 *  //$img->load(REOMOTE_IMG_FILE);         //http://ではじまるリモートファイルも可
 *  $img->resize(30);
 *  $img->show
 * </code>
 *
 * Example 2. 画像とテキストを合成してiMagickを使用してJPEG表示
 *
 * <code>
 *      //ローカルファイルの取得
 *      $bear_img = BEAR_Img::getInstance();
 *      $img = $bear_img->factory('Cairo');
 *      $img->load(LOCAL_IMG_FILE);
 *      $text1 = date(DATE_RFC822);;
 *      $x = $y = 0;
 *      $size = 18;
 *      $img->addText($text1, $x , $y, 'mikachan', $size, _BEAR_ALIGN_RIGHT);
 *      //$img->show();exit(); // PNGで表示
 *      // JPEGで表示のためにMagick使用
 *       $tmp_file = $img->getTmpFileName();
 *       $img->save($tmp_file);
 *       $img = $bear_img->factory('Magick');
 *       $img->load($tmp_file);
 *       imagick_convert($img->image, 'JPEG');
 *       $img->resizeMobile();
 *       //$img->resize(200);
 *       $img->show();
 * </code>
 *
 * Example 3. キャッシュDBを利用
 *
 * <code>
 *      //ローカルファイルの取得
 *       $bear_img = BEAR_Img::getInstance();
 *       $img = $bear_img->factory('Magick');
 *       $name = "testCacheShow";
 *       $size = 99;
 *       $cache_id = $name.$size;
 *       $has_cache = $img->hasCache($cache_id);
 *       if (!$has_cache){
 *           $img->load(REMOTE_IMG_FILE);
 * //            $img->load(LOCAL_IMG_FILE);
 *           $img->resize($size);
 * //                        $img->show();
 *       }
 *       $img->showCache($cache_id);
 * </code>
 *
 *
 * @package      BEAR
 * @subpackage class
 * @author       koriyama
 * @version      $Id: BEAR_Img_Cairo.php 320 2008-06-22 19:41:58Z koriyama $
 * @since        Mon Aug 06 11:06:33 GMT+09:00 2007
 */
class BEAR_Img_Cairo extends BEAR_Img_abst
{

	/**
	 * Cairoサーフェイス
	 *
	 * @var resource
	 */
    public  $surface;
    
    /**
     * フォント情報
     *
     * @var unknown_type
     */
    public $font_info;

    /**
     * コンストラクタ
     *
     */
    public function __construct()
    {
        //インストールチェック
        if(!function_exists("cairo_create")) {
            trigger_error('Error: You need Cairo Library', E_ERROR);
            exit;
        }
    }

    /**
     * ファイルのロード
     *
     * <pre>$fileにはローカルファイルのパスまたはリモートファイルのURLを指定します。
     * リモートファイルの読み込みにはphp.iniでallow_url_fopen =Onの設定が必要です。</pre>
     *
     * @param string $file
     */
    public function load($file)
    {
        //拡張子はpngチェック
        $info = pathinfo($file);
        $ext = $info['extension'];
        if (strtolower($ext) != 'png'){
            $this->error('load', "file ext is wrong, file=[{$file}]");
        }
        $this->file = $file;
        $tmp_file = $this->loadRemoteFile($file);
        $this->getImageInfo();
        BEAR_Log::appLog('$tmp_file', $tmp_file);
        $this->surface = cairo_image_surface_create_from_png($tmp_file) ;
        if (!is_resource($this->surface)){
            $file_size = (file_exists($file)) ? filesize($file) : 'none';
            $this->error("load",  "cairo_image_surface_create_from_png filse_size=[{$file_size}] file=[{$file}] ");
        }
        $this->image = cairo_create($this->surface);
        if (!is_resource($this->image)){
            $this->error('load',  'cairo_create');
        }
        cairo_paint_with_alpha($this->image, 0);
        //        print_b($this->image);exit();
    }

    /**
     * 画像のリサイズ
     *
     * cairo_scaleを使って画像をリサイズします。
     *
     * @param int $width
     * @param int $height
     */
    public function resize($size) {
        cairo_scale($this->image, 2, 2);
    }

    /**
     * 画像を合成
     *
     * <pre>画像ファイル(PNG)を合成します</pre>
     *
     * @param string $file
     * @param int $x
     * @param int $y
     * @param float $alpha (0..1)
     */
    public function addImage($file, $x=0, $y=0, $alpha=1.0){
        $file = $this->loadRemoteFile($file);
        $surfce = cairo_image_surface_create_from_png($file);
        cairo_set_source_surface($this->image, $surfce, $x, $y);
        cairo_paint_with_alpha($this->image, $alpha);
    }

    /**
     * テキストを合成
     *
     * <pre>指定位置にテキストを追加します。$alignに右寄せ（_BEAR_ALIGN_RIGHT)を指定すると
     * $xは右からのスペースになります。fontはターミナルでfc-listで得られるフォントの名前を
     * 使用します。イタリックは$slantにCAIRO_FONT_SLANT_ITALIC, ボールドは$weightに
     * CAIRO_FONT_WEIGHT_BOLDを指定します。</pre>
     *
     * @param string    $text
     * @param int       $x
     * @param int       $y
     * @param string    $font
     * @param int       $size
     * @param int       $align
     * @param array     $color1     array($r, $g, $b)
     * @param array     $color12    array($r, $g, $b)
     * @param float     $text_alpha
     * @param int    $slant CAIRO_FONT_SLANT_NORMAL | CAIRO_FONT_SLANT_ITALIC
     * @param int    $weight CAIRO_FONT_WEIGHT_NORMAL | CAIRO_FONT_WEIGHT_BOLD
     */
    public function addText($text, $x=0, $y=0, $font='mikachan', $size=24, $align=_BEAR_AKLIGN_LEFT, $color1=false, $color2=false, $text_alpha=0.85, $line_width=0.75, $slant=CAIRO_FONT_SLANT_NORMAL, $weight=CAIRO_FONT_WEIGHT_NORMAL)
    {
        //        print"text";exit();
        //フォントカラー
        cairo_set_source_rgb ($this->image, 0.0, 0.0, 1.0);
        cairo_select_font_face($this->image ,$font, $slant, $weight);
        cairo_set_font_size($this->image, $size);
        if (function_exists('cairo_text_extents')){
            $this->font_info = cairo_text_extents($this->image, $text);
        } else {
            //bug compatibility
            $this->font_info = cairo_text_extends($this->image, $text);
        }
        //Array ( [x_bearing] => 2 [y_bearing] => -41 [width] => 93 [height] => 44 [x_advance] => 96 [y_advance] => 0 )
        switch ($align) {
            case _BEAR_ALIGN_CENTER:
                $x = $this->src_width/2 - $this->font_info['x_advance'] / 2 + $x;
                break;
            case _BEAR_ALIGN_RIGHT:
                $x = $this->src_width - $this->font_info['x_advance'] - $x;
                break;
            default:
                break;
        }
        cairo_move_to($this->image, $x , $y+$size);
        cairo_text_path($this->image, $text);
        //        cairo_show_text($this->image, "日本語はどうだ!");
        //テキスト中身
        if ($color1){
            cairo_set_source_rgba($this->image, $color1[0]/255, $color1[1]/255, $color1[2]/255, $text_alpha);
        } else {
            cairo_set_source_rgba($this->image, 1, 1, 1, $text_alpha);
        }
        cairo_fill_preserve($this->image);
        //テキストボーダー
        if ($color2){
            cairo_set_source_rgba($this->image, $color2[0]/255, $color2[1]/255, $color2[2]/255, $text_alpha);
        } else {
            cairo_set_source_rgba($this->image, 0, 1, 1, $text_alpha);
        }
        cairo_set_line_width($this->image, $line_width);
        //        cairo_stroke_preserve($this->image);
        cairo_stroke($this->image);
        //cairo_show_page($this->image);
    }


    /**
     * 画像表示
     *
     * image/pngヘッダーを出力してPNG画像を出力します。
     *
     * @param string $file_location     画像ファイルの場所(URL or fileパス)
     * @param string $width             画像の幅
     */
    public function show($return=false){
        header("Content-type: " . 'image/png');
        cairo_surface_show_png($this->surface);
        exit();
    }

    /**
     * 画像保存
     *
     * CairoのPNG画像を保存します。
     *
     * @param string $format     画像ファイルのフォーマット
     * @param string $file_path  保存画像のファイルパス
     */
    public function save($file_path){
        $result = cairo_surface_write_to_png($this->surface, $file_path);
        $file_exists = file_exists($file_path);
        $log = array('surface'=>$this->surface, 'is_res'=>is_resource($this->surface),
        'file path'=>$file_path, 'file_exists'=> file_exists($file_path), 'file size'=>filesize($file_path));
        BEAR_Log::appLog('cairo_surface_write_to_png', $log);
        cairo_surface_destroy($this->surface);
    }


    /**
     * エラー終了
     *
     * <pre>エラー終了します。運用でクローラーにキャッシュされないために503ヘッダーを出力しています</pre>
     *
     * @param string $error_func コール元のメソッド名
     * @param string $msg エラーメッセージ
     */
    private function error($error_func, $msg=false)
    {
        //エラーヘッダー
        header ('HTTP/1.0 503 Service Temporarily Unavailable');
        $is_res = (is_resource($this->image)) ? 'true' : 'false';
        if (App::$debug || 1){
            $err_msg = "cairo error! func=[{$error_func}] msg={$msg} is_resource=[{$is_res}] ";
            header("x-imgcairo-error: {$err_msg}");
            trigger_error($err_msg, E_USER_WARNING);
            exit() ;
        } else {
            trigger_error($err_msg, E_USER_WARNING);
            exit() ;
        }
    }
}


<?php
class BEAR_Factory extends BEAR_Base
{

    public function __construct(array $config)
    {
        parent::__construct($config);
    }
}
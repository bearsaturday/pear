<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Agent
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Agent.php 687 2009-07-03 14:49:14Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Agent/BEAR_Agent.html
 */
/**
 * エージェントクラス
 *
 * <pre>
 * 各エージェント（携帯）判別やエージェント毎の詳細情報を取得するのに用います。
 * PEARのNet_UserAgent_Mobileオブジェクトをプロパティに保持しています。
 *
 * Example 1. 直接アクセス
 *
 * </pre>
 * <code>
 * $agent = BEAR::dependency('BEAR_Agent');
 * $sub_id = $agent->getSubID();
 * </code>
 *
 * Example 2. 内部のNet_UserAgent_Mobileオブジェクトにアクセス
 * <code>
 * $agent = BEAR::dependency('BEAR_Agent');
 * $display = $agent->agent->getDisplay()
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Agent
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Agent.php 687 2009-07-03 14:49:14Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Agent/BEAR_Agent.html
 */
class BEAR_Agent extends BEAR_Factory
{

    /**
     * PC
     */
    const UA_PC = 'N';

    /**
     * Docomo iモード
     */
    const UA_DOCOMO = 'I';

    /**
     * AU EzWeb
     */
    const UA_AU = 'E';

    /**
     * Softbank 3GC
     */
    const UA_SOFTBANK = 'S';

    /**
     * Willcom
     */
    const UA_WILLCOM = 'W';

    /**
     * BEAR RESTクライアント
     */
    const UA_BEAR = 'B';

    /**
     * ボット用携帯エージェント(Docomo)
     */
    const BOT_DOCOMO = 'DoCoMo/2.0 N900i(c100;TB;W24H12)';

    /**
     * ボット用携帯エージェント(Docomo)
     */
    const BOT_AU = 'KDDI-TS26 UP.Browser/6.2.0.5 (GUI) MMP/1.1';

    /**
     * ボット用携帯エージェント(SB)
     */
    const BOT_SOFTBANK = 'SoftBank/1.0/705P/PJA23 Browser/Teleca-Browser/3.1 Profile/MIDP-2.0 Configuration/CLDC-1.1';

    /**
     * ボット用携帯エージェント(Willcom)
     */
    const BOT_WILLICOM = 'Mozilla/3.0(WILLCOM;KYOCERA/WX310K/2;1.1.5.15.000000/0.1/C100) Opera 7.0';

    /**
     * QVGAと判断するサイズ
     */
    const QVGA_WIDTH = 230;

    /**
     * 小さいと判定するキャッシュサイズ
     */
    const SMALL_CACHE_SIZE = 15000;

    /**
     * モバイレルかどうか
     * 
     * @var bool
     */
    public static $isMobile = false;

    /**
     * BOTかどうか
     *
     * @var bool
     */
    public static $isBot = false;

    /**
     * ユーザーエージェント
     *
     * ブラウザが送信するユーザーエージェント
     *
     * @var     string
     */
    private $_inputAgent;

    /**
     * モバイルエージェント
     *
     * PEAR::Net_UserAgent_Mobileオブジェクト
     *
     * @var     string
     */
    public $agent;

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    public function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * Net_UserAgent_Mobileクラスのインスタンス生成
     *
     * <pre>
     * Net_UserAgent_Mobileオブジェクトを生成してagentプロパティに格納します
     * </pre>
     *
     * @param string $agent エージェント文字列
     *
     * @return  object
     */
    public function factory()
    {
        $agent = isset($this->_config['mobile']) ? $this->_config['mobile'] : '';
        $httpUserAgent = $this->agent = &Net_UserAgent_Mobile::factory($agent);
        if (PEAR::isError($this->agent)) {
            switch (true) {
            case (strstr($httpUserAgent, 'DoCoMo')) :
                $botAgent = self::BOT_DOCOMO;
                break;
            case (strstr($httpUserAgent, 'KDDI-')) :
                $botAgent = self::BOT_AU;
                break;
            case (preg_match('/(SoftBank|Vodafone|J-PHONE|MOT-)/', $httpUserAgent)) :
                $botAgent = self::BOT_SOFTBANK;
                break;
            case (preg_match('/(DDIPOCKET|WILLCOM)/', $httpUserAgent)) :
                $botAgent = self::BOT_WILLCOM;
                break;
            default :
                $botAgent = '';
            }
            $this->agent = &Net_UserAgent_Mobile::factory($botAgent);
            self::$isBot = true;
        }
        return $this->agent;
    }

    /**
     * 携帯のユニークIDを取得
     *
     * @return string
     */
    public function getSerialNumber()
    {
        $serial = '';
        switch (BEAR::$ua) {
        case BEAR_Agent::UA_DOCOMO :
            $serial = $agent->getCardID();
            if ($serial === '') {
                $serial = $agent->getSerialNumber();
            }
            break;
        case BEAR_Agent::UA_AU :
            $serial = $agent->getHeader('X-UP-SUBNO');
            break;
        case BEAR_Agent::UA_SOFTBANK :
            $serial = $agent->getSerialNumber();
            break;
        default :
            break;
        }
        return $serial;
    }

    /**
     * QVGA端末かどうかを取得
     *
     * @internal  横幅がself::QVGA_WIDTHより大きかればQVGA判定
     *
     * @return bool
     */
    public static function isQVGA()
    {
        static $isQVGA;
        if (!isset($isQVGA)) {
            $size = $this->getDisplaySize();
            $isQVGA = ($size[0] > self::QVGA_WIDTH) ? true : false;
            //DoCoMoでディスプレイサイズが分からない場合QVGAとする
            if (!$isQVGA && ((BEAR::$ua == BEAR_Agent::UA_DOCOMO) && ($size[0] == 0))) {
                $isQVGA = true;
            }
        }
        return $isQVGA;
    }

    /**
     * 画面サイズの縦、横のサイズを取得
     *
     * @return array　array(width, height)
     */
    public function getDisplaySize()
    {
        static $size;
        if (!isset($size)) {
            $display = $this->agent->getDisplay();
            $size = $display->getSize();
        }
        return $size;
    }

    /**
     * 携帯の表示可能文字数を取得
     *
     * 携帯の表示可能文字数を取得します。。
     *
     * @return array　array(width, height)
     */
    public function getDisplayByteSize()
    {
        static $byteSize;
        if (!isset($byteSize)) {
            $display = $this->agent->getDisplay();
            $byteSize = array($display->getWidthBytes(), 
                $display->getHeightBytes());
        }
        return $byteSize;
    }

    /**
     * キャッシュサイズの取得
     *
     * 端末のキャッシュサイズをバイト数で返します。
     *
     * @return int
     */
    public function getCacheSize()
    {
        switch (BEAR::$ua) {
        case BEAR_Agent::UA_DOCOMO :
            $size = $this->agent->getCacheSize() * 1024;
            break;
        case BEAR_Agent::UA_AU :
            $headers = getallheaders();
            $size = $headers['x-up-devcap-max-pdu'];
            break;
        case BEAR_Agent::UA_SOFTBANK :
            $phone = $this->agent->getName(); // 'J-PHONE'
            $version = (int)$this->agent->getVersion(); // 2.0
            if ($phone == 'J-PHONE') {
                if ($version <= 3.0) {
                    $size = 6000;
                } elseif ($version <= 4.2) {
                    $size = 12000;
                } elseif ($version <= 4.3) {
                    $size = 30000;
                } elseif ($version <= 5.0) {
                    $size = 200000;
                } else {
                    $size = 200000;
                }
            } else {
                $size = 300000;
            }
            break;
        default :
            $size = false;
        }
        return $size;
    }

    /**
     * キャッシュサイズの小さな端末かチェック
     *
     * @param integer $smallSize 小さいと判断するキャッシュサイズ
     *
     * @return bool
     */
    function isSmallCacheSize($smallSize = self::SMALL_CACHE_SIZE)
    {
        $cacheSize = $this->getCacheSize();
        $result = ($cacheSize && $cacheSize < $smallSize) ? true : false;
        return $result;
    }

    /**
     * セッションクエリーを付加
     *
     * クッキーが使えないエージェント用にURLからセッションクエリー
     * 付きURLを返します。
     *
     * @param string $url URL
     *
     * @return string
     */
    public function getSessionQuery($url = false)
    {
        $sessionName = session_name();
        $sessionId = session_id();
        if (!isset($_COOKIE[$sessionName])) {
            /**
             * セッションクエリーが付いてれば消去
             */
            $url = preg_replace("/&*{$sessionName}=[^&]+/is", '', $url);
            $con = ($url && strpos($url, "?")) ? '&' : '?';
            $url .= "{$con}{$sessionName}={$sessionId}";
        }
        return $url;
    }

    /**
     * DoCoMoのHTMLバージョンを取得
     *
     * Docomoの場合の利用可能HTMLバージョンを返します。
     *
     * @return string バージョン
     */
    public function getHTMLVersion()
    {
        static $result;
        if (isset($result)) {
            return $result;
        }
        $htmlVersionMap = array('M702i' => '5.0');
        $res = $this->agent->getModel();
        foreach ($htmlVersionMap as $key => $value) {
            if (preg_match("/$key/", $res)) {
                $result = $value;
                return $result;
            }
        }
        $result = $this->agent->getHTMLVersion();
        return $result;
    }

    /**
     * BEARエージェントか返す
     *
     * HTTP_USER_AGENTがBEAR/x.xならBEARのRESTのwebサービスクライアントとしてtrueを返します。
     *
     * @return bool
     */
    public static function isBearAgent()
    {
        return (isset($_SERVER['HTTP_USER_AGENT']) && strpos($_SERVER['HTTP_USER_AGENT'], 'BEAR') !== false);
    }
}
<?php

/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Execute
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: Vo.php 687 2009-07-03 14:49:14Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * VOリソースクラス
 *
 * <pre>
 * VOクラスをリソースとして扱うクラスです。VOクラスはメソッドをもちCRUDインターフェイスに対応します。
 * </pre>
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Execute
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: Vo.php 687 2009-07-03 14:49:14Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 *  */
class BEAR_Resource_Execute_Vo extends BEAR_Resource_Execute_Adaptor
{

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    public function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * リソースアクセス
     *
     * リソースを使用します。
     *
     * @param void
     *
     * @return mixed
     */
    public function request()
    {
        $fullPath = _BEAR_APP_HOME . '/App/Resource/' . $this->_config['uri'] . '.php';
        assert(file_exists($fullPath));
        $result = include_once $fullPath;
        if (!$result) {
            trigger_error("No Resource File=[$fullPath]", E_USER_ERROR);
            $mock = BEAR::factory('BEAR_Resource_Execute_Mock', $this->_config);
            return $mock->request($this->_config['method'], $this->_config['uri'], $this->_config['values'], $this->_config['options']);
        }
        // VOクラスDI
        $config = array(
            'method' => $this->_config['method'],
            'uri' => $this->_config['uri'],
            'class' => $this->_config['class']);
        if (isset($this->_config['options']['config'])) {
            $voConfig = array_merge($this->_config, $this->_config['options']['config']);
        } else {
            $voConfig = $this->_config;
        }
        $this->_config['obj'] = BEAR::factory($this->_config['class'], $voConfig);
        // アノテーションクラスDI
        $config['method'] = 'on' . $this->_config['method'];
        $annotation = BEAR::factory('BEAR_Annotation', $config);
        //        // requireアノテーション (引数のチェック)
        $annotation->required($this->_config['values']);
        //        // aspectアノテーション (アドバイスの織り込み）
        $method = $annotation->aspect();
        $result = $method->invoke($this->_config['obj'], $this->_config['values']);
        // 後処理
        if (PEAR::isError($result)) {
            $this->_config['obj']->setCode(BEAR::CODE_ERROR);
        } else {
            if (!($result instanceof BEAR_Vo)) {
                $this->_config['obj']->setBody($result);
            }
        }
        return $this->_config['obj'];
    }
}
<?php
class BEAR_Vo_Iterator implements Iterator
{

    private $_arr;

    public function __construct(array $arr)
    {
        $this->_arr = $arr;
    }

    public function update($arr)
    {
        $this->_arr = $arr;
    }

    public function rewind()
    {
        reset($this->_arr);
    }

    public function key()
    {
        return key($this->_arr);
    }

    public function &current()
    {
        return $this->_arr[key($this->_arr)];
    }

    public function next()
    {
        next($this->_arr);
    }

    public function valid()
    {
        return !is_null(key($this->_arr));
    }
}
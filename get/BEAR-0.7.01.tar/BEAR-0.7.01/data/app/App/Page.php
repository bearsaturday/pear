<?php
/**
 * App
 *
 * @category   BEAR
 * @package    App
 * @subpackage Class
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: Page.php 688 2009-07-03 15:57:58Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 */
/**
 * アプリケーションページ
 *
 * @category   BEAR
 * @package    App
 * @subpackage Class
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: Page.php 688 2009-07-03 15:57:58Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 * @abstract
 */
abstract class App_Page extends BEAR_Page
{

    /**
     *  セッション
     *
     * @var BEAR_Session
     */
    protected $_session;

    /**
     * リソースアクセス
     *
     * @var BEAR_Resource
     */
    protected $_resource;

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * インジェクション
     *
     * @return void
     */
    protected function onInject()
    {
        $this->_session = BEAR::dependency('BEAR_Session');
        $this->_resource = BEAR::dependency('BEAR_Resource');
    }

    /**
     * 出力
     *
     * @return void
     */
    public function onOutput()
    {
        $this->display();
    }
}
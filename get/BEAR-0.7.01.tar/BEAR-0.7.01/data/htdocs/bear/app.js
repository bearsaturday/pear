/*
 * app.js - JS library for BEAR
 */
( function($) {
	$.app = {
		demo : function(values) {
		$().print_b('demo was called.');
		}
	}
})($);
$().print_b('app.js was included.');
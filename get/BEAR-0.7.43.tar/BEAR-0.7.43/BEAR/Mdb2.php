<?php
/**
 * BEAR_Mdb2
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Mdb2
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Mdb2.php 835 2009-08-18 03:54:51Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Mdb2/BEAR_Mdb2.html
 */
/**
 * MDB2クラス
 *
 * <pre>
 * PEAR::MDB2を継承したDBアクセスクラスです。
 * アプリケーションではこのクラスを継承したアプリケーションDBアクセス
 * クラスを(App_DB)を定義しアプリケーションからはそちらを使用します。
 *
 *
 * 拡張機能
 * +同じクエリーなら同じ結果を返すクエリーキャッシュ
 * +実行計画の自動ログ
 * +DBハンドル自動再利用
 * +二重実行防止トークン処理
 * +実行時間計測
 * +INSERT文、UPDATE文生成
 *
 *
 * Example 1. セレクトクエリー
 *
 * </pre>
 * <code>
 *   $mdb2 = BEAR_Mdb2::getInstance($dsn);
 *   ...
 *   $value = $mdb2->queryOne($query);
 *   $value = $mdb2->queryRow($query);
 *   $value = $mdb2->queryAll($query);
 * </code>
 *
 * Example 2. インサート文生成
 *
 * <code>
 *  $mdb2 = BEAR_Mdb2::getInstance($dsn);
 *  $table_name = "user_table";
 *  $fields_values = array('id'=>$id, 'password'=>$password);
 *  $result = $mdb2->extend->autoExecute($table_name, $fields_values, MDB2_AUTOQUERY_INSERT);
 * </code>
 *
 * <pre>
 * MDB2結果コード
 *
 * ('MDB2_OK',                      true);
 * ('MDB2_ERROR',                     -1);
 * ('MDB2_ERROR_SYNTAX',              -2);
 * ('MDB2_ERROR_CONSTRAINT',          -3);
 * ('MDB2_ERROR_NOT_FOUND',           -4);
 * ('MDB2_ERROR_ALREADY_EXISTS',      -5);
 * ('MDB2_ERROR_UNSUPPORTED',         -6);
 * ('MDB2_ERROR_MISMATCH',            -7);
 * ('MDB2_ERROR_INVALID',             -8);
 * ('MDB2_ERROR_NOT_CAPABLE',         -9);
 * ('MDB2_ERROR_TRUNCATED',          -10);
 * ('MDB2_ERROR_INVALID_NUMBER',     -11);
 * ('MDB2_ERROR_INVALID_DATE',       -12);
 * ('MDB2_ERROR_DIVZERO',            -13);
 * ('MDB2_ERROR_NODBSELECTED',       -14);
 * ('MDB2_ERROR_CANNOT_CREATE',      -15);
 * ('MDB2_ERROR_CANNOT_DELETE',      -16);
 * ('MDB2_ERROR_CANNOT_DROP',        -17);
 * ('MDB2_ERROR_NOSUCHTABLE',        -18);
 * ('MDB2_ERROR_NOSUCHFIELD',        -19);
 * ('MDB2_ERROR_NEED_MORE_DATA',     -20);
 * ('MDB2_ERROR_NOT_LOCKED',         -21);
 * ('MDB2_ERROR_VALUE_COUNT_ON_ROW', -22);
 * ('MDB2_ERROR_INVALID_DSN',        -23);
 * ('MDB2_ERROR_CONNECT_FAILED',     -24);
 * ('MDB2_ERROR_EXTENSION_NOT_FOUND',-25);
 * ('MDB2_ERROR_NOSUCHDB',           -26);
 * ('MDB2_ERROR_ACCESS_VIOLATION',   -27);
 * ('MDB2_ERROR_CANNOT_REPLACE',     -28);
 * ('MDB2_ERROR_CONSTRAINT_NOT_NULL',-29);
 * ('MDB2_ERROR_DEADLOCK',           -30);
 * ('MDB2_ERROR_CANNOT_ALTER',       -31);
 * ('MDB2_ERROR_MANAGER',            -32);
 * ('MDB2_ERROR_MANAGER_PARSE',      -33);
 * ('MDB2_ERROR_LOADMODULE',         -34);
 * ('MDB2_ERROR_INSUFFICIENT_DATA',  -35);
 *
 * DATAタイプ
 *
 * 'text':
 * 'clob':
 * 'blob':
 * 'integer':
 * 'boolean':
 * 'date':
 * 'time':
 * 'timestamp':
 * 'float':
 * 'decimal':
 *
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Mdb2
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Mdb2.php 835 2009-08-18 03:54:51Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Mdb2/BEAR_Mdb2.html
 */
class BEAR_Mdb2 extends BEAR_Factory
{

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    public function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * シングルトン
     *
     * <pre>
     * MDB2のsingletonメソッドに相当する昨日に加えてエラーハンドラーの設定や
     * フェッチモードをASSOCにしています。
     * $dsnを省略しればApp_DB::$config['db']['default']がDSNとして利用されます。
     *　</pre>
     *
     * @param string $dsn     DSN
     * @param array  $options オプション
     *
     * @return MDB2_Driver_Datatype_mysqli
     */
    public function factory()
    {
        $options = (isset($this->_config['options']) && is_array($this->_config['options'])) ? $this->_config['options'] : array();
        // MDB2インスタンス生成
        if ($this->_config['debug']) {
            // Debugモード オプション
            $options['debug'] = true;
            $options['debug_handler'] = array('BEAR_Mdb2', 'onDebug');
        } else {
            $options['debug'] = false;
        }
        $mdb2 = MDB2::factory($this->_config['dsn'], $options);
        if (PEAR::isError($mdb2)) {
            var_export($this->_config['dsn']);
            exit();
            throw $this->_exception('db connection error', 503, array(
                'dsn' => $this->_config['dsn']));
        }
        $mdb2->setFetchMode(MDB2_FETCHMODE_ASSOC);
        return $mdb2;
    }

    /**
     * カウントクエリーを生成する
     *
     * <pre>SQL文から"SELECT COUNT(*)" を付加したカウントクエリーを生成して返します。
     * COUNT文を含まないSQLからセレクト結果の個数を知るためCOUNTのクエリーを使用するのに用います
     * DBページャーで内部的にも使用されています。
     *
     * Example 1. SQLからCOUNT()を取得
     *
     * </pre>
     * <code>
     * $count_query = $this->getCountSQL($query));
     * $total_items = $this->getOne($count_query, $params);
     * </code>
     *
     * @param string $query クエリー
     *
     * @return string 書き換えられたクエリー | false（失敗）
     * @static
     *
     */
    public static function rewriteCountQuery($query)
    {
        if (preg_match('/^\s*SELECT\s+\bDISTINCT\b/is', $query) || preg_match('/\s+GROUP\s+BY\s+/is', $query)) {
            return false;
        }
        $openParenthesis = '(?:\()';
        $closeParenthesis = '(?:\))';
        $subqueryInSelect = $openParenthesis . '.*\bFROM\b.*' . $closeParenthesis;
        $pattern = '/(?:.*' . $subqueryInSelect . '.*)\bFROM\b\s+/Uims';
        if (preg_match($pattern, $query)) {
            return false;
        }
        $subqueryWithLimitOrder = $openParenthesis . '.*\b(LIMIT|ORDER)\b.*' . $closeParenthesis;
        $pattern = '/.*\bFROM\b.*(?:.*' . $subqueryWithLimitOrder . '.*).*/Uims';
        if (preg_match($pattern, $query)) {
            return false;
        }
        $queryCount = preg_replace('/(?:.*)\bFROM\b\s+/Uims', 'SELECT COUNT(*) FROM ', $query, 1);
        list($queryCount, ) = preg_split('/\s+ORDER\s+BY\s+/is', $queryCount);
        list($queryCount, ) = preg_split('/\bLIMIT\b/is', $queryCount);
        return trim($queryCount);
    }

    /**
     * ページャーセレクト
     *
     * <pre>
     * DB結果の一部だけをSELECTする機能と、HTMLページングの機能が合わさった
     * メソッドです。getAll()メソッドの引数に加えて一画面に表示するデータ数を
     * 引数に指示するとページング(スライス）されたデータ結果、
     * エージェントに合わせたリンクHTML文字列が返ります。
     * 引数のSQLからCOUNT文とLIMIT文をメソッド内部で生成して実行します。
     * SELECTの範囲を全件ではなくて任意の数にしたいときは、
     * $pagerOptions['totalItems']にトータルの件数をセットします。
     * </pre>
     *
     * @param MDB2_Driver_Datatype_mysql &$db          DBオブジェクト(MDB2_Driver_Datatype_mysql)
     * @param string                     $query        SQL
     * @param array                      $pagerOptions PEAR::Pagerオプション
     *
     * @return BEAR_Ro
     */
    public function queryPager(&$db, $query, array $pagerOptions = array())
    {
        if (!array_key_exists('totalItems', $pagerOptions)) {
            //be smart and try to guess the total number of records
            $countQuery = self::rewriteCountQuery($query);
            if ($countQuery) {
                $totalItems = $db->queryOne($countQuery);
                if (PEAR::isError($totalItems)) {
                    return $totalItems;
                }
            } else {
                //GROUP BY => fetch the whole resultset and count the rows returned
                $res = & $db->queryCol($query);
                if (PEAR::isError($res)) {
                    return $res;
                }
                $totalItems = count($res);
            }
            $pagerOptions['totalItems'] = $totalItems;
        }
        // ページング
        $pager = BEAR::dependency('BEAR_Pager');
        // totalItems以外のBEAR_Pagerデフォルトオプションを使用
        $defaultPagerOptions = $pager->getPagerOptions();
        unset($defaultPagerOptions['totalItems']);
        $pagerOptions = $pagerOptions + $defaultPagerOptions;
        $pager->setOptions($pagerOptions);
        $pager->pager->build();
        //情報
        $info['totalItems'] = $pagerOptions['totalItems'];
        $pager->makeLinks($pagerOptions['delta'], $pagerOptions['totalItems']);
        $links = $pager->pager->getLinks();
        $info['page_numbers'] = array('current' => $pager->pager->getCurrentPageID(),
            'total' => $pager->pager->numPages());
        list($info['from'], $info['to']) = $pager->pager->getOffsetByPageId();
        $info['limit'] = $info['to'] - $info['from'] + 1;
        $db->setLimit($pagerOptions['perPage'], $info['from'] - 1);
        $result = $db->queryAll($query);
        if (PEAR::isError($result)) {
            return $result;
        }
        // ROオブジェクトにして返す
        $ro = BEAR::factory('BEAR_Ro');
        $ro->setBody($result);
        $ro->setHeaders($info);
        $pager = array('pager'=>$links);
        $ro->setLinks($pager);
        $bewarLog = BEAR::dependency('BEAR_Log');
        $bewarLog->log('DB Pager', $info);
        return $ro;
    }

    /**
     * エラーハンドラー
     *
     * エラー処理
     *
     * @param object $paerError PEARエラー
     *
     * @return void
     * @ignore
     * @static
     */
    private static function _errorHandler($paerError)
    {
        trigger_error('BEAR_Mdb2 Error:' . $paerError->toString(), E_USER_WARNING);
    }

    /**
     * デバック用ハンドラ
     *
     * @param object       &$db     MDB2オブジェクト
     * @param string       $scope   スコープ
     * @param string       $message メッセージ
     * @param unknown_type $isManip 不明
     *
     * @return void
     */
    public static function onDebug(&$db, $scope, $message, $isManip = null)
    {
        $log['scope'] = $scope;
        $log['message'] = $message;
        if ($scope == 'query') {
            $log['message'] = $message . $db->getOption('log_line_break');
        }
        if (!is_null($isManip)) {
            $log['isManip'] = $isManip;
        }
        $bearLog = BEAR::dependency('BEAR_Log');
        $bearLog->log('MDB2', $log);
    }
}

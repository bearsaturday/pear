<?php

/**
 * App
 * 
 * @category   BEAR
 * @package    App_Ro
 * @subpackage Output
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: _untitiled.php 835 2009-08-18 03:54:51Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 */
/**
 * Untitledアウトプットフィルター
 *
 * @param array $values  引数
 * @param array $options オプション
 * 
 * @return BEAR_Ro
 */
function outputUntitled($values, $options = null)
{
    $headers = array('X-BEAR-Output: untitled', 'Content-Type: text/html; charset=utf-8');
    return new BEAR_Ro('<pre>' . print_r($values, true) . '</pre>', $headers);
}
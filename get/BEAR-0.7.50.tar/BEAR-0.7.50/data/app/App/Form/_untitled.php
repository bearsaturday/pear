<?php
/**
 * フォーム
 *
 * <pre>
 * described here...
 * </pre>
 *
 * @package    App
 * @subpackage Form
 * @author     $Author: koriyama@users.sourceforge.jp $
 * @version    SVN: Release: $Id: _untitled.php 848 2009-08-19 10:02:54Z koriyama@users.sourceforge.jp $
 */
class App_Form_Untitled
{

    /**
     * Form
     *
     * @return void
     */
    public static function build()
    {
        $form = BEAR::dependency('BEAR_Form');
        $form->setDefaults(array('name' => 'Kuma', 'email' => 'kuma@example.com'));
        //  フォームヘッダー
        $form->addElement('header', 'main', '入力(確認）してください');
        //  フォームインプットフィールド
        $form->addElement('text', 'name', '名前', 'size=30 maxlength=30');
        $form->addElement('text', 'email', 'メールアドレス', 'size=30 maxlength=30');
        $form->addElement('textarea', 'body', '感想');
        $form->addElement('submit', '_submit', '送信', '');
        // フィルタと検証ルール
        $form->applyFilter('__ALL__', 'trim');
        $form->applyFilter('__ALL__', 'strip_tags');
        $form->addRule('name', '名前を入力してください', 'required', null, 'client');
        $form->addRule('email', 'emailを入力してください', 'required', null, 'client');
        $form->addRule('email', 'emailの形式で入力してください', 'email', null, 'client');
    }
}
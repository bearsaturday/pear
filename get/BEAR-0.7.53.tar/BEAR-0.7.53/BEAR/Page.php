<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Page
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Page.php 952 2009-09-22 05:45:23Z koriyama.sourceforge $
 * @link      http://api.bear-project.net/BEAR_Page/BEAR_Page.html
 */
/**
 * BEAR_Pageクラス
 *
 * <pre>
 * ページの抽象クラスです。onで始まるメソッドがイベントドリブンでコールされます。
 * が基本3メソッドです。
 *
 * onInit($args)        初期化
 * onOutput()           ページ出力処理
 * onAction($submit)    フォーム送信後の処理
 *
 * Example 1. テンプレートにアサインしてページ表示
 *
 * </pre>
 * <code>
 * // ページ実行
 * class Admin_Index extends App_Page
 * {
 *     public function onInit()
 *     {
 *         $res = BEAR_Resource('/usr/profile');
 *         $profile = $res->reard(array('id=>1'));
 *         // $viewにアサインする変数
 *         $this->set('profile', $profile);
 *     }
 *
 *     public function onOutput()
 *     {
 *         $this->display();
 *     }
 * }
 * new BEAR_Main('Admin_Index');
 * </code>
 *
 * Example 2. フォーム投稿
 *
 * <code>
 * // ページ実行
 * class Page_Register extends App_Page
 * {
 *     public function onAction($submit)
 *     {
 *         print "{$submit['name']}さんを登録しました";
 *         $this->display('admin/registered.tpl');
 *     }
 * }
 * BEAR_Main('Admin_Index');
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Page
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Page.php 952 2009-09-22 05:45:23Z koriyama.sourceforge $
 * @link      http://api.bear-project.net/BEAR_Page/BEAR_Page.html
 * @abstract
 */
abstract class BEAR_Page extends BEAR_Base
{

    /**
     * アクティブリンク・クリックネーム　クエリーキー
     *
     */
    const KEY_CLICK_NAME = '_cn';

    /**
     * アクティブリンク・クリックバリュ　クエリーキー
     *
     */
    const KEY_CLICK_VALUE = '_cv';

    /**
     * 携帯サ絵文字ポート対応なし
     *
     * @var integer
     */
    const SUPPORT_NONE = 0;

    /*
     * 携帯絵文字サポートIMG変換
     *
     * @var integer
     */
    const SUPPORT_IMG = 1;

    /*
     * 携帯絵文字サポートIMG変換
     *
     * @var integer
     */
    const SUPPORT_CONV = 2;


    /**
     * ページモード - HTML
     *
     * @var string
     */
    const CONFIG_MODE_HTML = 'html';

    /**
     * ページモード - リソース
     *
     * @var string
     */
    const CONFIG_MODE_RESOURCE = 'res';

    /**
     * Smartyオブジェクト
     *
     * @var Smarty
     */
    public $smarty = null;

    /**
     * onInit()等の引数
     *
     * @var array
     */
    protected $_args = array();

    /**
     * ページ実行ログ
     */
    protected $_pageLog = array();

    /**
     * Click名
     *
     * @var string
     */
    private $_onClick = null;

    /**
     * サブミット文字列を変換するか
     *
     * @var bool
     */
    private $_submitConvert = false;

    /**
     * 文字コード変換の場合のモバイルの文字コード
     */
    private $_codeFromMoble;

    /**
     * onInit()でsetされた値
     *
     * @var array
     */
    private $_values = array();

    /**
     * ページキャッシュ
     *
     * @var string
     */
    private $_cache = array('use_cache' => false, 'headers' => null, 'html' => null);

    /**
     * モバイル出力ヘッダー
     *
     * @var string
     */
    private $_mobileHeader = 'application/xhtml+xml';

    /**
     * AJAXコマンドデータ
     *
     * @var array
     */
    private $_ajax = array();

    /**
     * charset
     *
     * マルチエージェントの場合のcharset
     */
    private static $_charset = null;

    /**
     * クリックをゲット
     *
     * @return string
     */
    public function getOnClick()
    {
        return $this->_onClick;
    }

    /**
     * セッション
     *
     * @var BEAR_Session
     */
    protected $_session;

    /**
     * リソースアクセス
     *
     * @var BEAR_Resource
     */
    protected $_resource;

    /**
     * ページリソースモード
     *
     * @var bool
     */
    private static $_isResourceMode = false;

    /**
     * クリックをセット
     *
     * @param string $onClick
     */
    public function setOnClick($onClick)
    {
        $this->_onClick = $onClick;
    }

    /**
     * コンストラクタ
     *
     * <pre>
     * 携帯端末からPOSTされた文字のコード、絵文字を処理します。
     * </pre>
     *
     */
    public function __construct(array $config)
    {
        parent::__construct($config);
        $this->header = BEAR::dependency('BEAR_Page_Header');
        if ($this->smarty !== false) {
            $this->smarty = BEAR::dependency('BEAR_Smarty');
        }
        // PC/Mobile対応
        if ($this->_config['mobile'] !== 0) {
            $this->_initAgent($this->_config['mobile']);
        }
    }

    /**
     * ページ初期化ハンドラ
     *
     * ページの初期化を行います。onOutput()で出力させる変数を全て用意しsetします。<br/>
     * setした変数はキャッシュ可能です。
     *
     * @param args $args ページ引数
     *
     * @return void
     */
    public function onInit(array $args)
    {
    }

    /**
     * ページ表示ハンドラ
     *
     * <pre>
     * onInit()で実行された後、フォーム送信されてない、
     * またはバリデーションNGのときにコールされます。
     * </pre>
     *
     * @return void
     */
    public function onOutput()
    {
    }

    /**
     * バリデーションOKハンドラ
     *
     * <pre>フォーム送信されバリデーションOKの場合にonInit()の後にコールされます</pre>
     *
     * @param mixed $submit フォーム内容
     *
     * @return void
     *
     */
    public function onAction(array $submit)
    {
    }

    /**
     * モバイル用のヘッダーをセットする
     *
     * <code>
     * class App_Page extends BEAR_Page
     * {
     *   function __construct()
     *   {
     *     // html対応にする
     *     $this->setMobileHeader();
     *     parent::__construct();
     *   }
     * </code>
     *
     * @param string $header text/html
     *
     * @return void
     */
    protected function setMobileHeader($header = 'text/html')
    {
        $this->header->setMobileHeader($header);
    }

    /**
     * ページ出力
     *
     * <pre>
     * 指定したテンプレートをsmartyオブジェクトとフォームオブジェクトを
     * テンプレートにアサインして画面出力します。画面出力の代わりにHTMLを
     * 文字列として取得する場合はfetch()メソッドを使用します。
     * 引数を省略するとページクラスからパスが生成されたテンプレートが使用されます
     *
     * $options
     *
     * 'override'  設定ファイル上書き配列 key=>value
     *
     * </pre>
     *
     * @param string $tplName テンプレートファイル名
     * @param mixed  $options オプション
     *
     * @return   mixed
     */
    public function display($tplName = null, $options = null)
    {
        // charset
        if ($this->_charset) {
            $this->set('charset', $this->_charset);
        }
        $path = $this->_getTemplateNameByPageClass($tplName); // ex) user.ceate.preview
        // mobile
        if (BEAR::$ua) {
            $path = $this->_getTemplateNameByMobile($path, BEAR::$ua);
        }
        $matches = array();
        preg_match('/(.+?)[\.]/', $path, $matches);
        if (is_array($matches)) {
            $firstWordForConfig = (isset($matches[0]) && $matches[0]) ? $matches[0] : $path . '.';
        } else {
            $firstWordForConfig = '';
        }
        $templatePath = 'pages/' . $path . '.tpl';
        $configFileHead = _BEAR_APP_HOME . '/App/views/pages/' . $firstWordForConfig;
        // 設定ファイル
        if (file_exists($configFileHead . 'yml')) {
            $configFile = $configFileHead . 'yml';
        } elseif (file_exists($configFileHead . 'ini')) {
            $configFile = $configFileHead . 'ini';
        } else {
            $configFile = false;
        }
        // yml,ini
        if ($configFile === false) {
            BEAR_Smarty::$doEmojiOutputFilter = 1;
            //html
            $html = $this->fetch($templatePath);
        } else {
            $config = BEAR::loadValues($configFile);
            $lv = isset($config['default']) ? $config['default'] : array();
            //携帯config
            if (isset($config['mobile']) && (BEAR::$ua != BEAR_Agent::UA_PC)) {
                $isArray = is_array($lv);
                if ($isArray) {
                    $mobile = $config['mobile'];
                    $lv = array_merge($lv, $mobile);
                } else {
                    $lv = $config['mobile'];
                }
            }
            if (is_array($options) && is_array($lv) && is_array($config[$options['override']])) {
                $lv = array_merge($lv, $config[$options['override']]);
            }
            $this->set('layout', $lv);
            $this->set('static', $lv);
            if (isset($config['layout'])) {
                $contetForLayout = $this->fetch($templatePath);
                $this->set('content_for_layout', $contetForLayout);
                $layoutFile = 'layouts/' . $config['layout'];
                //モバイル用のレイアウトファイル
                $ua = BEAR::$ua;
                if ($ua != BEAR_Agent::UA_PC) {
                    $mobileLayoutNoExtention = $this->_removeExtention($layoutFile);
                    $path = _BEAR_APP_HOME . "/App/views/{$mobileLayoutNoExtention}.mobile.tpl";
                    $isExists = file_exists($path);
                    if ($isExists) {
                        $layoutFile = $mobileLayoutNoExtention . '.mobile.tpl';
                    }
                }
                BEAR_Smarty::$doEmojiOutputFilter = 1;
                $html = $this->fetch($layoutFile);
            } else {
                $html = $this->fetch($templatePath);
            }
        }
        $this->_output($html);
        // 使用テンプレートのログ
        $this->_pageLog['display'] = $tplName;
        $this->_log->log('page log', $this->_pageLog);
    }

    /**
     * テンプレート名の取得
     *
     * @param string $tplName テンプレート名（省略可）
     *
     * @return array
     *
     */
    private function _getTemplate($tplName = null)
    {
        $path = $this->_getTemplateNameByPageClass($tplName);
        // mobile
        $path = (BEAR::$ua) ? $this->_getTemplateNameByMobile($path, BEAR::$ua) : $path;
        return $path;
    }

    /**
     * ページクラスからパスを取得する
     *
     * <pre>
     * /はじまりだと絶対パス、テンプレート名省略または相対パスなら
     * ページクラスからパス名を組み立てます。相対パスでテンプレートを
     * 指定していれば指定したものにおきかわる。
     *
     * 例
     * 絶対パス
     *  '/index.tpl'　=> '/index'
     *  '/some/index.tpl' => '/some/index'
     * 相対パス　Sample_Test_Pageクラスの場合
     *  '' =>　'sample/test/page'
     *  'help.tpl' => 'sample/test/help'
     *  'another/help.tpl' => 'sample/test/another/help'
     * </pre>
     *
     * @param string $tplName テンプレート名
     *
     * @return string
     */
    private function _getTemplateNameByPageClass($tplName)
    {
        // 絶対パス
        if (substr($tplName, 0, 1) == '/') {
            // 先頭の/を除いて返す
            $absPath = $this->_removeExtention($tplName);
            return substr($absPath, 0);
        }
        // 相対パスの場合はクラス名からベースパスを作成する
        $pageClass = preg_replace('/^Page_/', '', get_class($this));
        $base = str_replace('_', '/', strtolower($pageClass));
        if ($tplName == null) {
            return $base;
        }
        $bodyTpl = $this->_removeExtention($tplName);
        //テンプレート名の指定があればページクラス名の相対パスで置換
        $regx = '/\/([\w]+)$/i';
        $result = ($tplName) ? preg_replace($regx, '/' . $bodyTpl, $base) : $base;
        return $result;
    }

    /**
     * ファイルの拡張子を除いたものを返します
     *
     * @param string $file ファイル名
     *
     * @return string
     *
     */
    private function _removeExtention($file)
    {
        $pathinfo = pathinfo($file);
        switch ($pathinfo['dirname']) {
            case '/' :
                $result = $pathinfo['filename'];
                break;
            case '.' :
                $result = $pathinfo['filename'];
                break;
            default :
                $result = $pathinfo['dirname'] . '/' . $pathinfo['filename'];
                break;
        }
        return $result;
    }

    /**
     * モバイルテンプレート名
     *
     * index.tplに対してindex.mobile.tplという風に.mobile.というファイルが用意されていれば
     * モバイル用のテンプレート名を返します
     *
     * @param string $file ファイル名
     * @param string $ua   ユーザーエージェント
     *
     * @return string
     */
    private function _getTemplateNameByMobile($file, $ua)
    {
        //クリックメソッドの時はクリックテンプレート優先
        if ($ua == BEAR_Agent::UA_PC) {
            return $file;
        }
        if (file_exists(_BEAR_APP_HOME . '/App/views/pages/' . $file . '.mobile.tpl')) {
            $file = $file . '.mobile';
        }
        return $file;
    }

    /**
     * 値をセット
     *
     * <pre>
     * outputでdisplay()やoutput()とする値をセットします。
     * </pre>
     *
     * @param mixed $key    キー string
     * @param mixed $value  値
     *
     * @return void
     */
    public function set($key, $value)
    {
        $this->_values[$key] = $value;
    }

    public function setAll($values)
    {
        $this->_values = $values;
    }

    /**
     * ページ変数取得
     */
    public function get($key = null)
    {
        $result = (is_null($key)) ? $this->_values : $this->_values[$key];
        return $result;
    }

    /**
     * ページ文字列取得
     *
     * アサイン済みテンプレートのHTMLを文字列として取得します。
     *
     * @param string $tplName テンプレート名
     *
     * @return string
     */
    public function fetch($tplName)
    {
        // プレフィックス付きテンプレートファイル優先
        // 無ければプレフィックス無しを使用
        $file = $this->smarty->template_dir . $tplName;
        if (!file_exists($file)) {
            //テンプレートファイルがない
            $info = array(
                'tpl name' => $tplName,
                'template_file' => $file);
            $msg = 'Template file is missing.（テンプレートファイルがありません)';
            throw $this->_exception($msg, array('info' => $info));
        }
        // フォーム
        if (isset($this->_config['redner_form']) && $this->_config['redner_form'] === true) {
            BEAR_Form::renderForms();
        }
        $this->smarty->assign($this->_values);
        $html = $this->smarty->fetch($file);
        return $html;
    }

    /**
     * http出力
     *
     * <pre>
     * HTTPヘッダーとコンテンツを出力します。
     * HTMLコンテンツ(text/html)やXMLコンテンツ(application/xml)などを出力します。
     *
     * Example 1. XML出力
     * </pre>
     * <code>
     * //XML出力
     * $option = array('header' => "Content-Type: application/xml");
     * $this->_output($contens, $option);
     * </code>
     *
     * Example 2. 複数ヘッダー出力
     *
     * <code>
     * $option[] = array('header' => "Content-Type: application/xml");
     * $option[] = array('x-hoge-time' => "{$time}");
     * $this->_output($contens, $option);
     * </code>
     *
     * @param string $html    HTMLコンテンツ
     * @param mixed  $headers HTTPヘッダー
     *
     * @return mixed
     */
    private function _output($html, $headers = false)
    {
        // ヘッダーを出力
        if ($headers) {
            $this->setHeader($headers);
        }
        // ボディ出力
        echo $html;
    }

    /**
     * ヘッダー出力
     *
     * <pre>
     * ヘッダーを出力用にバッファリングします。
     * 引数は配列または文字列で指定できます。
     * スタティック変数として保存されBEAR_Mainで出力バッファを
     * フラッシュする時に送出されます。
     * 同じ<
     * /pre>
     *
     * @param mixed $header HTTPヘッダー
     *
     * @return void
     * @static
     */
    public function setHeader($header)
    {
        $this->header->setHeader($header);
    }

    /**
     * ヘッダーのフラッシュ
     *
     * <pre>
     * ページにヘッダーを取得します。
     * 通常はページ出力時に自動で出力されます。
     * </pre>
     *
     * @return void
     * @static
     */
    public function flushHeader()
    {
        $this->header->flushHeader();
    }

    /**
     * PC/モバイル両用の設定を行う
     *
     * <pre>
     * 以下の使用のWebアプリに設定を行います。
     *
     * 1)PCおよびSB/3GCはUTF-8出力その他携帯はSJIS
     * 2)スクリプトはUTF-8
     * 3)フォームから送られる$submitはUTF-8
     * 4)エージェントに応じたヘッダーを出力します
     * </pre>
     *
     * @param int $mobileSupport モバイルサポート
     *
     * @return void
     */
    private function _initAgent($mobileSupport)
    {
        // POSTエンコード変換コンバートスイッチ
        $bearAgent = BEAR::dependency('BEAR_Agent');
        BEAR::$ua = $bearAgent->getCarrierShortName();
        if (BEAR::$ua == BEAR_Agent::UA_DOCOMO || BEAR::$ua == BEAR_Agent::UA_AU || BEAR::$ua == BEAR_Agent::UA_SOFTBANK) {
            BEAR_Agent::$isMobile = true;
        } else {
            BEAR_Agent::$isMobile = false;
        }
        // 変換ON
        $this->_submitConvert = true;
        // ヘッダー
        if (BEAR_Agent::$isBot) {
            // Bot
            $this->setHeader('Content-Type: text/html; charset=Shift_JIS;');
            $this->_codeFromMoble = 'SJIS-win';
            $this->_charset = 'Shift_JIS';
        } elseif (BEAR::$ua == BEAR_Agent::UA_PC || BEAR::$ua == BEAR_Agent::UA_SOFTBANK) {
            // PC
            $this->header->setHeader('Content-Type: text/html; charset=utf-8;');
            $this->_charset = 'utf-8';
        } else {
            // Mobile General (Docomo/AU)
            $header = 'Content-Type: ' . $this->_mobileHeader . '; charset=Shift_JIS;';
            $this->setHeader($header);
            $this->_codeFromMoble = 'SJIS-win';
            $this->_charset = 'Shift_JIS';
        }
        switch ($mobileSupport) {
            // 絵文字を表示できない時はイメージタグで表示
            case self::SUPPORT_IMG :
                // 絵文字出力アウトプットフィルター出力関数
                $this->smarty->register_outputfilter(array(
                'BEAR_Smarty',
                'onEmojiOutput'));
                break;
            case self::SUPPORT_CONV :
            case 2 :
            default :
                break;
        }
        // 絵文字エンティティconfig
        $emojiConfig = _BEAR_BEAR_HOME . '/BEAR/Smarty/config/emoji/' . BEAR::$ua . '/emoji.conf';
        $this->smarty->config_load($emojiConfig);
    }

    /**
     * UTF-8化コールバック関数
     *
     * @param string &$value 文字列
     *
     * @return void
     * @ignore
     */
    public static function onUTF8(&$value)
    {
        if (!mb_check_encoding($value, $this->_codeFromMoble)) {
            $msg = 'Illigal Submit Values';
            $info = array('value' => $value);
            throw $this->_exception($msg, array(
                'code' => BEAR::CODE_BAD_REQUEST,
                'info' => $info));
        }
        $value = mb_convert_encoding($value, 'UTF-8', $this->_codeFromMoble);
        if (!mb_check_encoding($value, 'UTF-8')) {
            $msg = 'Illigal UTF-8';
            $info = array('value' => $value);
            throw $this->_exception($msg, array(
                'code' => BEAR::CODE_BAD_REQUEST,
                'info' => $info));
        }
    }

    /**
     * HTTP出力
     *
     * 指定されたフォーマットでHTTP出力します。
     * 指定フォーマットのアウトプットファイルを以下の順（BEAR, App)で探します。
     *
     * 1) /BEAR/Resource/output/
     * 2) /App/output/
     *
     * @param string $format  フォーマット
     * @param mixed  $options オプション
     *
     * @return void
     */
    public function output($format = 'print', array $options = array())
    {
        if  (file_exists(_BEAR_APP_HOME . '/App/Resource/output/' . $format . '.php')) {
            $formatFile = _BEAR_APP_HOME . '/App/Resource/output/' . $format . '.php';
        } elseif (file_exists(_BEAR_BEAR_HOME . '/BEAR/Resource/output/' . $format . '.php')) {
            $formatFile = _BEAR_BEAR_HOME . '/BEAR/Resource/output/' . $format . '.php';
        } else {
            $ro = BEAR::factory('BEAR_Ro');
            $ro->setCode(BEAR::CODE_BAD_REQUEST);
            $ro->httpOutput();
        }
        include_once $formatFile;
        if (!function_exists('output' . $format)) {
            $info = array('format' => $format);
            $msg = 'Output format is unavailable.（アウトプットフォーマットが利用できません)';
            throw $this->_exception('Bad Page Request', array(
                'info' => $info));
        }
        $ro = call_user_func('output' . $format, $this->_values, $options);
        /* @var $ro BEAR_Ro */
        $ro->outputHttp();
        exit();
    }

    /**
     * ページ引数への変数インジェクト
     *
     * @param string $key     ページ引数キー
     * @param mixed  $val     ページ引数にインジェクトする値
     * @param mixed  $default デフォルト
     */
    public function injectArg($key, $val, $default = null)
    {
        $this->_args[$key] = !is_null($val) ? $val : $default;
    }

    /**
     * GETをインジェクト
     *
     * @param string $key
     * @param string $getKey
     *
     * @return void
     */
    public function injectGet($key, $getKey = null, $default = null){
        $getKey = $getKey ? $getKey : $key;
        if (isset($_GET[$getKey])) {
            $this->_args[$key] = $_GET[$getKey];
        } elseif ($default) {
            $this->_args[$key] = $default;
        }
    }

    /**
     * ページ引数へ連想配列でインジェクト
     *
     * @param array $args 引数全部
     */
    public function injectArgs($args)
    {
        $args = (array)BEAR::loadValues($args);
        $this->_args = array_merge($this->_args, $args);
    }

    public function injectAjaxRequest()
    {
        $ajax = BEAR::dependency('BEAR_Page_Ajax');
        /** @param $ajax BEAR_Page_Ajax */
        $ajaxReq = $ajax->getAjaxRequest();
        $this->_args = array_merge($this->_args, $ajaxReq);
    }

    public function injectAjaxValues()
    {
        $ajax = BEAR::dependency('BEAR_Page_Ajax');
        /** @param $ajax BEAR_Page_Ajax */
        $ajaxReq = $ajax->getAjaxRequest();
        $this->_args = array_merge($this->_args, $ajaxReq);
    }

    /**
     * ページ引数の取得
     *
     * @return array ページ引数
     */
    public function getArgs()
    {
        return $this->_args;
    }

    /**
     * ページ終了
     *
     * <pre>
     * ページを途中で終了します。コードとメッセージを指定すると指定HTTPコードのヘッダーと出力画面で終了します。
     * </pre>
     * s
     * @param int    $httpCode HTTPコード
     * @param string $msg      HTTPコードメッセージ(200以外）
     *
     * @return void
     */
    public function end($httpCode = 200, $msg = 'Error')
    {
        if ($httpCode === 200) {
            $main = BEAR::dependency('BEAR_Main');
            $main->end();
        } else {
            ob_clean();
            throw new Panda_Exception($msg, $httpCode);
        }
    }

    /**
     * setした値をすべて取得
     *
     * @return array
     */
    public function getValues()
    {
        return $this->_values;
    }

    /**
     * ページキャッシュのキーを生成
     *
     * @return mixed (bool)falseキャッシュ不可 | (string)キャッシュキー
     */
    public function getCacheKey()
    {
        static $result = null;

        // キーの同一性を保障＆パフォーマンス
        if (!is_null($result)) {
            return $result;
        }
                // $_GET['_start'] は BEAR_Page::PAGER_NUMと同じ
        $pageConfig = $this->_config['mobile'] . serialize(array($this->getArgs(), $this->_config));
        $pagerKey = isset($_GET['_start']) ? $_GET['_start'] : '';
        $result = get_class($this) . '-' . $pagerKey . '-' . ($pageConfig);
        return $result;
    }

    /**
     *
     * @return unknown_type
     */
    public function clearPageCache(){
        $key = $this->getCacheKey();
        $cache = BEAR::dependency('BEAR_Cache');
        $cache->delete($key);
    }
}

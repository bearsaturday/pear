Try Sample first.

1) place data/htdocs/panda_sample under htdocs.
2) edit papnda_ini.file,
3) oepn  http://example.com/panda_sample/

Panda Quick Manual

English
http://code.google.com/p/panda-project/wiki/quickmanualen

Japanese
http://code.google.com/p/panda-project/wiki/quickmanual
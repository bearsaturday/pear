<?php

/**
 * App
 * 
 * @category   BEAR
 * @package    App
 * @subpackage Class
 * @author     $Author:$ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id:$
 * @link       http://www.example.com/
 */

/**
 * Untitled Class
 *
 * <pre>
 * description here...
 *
 * Example 1. 
 *
 * </pre>
 * <code>
 * // sample code here...
 * </code>
 *
 * @category   BEAR
 * @package    App
 * @subpackage Class
 * @author     $Author:$ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id:$
 * @link       http://www.example.com/
 */
class Example
{

    /**
     * クラス定数
     */
    const SAMPLE = 0;

    /**
     * シングルトンインスタンス
     *
     * @var object
     */
    private $_instance;

    /**
     * Untitled
     *
     * <pre>Enter description here...
     * </pre>
     *
     * @return Example
     */
    function &getInstance()
    {
        static $_instance;
        
        if (!isset($_instance)) {
            $_instance = new self();
        }
        return $_instance;
    }
}
<?php

/**
 * App_Page
 * 
 * @category BEAR
 * @package  App_Page
 * @author   $Author:$ <username@example.com>
 * @version  SVN: Release: $Id:$
 */

require_once 'App.php';

/**
 * Untitled Page
 * 
 * description here...
 *
 * @category BEAR
 * @package  App_Page
 * @author   $Author:$ <username@example.com>
 * @version  SVN: Release: $Id:$
 */
class Index extends App_Page
{

    function onInit($args)
    {
    }

    function onOutput()
    {
        $this->display();
    }

    function onAction($submit)
    {
        $this->set('submit', $submit);
        $this->display();
    }
}

new BEAR_Main('Index');
<?php
/**
 * BEAR_Vo
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Vo
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Vo.php 537 2009-03-10 06:50:01Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Vo/BEAR_Vo.html
 */

/**
 * バリューオブジェクトクラス
 *
 * <pre>
 * リソースのバリューオブジェクトクラスです。
 * リソースの内容とリソースに対するCRUDインターフェイスを備えています。
 * ボディ情報（リソース状態）、メタ情報（リソースヘッダー）、リソースリンク、
 * 状態コードのプロパティを持ち、リソースの作成、読み込み、変更、削除の
 * インターフェイスを持つ事ができます。
 *
 * BEAR_Resouceクラスがリソースを扱うクラスなのに対して、
 * リソースとして扱われるがこのクラスのオブジェクトです。
 * CSVファイルなどのスタティックリソースや、外部RSS等のリモートリソースも
 * このバリューオブジェクトに変換されて扱われます。
 *
 * このオブジェクトはHTTP通信の仕組みそのものにも似ています。
 * ヘッダーとボディを持ち、POST/GET/PUT/DELETEに対応する
 * インターフェイス(onCreate, onRead, onUpdate, onDelete)を持ちます。
 * このオブジェクトそのものをHTTP出力することができます。x
 * ml/json/phpなどのフォーマットを指定して
 * outputHttp()メソッドを使うとそのままHTTP出力されます。
 *
 * Example. オブジェクト格納例）DBページャーの結果VO
 *
 * ボディ　：　ページングされたデータ
 * ヘッダー：　件数や現在の表示ページ番号などのメタ情報
 * リンク　：　次ページリンクHTML
 * コード　 : 200(OK)
 *
 * 以下は指定したフォーマットで時間を取得できるmyTimeリソースの実装例です。
 * </pre>
 * <code>
 * class myTime extends BEAR_Vo
 * {
 *   public function onRead($values){
 *      $format = $values['format'];
 *      retruen date($format);
 *   }
 * }
 * </code>
 * <pre>
 * ※　時間は削除、変更、作成はできないのでreadメソッドだけが実装されています。
 * ※　returnのフォーマットは2種類あります。
 * RAWデータ（配列やスカラー値）かバリューオブジェクトです。
 *　
 * データだけを返せば十分なときはRAWデータでデータにヘッダーやリンクなどの
 * 属性情報をつけて返したい場合はバリューオブジェクト(BEAR_VOオブジェクト）
 * で返します。
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Vo
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Vo.php 537 2009-03-10 06:50:01Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Vo/BEAR_Vo.html
 */
class BEAR_Vo extends ArrayObject implements BEAR_Vo_Interface, IteratorAggregate
{

    /**
     * コード OK
     */
    const CODE_OK = 200;

    /**
     * コード Bad Request
     */
    const CODE_BAD_REQUEST = 400;

    /**
     * コード　Internal Error
     */
    const CODE_ERROR = 500;

    /**
     * set() configキー
     */
    const CONFIG_PAGER = 'pager';

    /**
     * 最初のリンクフラグ
     *
     * @bool
     */
    private static $_isFirstLink = true;

    private static $_linksBody = array();


    /**
     * バリュー
     *
     * @var mixed
     */
    private $_body;

    /**
     * メタ情報
     *
     * @var array
     */
    private $_headers;

    /**
     * リンク情報
     *
     * @var array
     */
    private $_links;

    /**
     * 状態コード
     *
     * @var int BEAR::CODE_OK | BEAR::CODE_BAD_REQUEST | BEAR::CODE_ERROR
     */
    private $_code = BEAR::CODE_OK;

    /**
     * 設定(リクエスト情報)
     *
     * @var array
     */
    private $_config = array();

    /**
     * コンストラクタ
     *
     * @param string $body    ボディ
     * @param array  $headers ヘッダー
     * @param array  $links   リンク
     * @param int    $code    コード
     */
    function __construct($body = null, $headers = null, $links = null, $code = BEAR::CODE_OK)
    {
        $this->_body    = $body;
        $this->_headers = $headers;
        $this->_links   = $links;
        $this->_code    = $code;
    }

    /**
     * リソース作成
     *
     * リソースを作成します。このメソッドはキャッシュオプションが使えます。
     *
     * @param array $values 引数
     *
     * @return mixed
     */
    public function onCreate($values)
    {
        $vo = new BEAR_Vo();
        $vo->setCode(BEAR::CODE_BAD_REQUEST);
        $vo->setHeader('values', $values);
        return $vo;
    }

    /**
     * リソース読み込み
     *
     * オプションにcacheが使えます
     *
     * @param array $values 引数
     *
     * @return mixed
     */
    public function onRead($values)
    {
        $vo = new BEAR_Vo();
        $vo->setCode(BEAR::CODE_BAD_REQUEST);
        $vo->setHeader('values', $values);
        return $vo;
    }

    /**
     * リソース変更
     *
     * リソースを変更します。このメソッドはPOEオプション
     * （一度だけ実行する）オプションが使えます。
     *
     * @param array $values 引数
     *
     * @return mixed
     */
    public function onUpdate($values)
    {
        $vo = new BEAR_Vo();
        $vo->setCode(BEAR::CODE_BAD_REQUEST);
        $vo->setHeader('values', $values);
        return $vo;
    }

    /**
     * リソース消去
     *
     * リソースを消去します。このメソッドはPOEオプション
     * （一度だけ実行する）オプションが使えます。
     *
     * @param array $values 引数
     *
     * @return mixed
     */
    public function onDelete($values)
    {
        $vo = new BEAR_Vo();
        $vo->setCode(BEAR::CODE_BAD_REQUEST);
        $vo->setHeader('values', $values);
        return $vo;
    }

    /**
     * シンプルアサーション
     *
     * <pre>
     * 単純なboolean値を引数にしてfalseの時は例外を投げ、
     * リソースの結果は400エラー(Bad Request)のバリューオブジェクト(BEAR_Voオブジェクト)になります。
     * onRead, onCreateなどCRUDメソッドに値が正しく渡されているか確認するために使用します。
     * </pre>
     *
     * @param bool $bool 条件
     *
     * @return void
     */
    public static function assert($bool)
    {
        if (!$bool) {
            throw new Exception('Bad Resource Request', BEAR::CODE_BAD_REQUEST);
        }
    }

    /**
     * 必須項目アサーション
     *
     * <pre>
     * 連想配列に指定のキー配列が全て含まれてるか検査し、問題があれば例外を投げます。
     * リソースの結果は400エラー(Bad Request)のバリューオブジェクト(BEAR_Voオブジェクト)になります。
     * onRead, onCreateなどCRUDメソッドに値が正しく渡されているか確認するために使用します。
     * </pre>
     *
     * @param array $keys   必須キー配列
     * @param array $values テストする配列
     *
     * @return void
     * @throw BEAR_Exception
     */
    public function assertRequired(array $keys, $values)
    {

        if (count(array_intersect($keys, array_keys($values))) != count($keys)) {
            throw new BEAR_Exception('Bad Resource Request', BEAR::CODE_BAD_REQUEST);
        }
    }

    /**
     * リソースエラー
     *
     * リソース内でエラーを発生させます。
     *
     * @param string $msg エラーメッセージ
     *
     * @return void
     */
    public static function error($msg)
    {
        throw new Exception('Internal Resource Error: ' . $msg, BEAR::CODE_ERROR);
    }

    /**
     * リソースボディの取得
     *
     * ボディ（リソース取得結果本体）を取得します。
     *
     * @return string
     */
    public function getBody()
    {
        return $this->_body;
    }

    /**
     * リソースヘッダーの取得
     *
     * @return array
     */
    public function getHeaders()
    {
        return $this->_headers;
    }

    /**
     * リソースリンクの取得
     *
     * リソースのリンクを取得します。
     *
     * @return array
     */
    public function getLinks()
    {
        return $this->_links;
    }

    /**
     * リソースボディをセット
     *
     * リソースのボディ（リソース結果）をセットします。
     *
     * @param mixed $body ボディ
     *
     * @return void
     */
    public function setBody($body)
    {
        $this->_body = $body;
    }

    /**
     * リソースヘッダーセット
     *
     * <pre>
     * キーを指定してリソースヘッダーをセットします。
     * 予約済みキーはこのクラスのconstとして定義されています。
     * </pre>
     *
     * @param string $key    ヘッダーキー
     * @param string $header ヘッダー
     *
     * @return void
     */
    public function setHeader($key, $header)
    {
        $this->_headers[$key] = $header;
    }

    /**
     * リンクのセット
     *
     * <pre>
     * リソースリンクをセットします。
     * 予約済みキーはこのクラスのconstとして定義されています。
     * </pre>
     *
     * @param string $key  リンクキー
     * @param string $link リンク
     *
     * @return void
     */
    public function setLink($key, $link)
    {
        $this->_links[$key] = $link;
    }

    /**
     * 状態コード設定
     *
     * @param int $code コード
     *
     * @return void
     *
     */
    public function setCode($code)
    {
        if ($code == BEAR::CODE_OK || $code == BEAR::CODE_BAD_REQUEST || $code == BEAR::CODE_ERROR) {
            $this->_code = $code;
        } else {
            trigger_error('Illigal BEAR_Vo code', E_USER_WARNING);
        }
    }

    /**
     * 状態コードの取得
     *
     * @return int code
     *
     * @return int (200|400|500)
     */
    public function getCode()
    {
        return $this->_code;
    }

    /**
     * 文字列化
     *
     * シリアリズしてbodyを返します。
     *
     * @return string
     */
    public function __toString()
    {
        return serialize($this->_body);
    }

    /**
     * HTTP出力
     *
     * <pre>
     * BEAR_VoバリューオブジェクトをHTTP出力します。
     * _codeプロパティがレスポンスコード、_header配列プロパティのうち
     * 文字列のものがHTTPヘッダー,_bodyプロパティがHTTPボディとして出力されます。
     * </pre>
     *
     * @return void
     */
    public function outputHttp()
    {
        //ヘッダー
        switch ($this->_code) {
            case BEAR::CODE_BAD_REQUEST :
                header('HTTP/1.x 400 Bad Request');
                if (!$this->_body) {
                    $this->setBody('400 Bad Request (BEAR)');
                }
                break;
            case BEAR::CODE_ERROR :
                header('HTTP/1.x 500 Server Error');
                if (!$this->_body) {
                    $this->setBody('500 Server Error (BEAR)');
                }
                break;
            case BEAR::CODE_OK :
            default :
                header('HTTP/1.x 200 OK');
        }
        if (is_array($this->_headers)) {
            foreach ($this->_headers as $header) {
                if (is_string($header)) {
                    header($header);
                }
            }
        }
        BEAR_Log::appLog('HTTP Output', array('header'=>headers_list(), 'body'=>$this->_body));
        echo $this->_body;
        exit();
    }

    /**
     * ArrayObject配列の個別ROWオフセット取得
     *
     * <pre>
     * 暗黙的に offsetExists が呼ばれたりはしない。
     * & を使ったリファレンス返しはできない。
     * </pre>
     *
     * @param mixed $offset オフセット
     *
     * @return mixed
     *
     * @ignore
     */
    public function offsetGet($offset)
    {
        return $this->_body[$offset];
    }

    /**
     * 値をbodyにセット
     *
     * <pre>
     * & を使ったリファレンス渡しはできません。
     * $a[] = $value のように呼ばれた場合$offset には null が渡されます。
     * </pre>
     *
     * @param mixed $offset セットするオフセット
     * @param mixed $value  セットする値
     *
     * @return void
     * @ignore
     */
    public function offsetSet($offset, $value)
    {
        $this->_body[$offset] = $value;
    }

    /**
     * issetで呼ばれbodyに値があるか調べる。
     *
     * <pre>
     * array_key_exists では呼ばれません。
     * </pre>
     *
     * @param mixed $offset オフセット
     *
     * @return bool
     * @ignore 
     */
    public function offsetExists($offset)
    {
        return isset($this->_body[$offset]);
    }

    /**
     *　unsetで呼ばれ指定のオフセットのbody値を消去。
     *
     * <pre>
     * array_key_exists では呼ばれません。
     * </pre>
     *
     * @param mixed $offset オフセット
     *
     * @return void
     * @ignore 
     */
    public function offsetUnset($offset)
    {
        unset($this->_body[$offset]);
    }

    /**
     * イテレーター取得
     *
     * arrayとして振舞うための実装です。
     *
     * @return BEAR_Vo_Iterator
     * @ignore 
     */
    public function getIterator()
    {
        $this->_body = is_array($this->_body) ? $this->_body : array();
        include_once 'BEAR/BEAR/Vo/Iterator.php';
        $obj = BEAR::dependency('BEAR_Vo_Iterator', $this->_body, false);
        return $obj;
    }

    /**
     * count取得
     *
     * arrayとして振舞うための実装です。
     *
     * @return int
     * @ignore
     */
    public function count()
    {
        return count($this->_body);
    }

    /**
     * array関数の適用
     *
     * <pre>
     * array関数適用用のインターフェイスです。
     * </pre>
     *
     * @param string $fname 関数名
     * @param mixed  $args  関数の引数
     *
     * @return mixed
     *
     * @ignore
     */
    public function __call($fname, $args)
    {
        if (function_exists("array_$fname")) {
            $arr = call_user_func_array("array_$fname", array((array)$this->_body) + $args);
            if (is_array($arr)) {
                $this->_body = $arr;
                return $this;
            } else {
                return $arr;
            }
        }
    }

    /**
     * ksour
     *
     * @return BEAR_Vo
     * @ignore
     */
    public function ksort()
    {
        parent::ksort();
        return $this;
    }

    /**
     * append
     *
     * @param mixed $val 追加する値
     *
     * @return BEAR_Vo
     * @ignore
     */
    public function append($val)
    {
        parent::append($val);
        return $this;
    }

    /**
     * ビューにセット
     *
     * readの後ろにつなげて使います。
     *
     * <pre>
     * $config
     * 'pager' string ページャーをアサインする変数名
     * 'vo'    bool   VOアサイン
     * </pre>
     *
     * <code>
     * $resource->$read($params)->set('user');
     * </code>
     *
     * @param string $tplVar テンプレート変数名 省略すればURI(/を_に置換)
     * @param array  $config 設定
     *
     * @return void
     */
    public function set($tplVar=false, array $config=array())
    {
        $page = BEAR::get('page');
        if (BEAR_Vo::$_linksBody) {
            $this->_setLinksBody($page);
            $this->_setPager($page);
            return $this;
        }
        if ($tplVar === false) {
            $tplVar = str_replace(DIRECTORY_SEPARATOR, '_', $this->header['uri']);
        }
        /* @var $page App_Page */
        $val = (isset($config['vo']) && $config['vo'] === true) ? $this : $this->_body;
        $page->set($tplVar, $val);
        $this->_setPager($page);
        return $this;
    }

    /**
     * linkの結果をアサイン
     *
     * @return void
     */
    private function _setLinksBody(&$page)
    {
        foreach (BEAR_Vo::$_linksBody as $tplVar => $val){
            $page->set($tplVar, $val);
        }
    }

    /**
     * ページャーセット
     * 
     * ページャーがあればアサインします。デフォルトはpagerです。
     * 
     * @return void
     */
    private function _setPager(&$page)
    {
        if (isset($this->_links['pager'])) {
            $pager  = array('links' => $this->_links['pager'], 'info' => $this->_headers);
            $tplVar = isset($config['pager']) ? $config['pager'] : self::CONFIG_PAGER;
            /* @var $page App_Page */
            $page->set($tplVar, $pager);
        }
    }
    /**
     * デバック表示
     *
     * <code>
     * $resource->$read($params)->p();
     * $resource->$read($params)->set('user')->p();
     * </code>
     *
     * @return BEAR_Vo
     */
    public function p()
    {
        $resource = BEAR::dependency('BEAR_Resource');
        $vo = $resource->getVo();
        if (BEAR_Vo::$_linksBody) {
            print_a(BEAR_Vo::$_linksBody, "label:links");
        } else {
            print_a($this->_body, "label:{$this->_uri}");
        }
        return $this;
    }

    /**
     * リソースリンクを取得
     *
     * <pre>
     * リソースのリンクを取得します。
     * リンクはリンクキーをキーにリンクURIを値にした配列をVOリソースの中のonLinkメソッドで返す事で実現できます。
     * </pre>
     */
    public function link($link)
    {
        //readをset
        if (BEAR_Vo::$_isFirstLink === true) {
            $tplVar = str_replace(DIRECTORY_SEPARATOR, '_', $this->header['uri']);
            BEAR_Vo::$_linksBody[$tplVar] = $this->_body;
            BEAR_Vo::$_isFirstLink = false;
        }
        $resource = BEAR::dependency('BEAR_Resource');
        $vo = $resource->getVo();
        $body = $vo->getBody();
        if (!method_exists($vo, 'onLink')){
            //            throw new BEAR_Exception('no links method. Vo class=' . get_class($vo), BEAR::CODE_BAD_REQUEST);
        }
        $links = $vo->onLink($body);
        if (!isset($links[$link])) {
            throw new BEAR_Exception('Link is not found' , BEAR::CODE_BAD_REQUEST, array('link URI'=> $links[$link]));
        }
        $params = array(
            'uri'=>$links[$link],
            'values'=>array(),
            'options'=>array()
        );
        $vo = $resource->read($params);
        // linkをセット
        BEAR_Vo::$_linksBody[$link] = $vo->getBody();
        return $vo;
    }

    public function setConfig($config){
        $this->_config = $config;
    }

    public function getConfig() 
    {
        return $this->_config;
    }
}
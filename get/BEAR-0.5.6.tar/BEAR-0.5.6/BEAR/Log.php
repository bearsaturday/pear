<?php

/**
 * BEAR_Log
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Log
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Log.php 542 2009-03-10 12:55:40Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Log/BEAR_Log.html
 */

/**
 * ログ
 *
 * <pre>
 * ログクラスです
 * </pre>
 *
 * <code>
 * BEAR_Log::appLog($label, $data);
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Log
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Log.php 542 2009-03-10 12:55:40Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Log/BEAR_Log.html
 */

class BEAR_Log
{

    /**
     * アプリケーションログ
     */
    const TYPE_APP = 0;

    /**
     * エラーログ
     */
    const TYPE_ERROR = 1;

    /**
     * リソースアクセスログ
     */
    const TYPE_RESOURCE = 2;

    /**
     * アプリケーションログ
     *
     * @var array
     */
    public static $log;

    /**
     * エラーログ
     *
     * @var array
     */
    public static $errorLog;

    /**
     * エラー統計
     *
     * @var int
     */
    public static $errorStat;

    /**
     * syslogのlocal番号
     *
     * デフォルトは5
     */
    public static $local = LOG_LOCAL5;

    /**
     * アプリユーザー
     *
     * ユーザーの特定につながる情報をストアします。
     */
    private $_user = '';

    /**

    **
    * アプリケーションログを記録
    *
    * <pre>
    * アプリケーションログを記録します。
    * このログは画面上で確認できる一時的なスクリーンログです。
    * </pre>
    *
    * @param string $label ラベル
    * @param mixed  $log   値
    *
    * @return void
    * @access public
    * @static
    */
    public static function appLog($label, $log)
    {
        self::$log[][$label] = $log;
    }

    /**
     * リソースログ
     *
     * <pre>
     * App::onResourceLog($method, $uri, $values)をコールバックし
     * falseが返えらなかったらsysrogにリソースログを記録。
     * read操作はログには記録されません。
     * </pre>
     *
     * @param string $method メソッド
     * @param string $uri    URI
     * @param array  $values 引数
     *
     * @return void
     */
    public static function resourceLog($method, $uri, $values)
    {
        $fullUri = "{$method} {$uri}" . (is_array($values) ? '?' . http_build_query($values) : '');
        BEAR_Log::appLog('Resource', $fullUri);
        if ($method == BEAR_Resource::METHOD_READ) {
            return;
        }
        if (is_callable(array('App', 'onResourceLog'))) {
            $result = App::onResourceLog($method, $uri, $values);
        } else {
            $result = true;
        }
        if ($result !== false) {
            $logger = &Log::singleton('syslog', LOG_USER, 'BEAR RES');
            $logger->log($fullUri);
        }
    }

    /**
     * コンストラクタ
     *
     */
    function __construct()
    {
        if (App::$debug) {
            self::appLog(array('URI' => $_SERVER['REQUEST_URI'], 'time' => date('r')));
        }
    }

    /**
     * スクリプトシャットダウン時のログ処理
     *
     * <pre>
     * アプリケーションログ、smartyアサインログ、グローバル変数ログ、
     * リクエストURIをシリアライズしてファイル保存します。
     * デバックモードの時のみ使用します。
     * 保存されたログは/beardev/のLogタブでブラウズできます。
     * シャットダウン時実行のメソッドとしてフレームワーク内で登録され、
     * スクリプト終了時に実行されます。
     * フレームワーク内で使用されます。
     * </pre>
     *
     * @return void
     * @ignore
     *
     */
    public static function onShutDownDebug()
    {  
        $isBeardev = isset($_SERVER['beardev']);
        if (App::$debug !== true || $isBeardev || PHP_SAPI === 'cli') {
            return;
        }
        $log = array();
        // unserializeの時のautoloadを無効に
        ini_set('unserialize_callback_func', '');
        // unserializeしたオブジェクトによってオートローダーがコールされないようにするため
        //　ajaxログ
        if (BEAR_Page::isAjaxRequest()){
            self::_onShutDownDebugAjax();
            return;
        }
        BEAR::disableAutoLoader();
        $pageLogPath = _BEAR_APP_HOME . '/logs/page.log';
        if (file_exists($pageLogPath) && !is_writable($pageLogPath)) {
            return;
        }
        // page ログ
        $pageLog         = file_exists($pageLogPath) ? unserialize(file_get_contents($pageLogPath)) : '';
        $var  =show_vars('trim_tabs:2;show_objects:0;max_y:30;avoid@:1; return:1');
        if (class_exists('BEAR_Smarty')) {
            $smarty = BEAR::dependency('BEAR_Smarty');
            $log['smarty'] = $smarty->_tpl_vars;
        } else {
            $log['smarty'] = '';
        }
        $oldPageLog = isset($pageLog['page']) ? $pageLog['page'] : array();
        $newPageLog = array('page'=>BEAR_Log::$log, 'uri'=>$_SERVER['REQUEST_URI']);
        $oldPageLog[] = $newPageLog;
        if (count($oldPageLog) > 3) {
            array_shift($oldPageLog);
        }
        $log += array('page' => $oldPageLog ,'var' => $var, 'include'=>get_included_files());
        if (isset($_SERVER['REQUEST_URI'])) {
            $log += array('uri' => $_SERVER['REQUEST_URI']);
        }
        $reg = BEAR::getAll();
        $log['reg'] = '<h2>Keys</h2>' . print_a($reg, "show_objects:0; return:1") .'<h2>Values</h2>'  . print_a($reg, "return:1");
        file_put_contents($pageLogPath, serialize($log));
        exit();
    }

    private static function _onShutDownDebugAjax()
    {
        $ajaxLogPath = _BEAR_APP_HOME . '/logs/ajax.log';
        $ajaxLog         = file_exists($ajaxLogPath) ? unserialize(file_get_contents($ajaxLogPath)) : null;
        $log = array('page'=>BEAR_Log::$log, 'uri'=>$_SERVER['REQUEST_URI']);
        $ajaxLog[] = $log;
        if (count($ajaxLog) > 5) {
            array_shift($ajaxLog);
        }
        file_put_contents(_BEAR_APP_HOME . '/logs/ajax.log', serialize($ajaxLog));
    }
    private function _onShutDownDebug()
    {
        file_put_contents( _BEAR_APP_HOME . '/logs/ajax.log', serialize($log));

    }

    /**
     * スクリプトシャットダウン時のログ処理
     *
     * @return void
     */
    public static function onShutDownLive()
    {
    }
}
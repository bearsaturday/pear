<?php

require_once 'App.php';
require_once 'BEAR/BEAR/Cache.php';
require_once 'BEAR/BEAR.php';

require_once 'PHPUnit/Framework/TestCase.php';

/**
 * BEAR_Cache test case.
 */
class BEAR_CacheTest extends PHPUnit_Framework_TestCase
{

    /**
     * @var BEAR_Cache
     */
    private $BEAR_Cache;

    /**
     * Prepares the environment before running a test.
     */
    protected function setUp()
    {
        parent::setUp();
        
    // TODO Auto-generated BEAR_CacheTest::setUp()
    

    }

    /**
     * Cleans up the environment after running a test.
     */
    protected function tearDown()
    {
        // TODO Auto-generated BEAR_CacheTest::tearDown()
        

        $memcache = null;
        
        parent::tearDown();
    }

    /**
     * Constructs the test case.
     */
    public function __construct()
    {    // TODO Auto-generated constructor
    }

    /**
     * Tests BEAR::dependency('BEAR_Cache')
     */
    public function assstestGetInstance()
    {
        // TODO Auto-generated BEAR_CacheTest::testGetInstance()
        BEAR_Cache::destoryInstance();
        $memcache = BEAR_Cache::getInstance(array('engine' => BEAR_Cache::ENGINE_NONE));
        $this->assertTrue(get_class($memcache) == 'BEAR_Cache_Adapter_None');
        //
    

    }

    public function testGetInstanceMemcache()
    {
        BEAR_Cache::destoryInstance();
        $memcache = BEAR_Cache::getInstance(array('engine' => BEAR_Cache::ENGINE_MEMCACHE));
        $this->assertTrue(get_class($memcache) == 'BEAR_Cache_Adapter_Memcache');
    
    }

    public function testActive()
    {
        BEAR_Cache::destoryInstance();
        $memcache = BEAR_Cache::getInstance(array('engine' => BEAR_Cache::ENGINE_MEMCACHE));
        $memcache->setActive(true);
        $this->assertTrue($memcache->isActive());
    
    }

    public function testSet()
    {
        BEAR_Cache::destoryInstance();
        $memcache = BEAR_Cache::getInstance(array('engine' => BEAR_Cache::ENGINE_MEMCACHE));
        $memcache->set('kuma', 10);
        $this->assertTrue($memcache->get('kuma') == 10);
    }

    public function testDelete()
    {
        BEAR_Cache::destoryInstance();
        $memcache = BEAR_Cache::getInstance(array('engine' => BEAR_Cache::ENGINE_MEMCACHE));
        $memcache->set('kuma', 10);
        $memcache->delete('kuma');
        $this->assertTrue($memcache->get('kuma') != 10);
    }

    public function testDeleteAll()
    {
        BEAR_Cache::destoryInstance();
        $memcache = BEAR_Cache::getInstance(array('engine' => BEAR_Cache::ENGINE_MEMCACHE));
        $memcache->set('kuma', 10);
        $memcache->deleteAll();
        $this->assertTrue($memcache->get('kuma') != 10);
    }

    public function testSetLife()
    {
        BEAR_Cache::destoryInstance();
        $memcache = BEAR_Cache::getInstance(array('engine' => BEAR_Cache::ENGINE_MEMCACHE));
        $memcache->set('kuma', 10, 2);
        $this->assertTrue($memcache->get('kuma') == 10);
        sleep(3);
        $this->assertTrue($memcache->get('kuma') != 10);
    
    }
}


<?php
/**
 * App
 *
 * @category   BEAR
 * @package    App
 * @subpackage Page
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: Page.php 1041 2009-10-14 12:41:44Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 */
/**
 * アプリケーションページ
 *
 * @category   BEAR
 * @package    App
 * @subpackage Page
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: Page.php 1041 2009-10-14 12:41:44Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 * @abstract
 */
abstract class App_Page extends BEAR_Page
{

    /**
     *  セッション
     *
     * @var BEAR_Session
     */
    protected $_session;

    /**
     * リソースアクセス
     *
     * @var BEAR_Resource
     */
    protected $_resource;

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * インジェクション
     *
     * @return void
     */
    public function onInject()
    {
        $this->_session = BEAR::dependency('BEAR_Session');
        $this->_resource = BEAR::dependency('BEAR_Resource');
    }

    /**
     * 出力
     *
     * @return void
     */
    public function onOutput()
    {
        $this->display();
    }

    /**
     * 例外
     *
     * @return void
     */
    public function onException(Exception $e){
        //p($e->getMessage());
        throw $e;
    }
}

<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Emoji
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Adapter.php 687 2009-07-03 14:49:14Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Emoji/BEAR_Emoji.html
 */
/**
 * Andoroidエージェントアダプター
 *
 * エージェントに依存する入出力関連の依存と、エージェント別テンプレート選定に使われるエージェントのロールを設定するoエージェントアダプタークラスです。
 *
 * @category  BEAR
 * @package   BEAR_Emoji
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Adapter.php 687 2009-07-03 14:49:14Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Emoji/BEAR_Emoji.html
 * @abstract
 *  */
class BEAR_Emoji_Adaptor_Docomo
{
    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    public function __construct(array $config)
    {
    }

    public function onInject()
    {
        $file =  _BEAR_HOME_BEAR  . "/BEAR/Emoji/Conf/{$this->_config['ua']}.php";
        include $file;
        $this->_emoji = $config;
    }
}
public function init()
{
    $config = array();
    $config['output_filter'] = true;
    $config['charset'] ='utf-8';
    $this->_config['role'] = array(BEAR_Emoji::UA_IPHONE, BEAR_Emoji::UA_MOBILE, BEAR_Emoji::UA_DEFAULT);
    return array();
}
}
<?php
/**
 * BEAR_Main
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Main
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Main.php 780 2009-07-28 23:49:34Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Main/BEAR_Main.html
 */
/**
 * メインクラス
 *
 * <pre>
 * ページオブジェクトを実行するクラスです。。
 * ページに実装されたイベントハンドラをイベント毎にコールします。
 * キャッシュオプションでページの初期化（onInit）をキャッシュするinitキャッシュ、
 * テンプレート生成までも含めたページキャッシュのキャッシュオプションを
 * 指定することができます。
 *
 * Example 1.キャッシュページの実行
 * </pre>
 * <code>
 * class Blog_RSS extends App_Page{
 * }
 * $config = array('page_cache'=>'init', 'life'=>60);
 * new BEAR_Main('Blog_RSS', $config);
 * //10分間のページキャッシュ
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Main
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Main.php 780 2009-07-28 23:49:34Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Main/BEAR_Main.html
 */
class BEAR_Main extends BEAR_Base
{

    /**
     * ページインスタンス
     *
     * @var object App_Page
     */
    private $_page = null;

    /**
     * ページ引数
     *
     * ページの$_GETや$_COOKIE,CLIの引数。
     *
     * @var array
     */
    private $_args = array();

    /**
     * initキャッシュの値
     *
     * init()でset()した変数をキャッシュします。
     *
     * @var mixed mixed  (bool)true キャッシュ保存  | array キャッシュ内容
     */
    private $_initCache = false;

    /**
     * サブミット値
     *
     * $_POSTか$_GETの内容が入ります
     * BEAR_Page::queryMethodプロパティの設定に依存します
     *
     * @var mixed
     * @access private
     */
    private $_submit = false;

    /**
     * Ajaxサブミットか
     */
    private $isAjaxSubmit = false;

    /**
     * コンストラクタ
     *
     * @param array $config
     */
    public function __construct(array $config)
    {
        parent::__construct($config);
        // ページを生成してレジストリにセット
        $this->_page = BEAR::factory($this->_config['page_class'], $config);
        BEAR::set('page', $this->_page);
    }

    /**
     * ページクラス実行
     *
     * <pre>
     * 指定されたページクラスをインスタンス化し実行します。<var>$lifeTime</var><pre>で
     * ページ全体のキャッシュ時間が指定できます。
     * （デフォルトは0=キャッシュしない）キャッシュのIDはURLとBEAR::$uaで決まります。
     *
     * ページ内から別のページを生成するために</pre><var>$newPage</var>
     * ページオプションがあります。デフォルトのfalseの場合はページファイルを実行
     * しないクラスファイルとして使用できるようになります。
     * </pre>
     *
     * @param string $pageClass ページクラス名
     * @param array  $config    設定
     *
     * @return void
     */
    public static function run($pageClass, array $config = array())
    {
        static $_isFirstRun = true;
        if ($_isFirstRun === false) {
            $log = BEAR::dependency('BEAR_Log');
            $log->log("Page Include", $pageClass);
            return;
        }
        $_isFirstRun = false;
        // ページクラス存在チェック
        if (!$pageClass || !class_exists($pageClass, false)) {
            $info = array('page_class' => $pageClass);
            throw $this->_exception('Page class is not defined.（ページクラスが定義されていません)', array(
                'info' => $info));
        }
        // フォーム初期化
        if (class_exists('BEAR_Form', false)) {
            BEAR_Form::init();
        }
        // メイン実行
        $config['page_class'] = $pageClass;
        try {
            $main = BEAR::dependency('BEAR_Main', $config);
            $main->_run();
        } catch(BEAR_Exception $e) {
            if ($e->getRedirect()) {
                $header = BEAR::dependency('BEAR_Page_Header');
                $header->redirect($e->getRedirect());
            }
            $log = BEAR::dependency('BEAR_Log');
            $log->log("BEAR_Page_Exception", $e);
            if (isset($main->_page) && method_exists($main->_page, 'onException')) {
                $main->_page->onException($e);
            }
        } catch(Exception $e) {
            throw $e;
        }
    }

    /**
     * ページ開始
     *
     * ページを実行します。
     *
     * @return void
     */
    private function _run()
    {
        // debugログ
        if ($this->_config['debug']) {
            $this->_runDebug();
        }
        // init/ページキャッシュ
        $intiCache = $this->_startCache();
        // onInject
        $this->_log->log('Page', $this->_config);
        $injectMethod = isset($this->_config['injector']) ? $this->_config['injector'] : false;
        if ($injectMethod && method_exists($this->_page, $injectMethod)) {
            $this->_log->log('Page injector', $injectMethod);
            $this->_page->$injectMethod();
        }
        $args = $this->_page->getArgs();
        // onClick
        $this->_runClick($args);
        // onInit
        if (!$intiCache) {
            $this->_log->log('onInit', $args);
            $this->_page->onInit($args);
        }
        // submit ?
        $hasSubmit = (isset($_POST['_token']) || isset($_GET['_token'])) ? true : false;
        // onOutput()
        if ($hasSubmit === false) {
            $this->_runPreOutput();
            $this->_page->onOutput();
            $this->end();
            return;
        }
        $this->_submit = isset($_POST['_token']) ? $_POST : $_GET;
        // form作成
        $formName = BEAR_Form::getSubmitFormName($this->_submit);
        try {
            $form = BEAR::get('BEAR_Form_' . $formName);
        } catch(Exception $e) {
            $this->_log->log('BEAR_Form Exception', $e->__toString());
            $this->_runPreOutput();
            $this->_page->onOutput();
            $this->end();
            return;
        }
        //モバイル用サブミット
        //        $this->_page->mobileSubmit();
        // submitバリデーション
        $isValidate = $form->validate();
        $this->_isAjaxSubmit = isset($_SERVER['HTTP_X_BEAR_AJAX_REQUEST']);
        if ($isValidate) {
            // submit OK
            $this->_formValidationOk($form, $formName);
        } else {
            // submit NG
            $this->_log->log('Submit NG', array(
                'Submit' => $form->_submitValues, 
                'Rules' => $form->_rules, 
                'Errors' => $form->_errors));
            if ($this->_isAjaxSubmit) {
                // AJAXバリデーションNG]
                $this->_ajaxValidationNG($form);
            } else {
                $this->_runPreOutput();
                $this->_page->onOutput();
            }
        }
        // initキャッシュ保存
        if ($this->_initCache === true) {
            $smarty = BEAR::dependency('BEAR_Smarty');
            $cacheData = array('type' => 'init', 'init' => $page->get());
            $this->_writePageCache($cacheData);
        }
        //end
        $this->end();
    }

    /**
     * deubg実行
     *
     * @return void
     */
    private function _runDebug()
    {
        // デバック用キャッシュクリア
        if (isset($_GET['_cc'])) {
            BEAR_Util::clearAllCache();
            $this->exitMain();
        }
        // タイマー初期化
        $this->_config['start_time'] = microtime(true);
        // log
        $log = array();
        $log['BEAR'] = BEAR::VERSION;
        $log['URI'] = $_SERVER['REQUEST_URI'];
        $log['time'] = _BEAR_DATETIME;
        $this->_log->log('start', $log);
    }

    /**
     * onClickコール
     *
     * @return void
     */
    private function _runClick(array $args)
    {
        // onClick
        $isActiveLink = isset($_GET[BEAR_Page::KEY_CLICK_NAME]);
        $hasMethod = isset($_GET[BEAR_Page::KEY_CLICK_NAME]) && method_exists($this->_page, $onClickMethod = 'onClick' . $_GET[BEAR_Page::KEY_CLICK_NAME]);
        if ($isActiveLink && $hasMethod) {
            $page = BEAR::get('page');
            $page->setOnClick($_GET[BEAR_Page::KEY_CLICK_NAME]);
            $args['click'] = isset($_GET[BEAR_Page::KEY_CLICK_VALUE]) ? $_GET[BEAR_Page::KEY_CLICK_VALUE] : null;
            $this->_log->log('onClick', array(
                'click' => $this->_page->getOnClick(), 
                'args' => $args));
            $this->_page->$onClickMethod($args);
        } elseif ((!isset($_GET[BEAR_Page::KEY_CLICK_NAME]) && method_exists($this->_page, 'onClickNone'))) {
            $this->_page->onClickNone($args);
        }
    }

    /**
     * onInitコール
     *
     * @return void
     */
    private function _runInit(array $args)
    {
        switch (true) {
        case (!(isset($this->_config['page_cache']['type']) && $this->_config['page_cache']['type'] == 'init')) :
            // キャッシュ利用なし
            $this->_page->onInit($args);
            break;
        case (is_array($this->_initCache)) :
            // キャッシュあり -> initキャッシュをアサイ
            $smarty = BEAR::dependency('BEAR_Smarty');
            $smarty->_tpl_vars = $this->_initCache['init'];
            break;
        default :
            $this->_page->onInit($args);
            $this->_initCache = true;
        }
    }

    /**
     * 出力前のバッファの消去
     *
     * debugモード時はdebug出力エリアとして出力します。
     */
    private function _runPreOutput()
    {
        $buff = ob_get_clean();
        ob_start();
        if ($this->_config['debug'] && $buff) {
            echo '<div style="border-style: dotted;">' . $buff . '</div>';
        }
    }

    /**
     * ページ終了処理
     *
     * <pre>
     * ヘッダーとコンテンツを出力して終了します。
     * </pre>
     *
     * @return void
     */
    public function end()
    {
        $body = ob_get_contents();
        // ページキャッシュ書き込み
        if (isset($this->_config['cache']['type']) && $this->_config['cache']['type'] == 'page') {
            $cacheData = array('type' => 'page', 
                'headers' => BEAR_Page::$headers, 
                'body' => $body);
            $this->_writePageCache($cacheData);
        }
        // ヘッダー出力
        $this->_page->flushHeader();
        // ページ出力
        ob_end_flush();
        // 終了
        $this->exitMain();
    }

    /**
     * init/ページキャッシュの読み込み
     *
     * <pre>
     * ページキャッシュが存在すれば表示して終了します。
     * ページキャッシュはヘッダーもキャッシュされます。
     * initキャッシュの場合は_initプロパティに格納します。
     * </pre>
     *
     * @return void
     */
    private function _startCache()
    {
        //キャッシュ初期化
        $type = isset($this->_config['cache']['type']) && $this->_config['cache']['type'];
        if (!$type) {
            return;
        }
        $cache = BEAR::dependency('BEAR_Cache');
        $cache->setLife($this->_config['cache']['life']);
        $key = $this->_getPageCacheKey();
        $cachedPage = $cache->get($key);
        if (!$cachedPage) {
            $this->_log->log('Page Cache[R]', 'No hit');
            return false;
        } elseif ($cachedPage['type'] == 'page') {
            $this->_log->log('Page Cache[R]', $key);
            // page cache
            $this->_page->setHeaders($cachedPage['headers']);
            $this->_page->flushHeader();
            echo $cachedPage['body'];
            $this->exitMain();
        } else {
            // init cache
            $this->_initCache = $cachedPage;
        }
    }

    /**
     * ページキャッシュ書き込み
     *
     * ヘッダーとコンテンツをキャッシュに保存
     *
     * @param string $cacheData キャッシュ
     *
     * @return void
     */
    private function _writePageCache($cacheData)
    {
        $cache = BEAR::dependency('BEAR_Cache');
        $cache->setLife($this->_config['cache']['life']);
        $key = $this->_getPageCacheKey();
        $cache->set($key, $cacheData);
        $this->_log->log('Main Cache[W]', $this->_config['cache']);
    }

    /**
     * ページキャッシュのキーを生成
     *
     * @return string ハッシュ
     */
    private function _getPageCacheKey()
    {
        // $_GET['_start'] は BEAR_Page::PAGER_NUMと同じ
        $key = $this->_config['mobile'] . $_SERVER['SCRIPT_NAME'] . serialize($this->_page->getArgs());
        $key .= (isset($_GET['_start'])) ? $_GET['_start'] : null;
        return md5($key);
    }

    /**
     * ページクラス名取得
     *
     * <pre>
     * マルチページの場合、$_GET['_p']または$_GET['_p']が
     * ページクラス名として使用される。どちらも指定が無いときは
     * start()メソッドで使用されたページクラス名を返す（最初のページ）
     *
     *
     * 詳細:
     *　$_GET['_p']は$_POST['_p']より優先される
     *  $_GET['_p']はBEAR_Mulit_Page::locationで付与されるもの（ページの移動）
     *  $_POST['_p']はhiddenフォームで埋め込まれてるもの（
     * ページのリロードやバリデーションNG）
     * </pre>
     *
     * @param string $pageClass ページクラス名
     *
     * @return void
     * @access private
     */
    private function _getPageClassName($pageClass)
    {
        /**
         * マルチページチェック
         * hiddenフォームに$_POSTか$_GETに_p変数（ページクラス指定変数）が
         * 存在するとその名前を実行ページクラスとして扱う
         */
        $getP = isset($_GET['_p']) ? $_GET['_p'] : false;
        $postP = isset($_POST['_p']) ? $_POST['_p'] : false;
        if ($getP) {
            $pageClassName = $getP;
        } elseif ($postP) {
            $pageClassName = $postP;
        } else {
            $pageClassName = $pageClass;
        }
        if (class_exists($pageClassName)) {
            //ページクラス決定
            $this->_log->log("Page Class", $pageClassName);
        } else {
            $info = array('page class name' => $pageClassName);
            $msg = 'Undefined Page Class（ページクラスがありません）';
            throw $this->_exception($msg, array('info' => $info));
        }
        return $pageClassName;
    }

    /**
     * TokenがAJAXのものか検査
     *
     * @param string $token トークン
     *
     * @return bool
     *
     *
     * @ignore
     */
    private function _isAjaxToken($token)
    {
        $ajaxToken = BEAR_Form::makeToken(true);
        $result = ($token == $ajaxToken) ? true : false;
        return $result;
    }

    /**
     * トークン有効チェック
     *
     * セッショントークンが有効なものかどうか検査します。
     *
     * @param string $token トークン
     *
     * @return bool
     */
    function isTokenValid($token)
    {
        $mdFiveShort = substr($token, 1, 12);
        $tokenCheckSum = substr($token, 13, 2);
        $genuineCheckSum = substr(md5(hexdec($mdFiveShort) * 5 - 1), 0, 2);
        $result = ($tokenCheckSum == $genuineCheckSum) ? true : false;
        $this->_log->log('Token Status', $result ? "Secure" : "Unsecure");
        return $result;
    }

    /**
     * フォームバリデーションOK処理
     *
     * トークンの検査を行い不正アクセスでなければonActionメソッドの引数に
     * POSTされたデータを与えてコールする。
     *
     * @param object $form     フォーム
     * @param object $formName フォーム名
     *
     * @return void
     */
    private function _formValidationOk($form, $formName = null)
    {
        $submit = $form->exportValues();
        BEAR_Form::$exportValue = $form->getSubmitValues();
        /**
         * HTML_QuickForm::exportValues()
         *
         * getSubmitValues()  とは異なり、この関数は フォームに追加された
         * 要素に対応する値で実際に送信されたもののみを返します。
         * 'man'/'woman' を選択するラジオボタンがあった場合、
         * 'other'は有効な送信値とはみなされません。
         * また、このメソッドでは file 要素の値を取得することもできません。
         */
        // アンダースコア始まりのsubmitを消去
        foreach ($submit as $submitKey => $value) {
            if (substr($submitKey, 0, 1) == '_') {
                unset($submit[$submitKey]);
                BEAR_Form::$submitHeader[$submitKey] = $value;
            }
            if ($value === null) {
                $submit[$submitKey] = '';
            }
        }
        //        BEAR_Form::$submitValue = $submit;
        //        $this->_log->log('Submit OK', $submit);
        // アクションコール
        $this->_page->onAction($submit);
        //追加でアクションコール
        $methodExists = method_exists($this->_page, 'onAction' . $formName);
        if ($methodExists) {
            // onAction.フォーム名() コール
            $actionMethodName = 'onAction' . $formName;
            $this->_page->$actionMethodName($submit);
        }
    }

    /**
     * Main終了
     *
     * @return void
     */
    public function exitMain()
    {
        exit();
    }

    /**
     * ヘッダー出力
     *
     * <pre>
     * ページキャッシュにも利用されます。
     * </pre>
     *
     * @return  void
     * @static
     *
     */
    public function _outputHeaders()
    {
        static $hasOut = false;
        $headers = $this->_page->getHeaders();
        if ($headers && !$hasOut) {
            //ヘッダー出力
            foreach ($headers as $header) {
                header($header, true);
            }
            $hasOut = true;
        } else {
            throw $this->_exception('Header is already out');
        }
    }

    /**
     * AJAXフォームでバリデーションNG
     *
     * エラーフォームエレメント名とエラーメッセージの連想配列をJSONで返す
     *
     * @param object $form フォームオブジェクト
     *
     * @return void
     */
    private function _ajaxValidationNG($form)
    {
        foreach ($form->_rules as $key => $value) {
            $ruleKeys[] = $key;
        }
        $ajaxErrorResult = array(
            'quickform' => array('form_id' => $form->_attributes['id'], 
                'rules' => $ruleKeys, 
                'errors' => $form->_errors));
        $this->_log->log('AJAX Form NG', $ajaxErrorResult);
        $formResult = array('validate' => false, 
            'id' => $form->_attributes['id'], 
            'errors' => $form->_errors);
        $ajax = BEAR::dependency('BEAR_Page_Ajax');
        $ajax->addAjax('quickform', $formResult);
        $this->_page->output('ajax');
        $this->end();
    }

    /**
     * AJAXフォームでバリデーションOK
     *
     * フォームエレメント名をJSONで返す
     *
     * @param object $form フォームオブジェクト
     *
     * @return void
     * @ignore
     */
    private function _ajaxValidationOk($form)
    {
        // ルール
        foreach ($form->_rules as $key => $value) {
            $ruleKeys[] = $key;
        }
        BEAR_Page::$formElement = array(
            'quickform' => array('form_id' => $form->_attributes['id'], 
                'rules' => $ruleKeys));
    }

    /**
     * エラーの出力フォーマット(CLI or rich HTML)
     *
     * @return bool
     */
    public static function isCliErrorOutput()
    {
        static $result = null;
        if (is_null($result)) {
            $ajax = BEAR::dependency('BEAR_Page_Ajax');
            $result = $ajax->isAjaxRequest();
        }
        return $result;
    }
}

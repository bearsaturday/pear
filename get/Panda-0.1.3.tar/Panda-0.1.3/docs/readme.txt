Panda Quick Manual

English
http://code.google.com/p/panda-project/wiki/quickmanualen

Japanese
http://code.google.com/p/panda-project/wiki/quickmanual
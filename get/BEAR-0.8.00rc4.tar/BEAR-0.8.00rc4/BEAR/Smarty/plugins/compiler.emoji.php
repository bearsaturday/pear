<?php

function smarty_compiler_emoji($tagArg, &$smarty)
{
    static $emojiConfig = array();
    
    if (!$emojiConfig) {
    	$ua = BEAR::dependency('BEAR_Agent')->getUa();
    	$file =  _BEAR_BEAR_HOME  . "/BEAR/Emoji/Conf/{$ua}.php";
    	if (file_exists($file)) {
    	    include $file;
    	} else {
            include _BEAR_BEAR_HOME  . '/BEAR/Emoji/Conf/Default.php';
    	}
    }
    return 'echo \'' . "{$emojiChars[$tagArg]}" . '\';';
}
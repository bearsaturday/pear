<?php
/**
 * App
 *
 * @category   BEAR
 * @package    App
 * @subpackage Class
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: App.php 1184 2009-11-04 13:58:38Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 */
/**
 * プロジェクトルートパス
 */
define('_BEAR_APP_HOME', realpath(dirname(__FILE__)));
/**
 * BEAR
 */
require_once 'BEAR.php';

/**
 * App実行
 */
App::init($_SERVER['bearmode']);

/**
 * アプリケーションクラス
 *
 * @category   BEAR
 * @package    App
 * @author     $Author: koriyama@users.sourceforge.jp $ <anonymous@example.com>
 * @copyright  anonymous All rights reserved.
 * @license
 * @version    SVN: Release: $Id: App.php 1184 2009-11-04 13:58:38Z koriyama@users.sourceforge.jp $
 * 
 */
class App
{
    /**
     * アプリケーション実行
     *
     * @param int $mode 動作モード
     * 
     * @return void
     */
    public static function init($mode = 1)
    {
        $app = BEAR::loadConfig(_BEAR_APP_HOME . '/App/app.yml');
        switch ($mode) {
        case 2 :
            //開発モード （キャッシュ無効)
            BEAR_Util::clearAllCache(false);
        case 1 :
            //開発モード （キャッシュ有効)
            $app['core']['debug'] = true;
            $app['App_Db']['dsn']['default'] = $app['App_Db']['dsn']['slave'] = $app['App_Db']['dsn']['test'];
            break;
        case 0 :
        default :
            //ライブ
            $app['core']['debug'] = false;
            break;
        }
        BEAR::init($app);
    }

    /**
     * コールバック
     *
     * @param string $event 　イベント
     * @param array  $config
     */
    public static function onCall($event, array $config)
    {
    }
}

<?php
/**
 * @APP@
 *
 * @package Page
 */
require_once 'App.php';

/**
 * Untitledページ
 *
 * <pre>
 * </pre>
 *
 * @package Page
 * @author  $Author: koriyama@users.sourceforge.jp $
 * @version SVN: Release: $Id: index.php 1196 2009-11-08 16:40:34Z koriyama@users.sourceforge.jp $
 */
class Page_Index extends App_Page
{

    /**
     * インジェクター
     *
     * @return void
     */
    public function onInject()
    {
        parent::onInject();
    }

    /**
     * 初期化
     *
     * @return void
     */
    public function onInit(array $args)
    {
        // RSS resource
        $uri = 'http://www.excite.co.jp/News/xml/rss_excite_news_odd_index_utf_8.dcg';
        $options['pager'] = 5;
        $params = array('uri' => $uri, 'values' => array(), 'options' => $options);
        $this->_resource->read($params)->set('news');
        $this->set('time', date('n/j H:i'));
    }

    /**
     * 出力
     *
     * @return void
     */
    public function onOutput()
    {
        $this->display();
    }
}
$options = array('cache' => array('type' => 'init', 'life' => 10));
App_Main::run('Page_Index', $options);

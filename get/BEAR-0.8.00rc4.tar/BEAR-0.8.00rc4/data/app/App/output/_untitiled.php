<?php

/**
 * App
 * 
 * @category   BEAR
 * @package    App_Page
 * @subpackage Output
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: _untitiled.php 1188 2009-11-04 14:00:16Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 */
/**
 * Untitledアウトプットフィルター
 *
 * @param array $values  引数
 * @param array $options オプション
 * 
 * @return BEAR_Ro
 */
function outputUntitled($values, $options = null)
{
    $headers = array('X-BEAR-Output: untitled', 'Content-Type: text/html; charset=utf-8');
    return new BEAR_Ro('<pre>' . print_r($values, true) . '</pre>', $headers);
}
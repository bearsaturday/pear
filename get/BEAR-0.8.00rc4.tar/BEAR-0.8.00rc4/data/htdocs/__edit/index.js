/**
 * Add Tree to container
 * 
 * @param container
 * @param path
 * @return void
 */
function addTree(container, path, is_dir, label) {
	if (is_dir) {
		script = 'jqueryFileTree/jqueryFileTree.php';
	} else {
		script = 'ajax/files.php';
	}
	$(container).fileTree( {
		root : path,
		script : script,
		folderEvent : 'dblclick',
		expandSpeed : 150,
		collapseSpeed : 150,
		multiFolder : true
	}, function(path) {
		load(path);
	});
	$(container).append(label);
}

/**
 * Ajax load
 * 
 * @param path
 * @return void
 */
function load(path) {
	$('#path').html('<em>Loading...</em>');
	var url = 'load.php';
	jQuery.post('ajax/load.php', {
		path : path
	}, function(data, status) {
		set_editor(data);
		$('#file_info').html(data.info);
		$('#path').html(path + "&nbsp;" + data.save);
	}, 'json');
}

/**
 * Load editor
 * 
 * @param data
 * @return void
 */
function set_editor(data) {
	// var _editor;
	_editor = new bespin.editor.Component('editor', {
		autocomplete : true
	});
	_editor.setContent(data.file);
	_editor.setLineNumber(0);
	bespin.publish("settings:language", {
		language : data.ext
	});
}

/**
 * save
 * 
 * @param path
 *            path to save
 * @return void
 */
function save(path) {
	var data = _editor.getContent();
	jQuery('#save').html('saving...').css('color', 'red');
	_editor.setFocus(true);
	jQuery.post('ajax/save.php', {
		path : path,
		data : data
	}, function(data, status) {
		jQuery('#save').html('saved').css('color', 'green').fadeOut('slow')
				.fadeIn('slow', function() {
					jQuery('#save').html('save').css('color', 'blue')
				});
	}, 'html')
}

/**
 * put folder path to val.
 * 
 * @param path
 * @return
 */
function folder_select(path) {
	foldar_path = path
	//console.log(path);
}
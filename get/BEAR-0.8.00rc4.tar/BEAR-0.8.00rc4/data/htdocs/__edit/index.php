<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>BEAR Edit</title>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script src="jquery.easing.js" type="text/javascript"></script>
<script src="jqueryFileTree/jqueryFileTree.js" type="text/javascript"></script>
<link href="index.css" rel="stylesheet" type="text/css" media="screen" />
<link href="jqueryFileTree/jqueryFileTree.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/dojo/1.3.2/dojo/dojo.xd.js"></script>
<script type="text/javascript" src="https://bespin.mozilla.com/embed.js"></script>
<script type="text/javascript" src="index.js"></script>
<script type="text/javascript" src="init.js.php"></script>
</script>
</head>
<body class="twoColHybLt">
<div style="background-color: #c9d9fb; -moz-border-radius-topright: 12px; -moz-border-radius-topleft: 12px; -webkit-border-radius: 12px; -webkit-border-top-left-radius:12px; -webkit-border-top-right-radius:12px;"><img src="jqueryFileTree/images/file.png" align="bottom"><span id="path" class="path"> Unloaded</span></div>
<div id="container">
  <div id="sidebar1">
  <div id="container_id1"></div>
  <div id="container_id2"></div>
  <div id="container_id3"></div>
  <div id="container_id"></div>
	  <!-- end #sidebar1 --></div>
  <div id="mainContent">
    <div id="editor" style="position:relative; left:0px; background-color:#222222; color:gray; height: 700px; border: 0px solid #ddd; visibility: visible; "></div>
    <div id="file_info"></div>
    <!-- end #mainContent --></div>
    <!-- このクリアリングエレメントは、#container div に強制的にすべての子フローティングエレメントが含まれるようにするため、#mainContent div の直後に配置される必要があります --><br class="clearfloat" />
<!-- end #container --></div>
</body>
</html>
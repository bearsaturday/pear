<?php 
/**
 * ファイルアクセスできる最上位パス
 * 
 * @var string
 */
require_once 'App.php';

//define ('_BEAR_EDIT_ROOT_PATH', '/');
define ('_BEAR_EDIT_ROOT_PATH', _BEAR_APP_HOME);
?>
<?php

ob_start();

/**
 * Panda init
 */
$pandaPath = '/usr/share/panda';
// required files
include $pandaPath . '/Panda.php';

// optional
// * debug utility
include $pandaPath . '/Panda/Debug/util.php';
// uncomment for PHP5.2.0 or earlier
//include $pandaPath . '/Panda/inc/sys_get_temp_dir.php';

$config = array(Panda::CONFIG_DEBUG => true,                    // debug mode
Panda::CONFIG_VALID_PATH => array('/'),                          // valid path (user source code path)
Panda::CONFIG_LOG_PATH => '/tmp/',                               // fatal error log path
//Panda::CONFIG_ON_ERROR_FIRED => array('Test_App', 'onError'),  // application error callback on fire
//Panda::CONFIG_FATAL_HTML => '',                                // fatal error template
//Panda::CONFIG_ON_IS_CLI_OUTPUT => false,                       // CLI check logic injection (callback or bool)
Panda::CONFIG_ENABLE_FIREPHP => true,                            // use firephp on firefox ?
//Panda::CONFIG_HTTP_TPL => 'Panda/Template/http.php',           // Http503 output template
Panda::CONFIG_CATCH_FATAL => true,                               // catch fatal error ? (recommend false for debug)
Panda::CONFIG_PANDA_PATH => '/',                                 // __bear Panda htdocs path
Panda::CONFIG_CATCH_STRICT => true);                             // catch stric error in compile ?
// init
Panda::init($config);
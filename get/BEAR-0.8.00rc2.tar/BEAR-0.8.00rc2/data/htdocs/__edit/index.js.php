<?php
ini_set('display_errors', 0);
require_once 'App.php';

$logFile = _BEAR_APP_HOME . '/logs/page.log';
spl_autoload_unregister(array('BEAR', 'onAutoload')); // to avoid auto loader run by unserialize
$pageLog = unserialize(file_get_contents($logFile));
$includeFiles = $pageLog['include'];
$files = array();
foreach ($includeFiles as $includeFile) {
    if (strpos($includeFile, _BEAR_APP_HOME . '/htdocs') !== false) {
        $files['page'][] = $includeFile;
        //        $cmd =  "addTree('#container_id', '{$includeFile}');";
    } elseif (strpos($includeFile, _BEAR_APP_HOME . '/App/Ro') !== false) {
        $files['ro'][] = $includeFile;
    } elseif (strpos($includeFile, _BEAR_APP_HOME . '/App/') !== false) {
        $files['app'][] = $includeFile;
    }
}
$pageFile = $files['page'][0];
$path = dirname(str_replace(_BEAR_APP_HOME . '/htdocs/', '', $pageFile));
$pathDir = ($path === '.') ? '' : $path . '/';
$pageDir = _BEAR_APP_HOME . '/App/views/pages/' . $pathDir;
if ($dir = opendir($pageDir)) {
    while (($ifile = readdir($dir)) !== false) {
        // is_dirでなぜかディレクトリが判別できない
        if(substr($ifile, 0, 1) == '.' || is_dir($ifile) || strpos($ifile, '.') === false){
            continue;
        }
        $files['view'][] = $pageDir . $ifile;
    }
    closedir($dir);
}
$icon = '<span class="ui-icon ui-icon-triangle-1-s"></span>';
if (is_array($files['page'])) {
    $cmd = "addTree('#container_id1', '" . serialize($files['page']) . "', false, '{$icon}<span class=\"tree_label\">ページ</span>');";
}
if (is_array($files['ro'])) {
    $cmd .= "addTree('#container_id2', '" . serialize($files['ro']) . "', false, '<span class=\"tree_label\">リソース</span>');";
}
if (is_array($files['view'])) {
    $cmd .= "addTree('#container_id3', '" . serialize($files['view']) . "', false, '<span class=\"tree_label\">ビュー</span>');";
}
$cmd .= "addTree('#container_id', '" . _BEAR_APP_HOME  ."/', true, '<span class=\"tree_label\"><hr class=\"project\">プロジェクト</span>');";
?>

$(document).ready( function() {
<?php echo $cmd;?>
});

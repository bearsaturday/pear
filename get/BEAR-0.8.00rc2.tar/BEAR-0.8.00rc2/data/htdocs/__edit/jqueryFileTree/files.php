<?php
//
// jQuery File Tree PHP Connector for BEAR
//
//
// Original Author : Cory S.N. LaViska
// A Beautiful Site (http://abeautifulsite.net/)
// 24 March 2008
//
// History:
//
// 1.01 - updated to work with foreign characters in directory/file names (12 April 2008)
// 1.00 - released (24 March 2008)
//
//
$root = '/';
$files = unserialize(urldecode($_POST['dir']));
//$files = array('/Users/akihito/app/bear.kumatter/htdocs/__edit/all/index.php', '/Users/akihito/app/bear.kumatter/htdocs/__edit/all/index.js');
echo "<ul class=\"jqueryFileTree\" style=\"display: none;\">";
// All files
foreach ($files as $file) {
        $ext = preg_replace('/^.*\./', '', $file);
        $shortfileName = str_replace(dirname($file) . DIRECTORY_SEPARATOR, '', $file);
        echo "<li class=\"file ext_$ext\"><a href=\"#\" alt=\"{$file}\" rel=\"" . htmlentities($file) . "\">" . htmlentities($shortfileName) . "</a></li>";
}
echo "</ul>";
?>
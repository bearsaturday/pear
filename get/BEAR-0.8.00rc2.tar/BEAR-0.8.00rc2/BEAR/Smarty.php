<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Smarty
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Smarty.php 1020 2009-10-13 04:03:35Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Smarty/BEAR_Smarty.html
 */
/**
 * Smartyライブラリ読み込み
 */
include _BEAR_BEAR_HOME . '/BEAR/inc/Smarty/libs/Smarty.class.php';
/**
 * Smartyクラス
 *
 * <pre>
 * BEARで使うテンプレートエンジンのSmartyです。コンストラクタで
 * 初期設定をしています。
 *
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Smarty
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Smarty.php 1020 2009-10-13 04:03:35Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Smarty/BEAR_Smarty.html
 */
class BEAR_Smarty extends BEAR_Factory
{

    /**
     * outputフィルターを一度しか実行しないためのコントロール値
     *
     * <pre>
     *   0 未実行
     *   1 実行
     *   2 実行済み
     * </pre>
     *
     * 　@var interger
     *
     */
    public static $doEmojiOutputFilter = 0;

    /**
     * コンストラクタ
     */
    public function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * Smartyオブジェクトを生成
     */
    public function factory()
    {
        //親コンストラクタ
        $smarty = new Smarty();
        //フォルダパス設定
        $smarty->template_dir = _BEAR_APP_HOME . '/App/views/';
        $smarty->config_dir = _BEAR_APP_HOME . '/App/smarty/configs/';
        $smarty->compile_dir = _BEAR_APP_HOME . '/tmp/smarty_templates_c/';
        $smarty->cache_dir = _BEAR_APP_HOME . '/tmp/smarty_cache/';
        $smarty->plugins_dir = array('plugins',
            'App/smarty/plugins/',
            'BEAR/Smarty/plugins/');
        // デバックモード
        if ($this->_config['debug']) {
            // テンプレートキャッシュなし
            $smarty->caching = 0;
            // テンプレートキャッシュは常に再生成
            $smarty->force_compile = true;
            // BEARバッジ表示
            if (BEAR::$ua != BEAR_Agent::UA_DOCOMO && BEAR::$ua != BEAR_Agent::UA_AU && BEAR::$ua != BEAR_Agent::UA_SOFTBANK && !BEAR_Agent::isBearAgent()) {
                $smarty->register_outputfilter(array(
                    'BEAR_Smarty',
                    'onPageRenderDebug'));
            }
        }
        return $smarty;
    }

    /**
     * 絵文字用アオウトプットフィルター
     *
     * <pre>
     * 絵文字を画像表示します。ネイティブ表示できる場合はそちらを優先します。
     * </pre>
     *
     * @param string $html   HTML
     * @param Smarty $smarty smartyオブジェクト
     *
     * @return string
     * @static
     */
    public static function onEmojiOutput($html, $smarty)
    {
        if (self::$doEmojiOutputFilter != 1) {
            return $html;
        }
        self::$doEmojiOutputFilter = 2; //済み
        if (BEAR::$ua == BEAR_Agent::UA_DOCOMO || BEAR::$ua == BEAR_Agent::UA_AU) {
            $html = mb_convert_encoding($html, 'SJIS-win', 'UTF-8');
        }
        $regex = '/&amp;#(\d{5});/s';
        $html = preg_replace($regex, "&#$1;", $html);
        $html = BEAR_Emoji::ImageTag($html);
        return $html;
    }

    /**
     * デバック時のページレンダリングフィルター
     *
     * <pre>
     * エラー状態を表し、__bearページにリンクするデバック時に
     * 画面右上に現れる「BEARバッジ」を表示します。
     *
     * ページの状態によって色が変わります。
     *
     * 赤　Fatal, PEARエラーなど
     * 黄　Warningレベルのエラーはあり
     * 青　noticeは出てる
     * 緑 noticeも出てない
     *
     * </pre>
     *
     * @param string $html   HTML
     * @param Smarty $smarty smartyオブジェクト
     *
     * @return string
     * @static
     */
    public static function onPageRenderDebug($html, $smarty)
    {
        $app = BEAR::get('app');
        if (!$app['core']['debug'] || BEAR_Agent::isBearAgent()) {
            return;
        }
        // エラー統計
        $errorFgColor = "white";
        $errorStat = Panda::getErrorStat();
        if ($errorStat & E_ERROR) {
            $errorBgColor = "red";
            $errorMsg = "Fatal Error";
        } elseif ($errorStat & E_WARNING) {
            $errorBgColor = "yellow";
            $errorFgColor = "black";
            $errorMsg = "Warning";
        } elseif ($errorStat & E_NOTICE) {
            $errorBgColor = "#2D41D7";
            $errorMsg = "Notice";
        } else {
            $errorBgColor = "green";
            $errorMsg = '';
        }
        // デバック情報表示HTML
        // bear.jsを使用する場合はbear_debuggingがtrueになる
        if (file_exists(_BEAR_APP_HOME. '/htdocs/__edit')){
            $editHtml = '<a href="/__edit/" target="bearedit" name="';
            $editHtml .= $errorMsg . '" style="padding:5px 3px 3px 3px;background-color: gray';
            $editHtml .= ';color:' . $errorFgColor . ';font:bold 8pt Verdana; margin-top:100px; ';
            $editHtml .= 'border: 1px solid #dddddd">EDIT</a>';
        } else {
        	$editHtml = '';
        }
        $budgeHtml = '<!-- bear_budge --><div id="bear_budge" style=" font-size: 9px; position: absolute;  top: 0px;';
        $budgeHtml .= ' right: 0px; text-align: right;">';
        $budgeHtml .= $editHtml;
        $budgeHtml .= '<a href="/__bear/" target="bearlog" name="';
        $budgeHtml .= $errorMsg . '" style="padding:5px 3px 3px 3px;background-color:' . $errorBgColor;
        $budgeHtml .= ';color:' . $errorFgColor . ';font:bold 8pt Verdana; margin-top:100px; ';
        $budgeHtml .= 'border: 1px solid #dddddd;　">BEAR</a></div>' . '</div></div><!-- /bear_budge --></body>';
        $html = str_ireplace('</body>', $budgeHtml, $html);
        return $html;
    }
}
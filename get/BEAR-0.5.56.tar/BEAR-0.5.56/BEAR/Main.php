<?php
/**
 * BEAR_Main
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Main
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Main.php 572 2009-04-10 01:26:15Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Main/BEAR_Main.html
 */

/**
 * メインクラス
 *
 * <pre>
 * ページオブジェクトを実行するクラスです。。
 * ページに実装されたイベントハンドラをイベント毎にコールします。
 * キャッシュオプションでページの初期化（onInit）をキャッシュするinitキャッシュ、
 * テンプレート生成までも含めたページキャッシュのキャッシュオプションを
 * 指定することができます。
 *
 * Example 1.キャッシュページの実行
 * </pre>
 * <code>
 * class Blog_RSS extends App_Page{
 * }
 * $config = array('cache'=>'init', 'life'=>60);
 * new BEAR_Main('Blog_RSS', $config);
 * //10分間のページキャッシュ
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Main
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Main.php 572 2009-04-10 01:26:15Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Main/BEAR_Main.html
 */
class BEAR_Main
{

    /**
     * cacheプロパティキー　キャッシュキー
     *
     */
    const CACHE_KEY = 'key';

    /**
     * cacheプロパティキー　キャッシュライフタイム
     *
     */
    const CACHE_LIFE = 'life';

    /**
     * cacheプロパティキー　キャッシュタイプ
     *
     */
    const CACHE_TYPE = 'type';

    /**
     * ページキャッシュ　配列キー header
     *
     */
    const CACHE_PAGE_HEADER = 'header';

    /**
     * ページキャッシュ　配列キー body
     *
     */
    const CACHE_PAGE_BODY = 'body';

    /**
     * initキャッシュキー
     *
     */
    const CACHE_INIT = 'i';

    /**
     * ページキャッシュ
     *
     */
    const CACHE_TYPE_PAGE = 'page';

    /**
     * initキャッシュ
     *
     */
    const CACHE_TYPE_INIT = 'init';

    /**
     * ページインスタンス
     *
     * @var object App_Page
     */
    public static $page = null;

    /**
     * 引数
     *
     * ページの$_GETや$_COOKIE,CLIの引数。
     *
     * @var array
     */
    private $_args = array();

    /**
     * セッション自動スタートスイッチ
     *
     * @var boolean
     * @access private
     */
    private $_sessionAutoStart = true;

    /**
     * コンフィグ
     * 
     * キャッシュオプション   
     * 'config'
     *   'type' int    キャッシュタイプ　0=init, 1=page 
     *   'key'  string キャッシュキー
     *   'life' int    キャッシュ時間
     *
     * @var mixed
     * @access private
     */
    private $_config = false;

    /**
     * initキャッシュの値
     *
     * init()でセットされたSmartyアサイン変数をキャッシュします。
     *
     * @var mixed mixed  (bool)true キャッシュ保存  | array キャッシュ内容
     */
    private $_initCache = false;

    /**
     * タイマー開始時間
     *
     * デバックモードの時の時間計測表示用
     *
     * @var float
     * @access private
     */
    private static $_startTime;

    /**
     * サブミット値
     *
     * $_POSTか$_GETの内容が入ります
     * BEAR_Page::queryMethodプロパティの設定に依存します
     *
     * @var mixed
     * @access private
     */
    private $_submit = false;

    /**
     * コンストラクタ
     *
     * 指定されたページクラスをインスタンス化し実行します。<var>$lifeTime</var><pre>で
     * ページ全体のキャッシュ時間が指定できます。
     * （デフォルトは0=キャッシュしない）キャッシュのIDはURLとBEAR::$uaで決まります。
     *
     * ページ内から別のページを生成するために</pre><var>$newPage</var>
     * ページオプションがあります。デフォルトのfalseの場合はページファイルを実行
     * しないクラスファイルとして使用できるようになります。
     *
     * @param string $pageClass ページクラス名
     * @param mixed  $config    コンフィグ
     *
     * @return void
     */
    function __construct($pageClass, $config = array())
    {
        // デバック用キャッシュクリア
        if (App::$debug && isset($_GET['_cc'])) {
            BEAR_Util::clearAllCache();
        }
        if (is_string($config)){
            $config = BEAR::loadValues($config);
        }
        if (!self::$page || (isset($config['new'])) && $config['new'] == true) {
            // ページクラス存在チェック
            if (!$pageClass || !class_exists($pageClass, false)) {
                $info = array('page_class' => $pageClass);
                $msg  = 'Page class is not defined.（ページクラスが定義されていません)';
                PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', $info, $msg);
            }
            // フォーム初期化
            if (class_exists('BEAR_Form', false)) {
                BEAR_Form::init();
            }
            // ページ生成、実行
            BEAR_Main::$page = new $pageClass;
            BEAR::set('page', BEAR_Main::$page);
            $this->_config = $config;
            try{
                $this->_run();
            } catch (Exception $e){
                $code =  $e->getCode();
                if ($code == BEAR::CODE_OK) {
                    $this->_endPage();
                } else {
                    throw new BEAR_Exception($e);
                }
            }
        } else {
            BEAR_Log::appLog("Page Include", $pageClass);
        }
    }

    /**
     * ページクラス実行
     * 
     * @param string $pageClass ページクラス名
     * @param array  $config    設定
     * 
     * @return void
     */
    public static function run($pageClass, $config = array())
    {
        new self($pageClass, $config);
    }
    
    /**
     * セッションオートスタートセット
     *
     * セッションを自動スタートさせたくないときはfalseでコールします。
     *
     * @param bool $autoStart オートスタート
     *
     * @return void
     * @access public
     */
    function setSessionAutoStart($autoStart = true)
    {
        $this->_sessionAutoStart = $autoStart;
    }

    /**
     * ページ開始
     *
     * ページを実行します。
     *
     * @return void
     */
    private function _run()
    {
        if (App::$debug) {
            // タイマー初期化
            self::$_startTime = microtime(true);
            // log
            $log         = array();
            $log['BEAR'] = BEAR::VERSION;
            $log['URI']  = $_SERVER['REQUEST_URI'];
            $log['time'] = _BEAR_DATETIME;
            BEAR_Log::appLog('start', $log);
        }
        // エラー初期化
        if (BEAR::$errorHandling === true) {
            BEAR_Error::init();
        }
        // ページキャッシュ読み込み（キャッシュフラグ、またはクエリーで無効）
        if (isset($this->_config['cache']['type']) && $this->_config['cache']['type'] == 'init') {
            $this->_readCache();
        }
        // セッションスタート
        if (App::$config['session']['engine'] !== 0) {
            BEAR_Session::start();
        }
        // args
        $this->_args = self::$page->onArgs();
        // onClick
        $isActiveLink = isset($_GET[BEAR_Page::ACTIVE_LINK_KEY]);
        $hasMethod    = isset($_GET[BEAR_Page::ACTIVE_LINK_KEY]) && method_exists(self::$page, $onMethod = 'onClick' . $_GET[BEAR_Page::ACTIVE_LINK_KEY]);
        if ($isActiveLink && $hasMethod) {
            BEAR_Page::$onClick = $_GET[BEAR_Page::ACTIVE_LINK_KEY];
            self::$page->$onMethod($this->_args);
        } elseif ((!isset($_GET[BEAR_Page::ACTIVE_LINK_KEY]) && method_exists(self::$page, 'onClickNone'))) {
            self::$page->onClickNone();
        }
        switch (true) {
        case (!(isset($this->_config['cache']['type']) && $this->_config['cache']['type'] == 'init')) :
            // キャッシュ利用なし
            $initResult = self::$page->onInit($this->_args);
            break;
        case (is_array($this->_initCache)) :
            // キャッシュあり -> initキャッシュをアサイ
            $initResult        = $this->_initCache;
            $smarty            = BEAR::dependency('BEAR_Smarty');
            $smarty->_tpl_vars = $initResult[self::CACHE_TYPE_INIT];
            break;
        default :
            $initResult       = self::$page->onInit($this->_args);
            $this->_initCache = true;
        }
        if (isset($initResult) && $initResult === false) {
            BEAR_Log::appLog('Terminated', 'onInit returns false');
            $this->_endPage();
            return;
        }
        // submit ?
        if (isset($_POST['_token']) || isset($_GET['_token'])) {
            $this->_submit = isset($_POST['_token']) ? $_POST : $_GET;
            $hasSubmit     = true;
        } else {
            $hasSubmit = false;
        }
        // onOutput()
        if ($hasSubmit === false) {
            self::$page->onOutput();
            $this->_endPage();
            return;
        }
        // form作成
        $formName = BEAR_Form::getSubmitFormName($this->_submit);
        $form     = BEAR::get('BEAR_Form_' . $formName);
        //モバイル用サブミット
//        self::$page->mobileSubmit();
        // submitバリデーション
        $isValidate = $form->validate();
        self::$page->isAjaxSubmit = isset($_SERVER['HTTP_X_BEAR_AJAX_REQUEST']);
        if ($isValidate) {
            // submit OK
            $this->_formValidationOk($form, $formName);
        } else {
            // submit NG
            BEAR_Log::appLog('Submit NG', array('Submit' => $form->_submitValues, 'Rules' => $form->_rules, 'Errors' => $form->_errors));
            if (self::$page->isAjaxSubmit) {
                // AJAXバリデーションNG]
                $this->_ajaxValidationNG($form);
            } else {
                self::$page->onOutput();
            }
        }
        // initキャッシュ保存
        if ($this->_initCache === true) {
            $smarty    = BEAR::dependency('BEAR_Smarty');
            $cacheData = array(self::CACHE_TYPE => self::CACHE_TYPE_INIT, self::CACHE_TYPE_INIT => $smarty->_tpl_vars);
            $this->_writePageCache($cacheData);
        }
        //end
        $this->_endPage();
    }

    /**
     * ページ終了処理
     *
     * <pre>
     * ヘッダーとコンテンツを出力して終了します。
     * start内からのみコールされます。
     * </pre>
     *
     * @return void
     */
    private function _endPage()
    {
        BEAR_Page::$body = ob_get_contents();
        // ページキャッシュ書き込み
        if (isset($this->_config['cache'][self::CACHE_TYPE]) && $this->_config['cache'][self::CACHE_TYPE] == self::CACHE_TYPE_PAGE) {
            $cacheData = array('type' => self::CACHE_TYPE_PAGE, self::CACHE_PAGE_HEADER => BEAR_Page::$headers, self::CACHE_PAGE_BODY => BEAR_Page::$body);
            $this->_writePageCache($cacheData);
        }
        // ヘッダー出力
        $this->outputHeader();
        // ページ出力
        ob_end_flush();
        // 終了
        BEAR_Main::end(false);
    }

    /**
     * init/ページキャッシュの読み込み
     *
     * <pre>
     * ページキャッシュが存在すれば表示して終了します。
     * ページキャッシュはヘッダーもキャッシュされます。
     * initキャッシュの場合は_initプロパティに格納します。
     * </pre>
     *
     * @return void
     */
    private function _readCache()
    {
        //キャッシュ初期化
        $cache = BEAR::dependency('BEAR_Cache');
        $life  = $this->_config['cache'][self::CACHE_LIFE];
        $cache->setLife($life);
        $key        = $this->_getPageCacheKey();
        $cachedPage = $cache->get($key);
        if (!$cachedPage) {
            BEAR_Log::appLog('Page Cache[R]', 'No hit');
            return false;
        } elseif ($cachedPage[self::CACHE_TYPE] == self::CACHE_TYPE_PAGE) {
            BEAR_Log::appLog('Page Cache[R]', $key);
            // page cache
            BEAR_Page::header($cachedPage[self::CACHE_PAGE_HEADER]);
            echo $cachedPage[self::CACHE_PAGE_BODY];
            BEAR_Main::end();
        } else {
            // init cache
            $this->_initCache = $cachedPage;
        }
    }

    /**
     * ページキャッシュ書き込み
     *
     * ヘッダーとコンテンツをキャッシュに保存
     *
     * @param string $cacheData キャッシュ
     *
     * @return void
     */
    private function _writePageCache($cacheData)
    {
        $cache = BEAR::dependency('BEAR_Cache');
        $cache->setLife($this->_config['cache'][self::CACHE_LIFE]);
        $key = $this->_getPageCacheKey();
        $cache->set($key, $cacheData);
        BEAR_Log::appLog('Init/Page Cache[W]', $this->_config['cache']);
    }

    /**
     * ページキャッシュのキーを生成
     *
     * @return string ハッシュ
     */
    private function _getPageCacheKey()
    {
        // $_GET['_start'] は BEAR_Page::PAGER_NUMと同じ
        $key = BEAR::$ua . $_SERVER['SCRIPT_NAME'] . serialize($this->_args);
        $key .= (isset($_GET['_start'])) ? $_GET['_start'] : null;
        return md5($key);
    }

    /**
     * ページクラス名取得
     *
     * <pre>
     * マルチページの場合、$_GET['_p']または$_GET['_p']が
     * ページクラス名として使用される。どちらも指定が無いときは
     * start()メソッドで使用されたページクラス名を返す（最初のページ）
     *
     *
     * 詳細:
     *　$_GET['_p']は$_POST['_p']より優先される
     *  $_GET['_p']はBEAR_Mulit_Page::locationで付与されるもの（ページの移動）
     *  $_POST['_p']はhiddenフォームで埋め込まれてるもの（
     * ページのリロードやバリデーションNG）
     * </pre>
     *
     * @param string $pageClass ページクラス名
     *
     * @return void
     * @access private
     */
    private function _getPageClassName($pageClass)
    {
        /**
         * マルチページチェック
         * hiddenフォームに$_POSTか$_GETに_p変数（ページクラス指定変数）が
         * 存在するとその名前を実行ページクラスとして扱う
         */
        $getP  = isset($_GET['_p']) ? $_GET['_p'] : false;
        $postP = isset($_POST['_p']) ? $_POST['_p'] : false;
        if ($getP) {
            $pageClassName = $getP;
        } elseif ($postP) {
            $pageClassName = $postP;
        } else {
            $pageClassName = $pageClass;
        }
        if (class_exists($pageClassName)) {
            //ページクラス決定
            BEAR_Log::appLog("Page Class", $pageClassName);
        } else {
            $info = array('page class name' => $pageClassName);
            $msg  = 'Undefined Page Class（ページクラスがありません）';
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, 0, 'error', $info, $msg);
        }
        return $pageClassName;
    }

    /**
     * TokenがAJAXのものか検査
     *
     * @param string $token トークン
     *
     * @return bool
     * @ignore
     */
    private function _isAjaxToken($token)
    {
        $ajaxToken = BEAR_Form::makeToken(true);
        $result    = ($token == $ajaxToken) ? true : false;
        return $result;
    }

    /**
     * トークン有効チェック
     *
     * セッショントークンが有効なものかどうか検査します。
     *
     * @param string $token トークン
     *
     * @return bool
     */
    function isTokenValid($token)
    {
        $mdFiveShort     = substr($token, 1, 12);
        $tokenCheckSum   = substr($token, 13, 2);
        $genuineCheckSum = substr(md5(hexdec($mdFiveShort) * 5 - 1), 0, 2);
        $result          = ($tokenCheckSum == $genuineCheckSum) ? true : false;
        BEAR_Log::appLog('Token Status', $result ? "Secure" : "Unsecure");
        return $result;
    }

    /**
     * フォームバリデーションOK処理
     *
     * トークンの検査を行い不正アクセスでなければonActionメソッドの引数に
     * POSTされたデータを与えてコールする。
     *
     * @param object $form     フォーム
     * @param object $formName フォーム名
     *
     * @return void
     */
    private function _formValidationOk($form, $formName = null)
    {
        $submit                 = $form->exportValues();
        BEAR_Form::$exportValue = $form->getSubmitValues();
        /**
         * HTML_QuickForm::exportValues()
         *
         * getSubmitValues()  とは異なり、この関数は フォームに追加された 
         * 要素に対応する値で実際に送信されたもののみを返します。 
         * 'man'/'woman' を選択するラジオボタンがあった場合、
         * 'other'は有効な送信値とはみなされません。
         * また、このメソッドでは file 要素の値を取得することもできません。
         */
        // アンダースコア始まりのsubmitを消去
        foreach ($submit as $submitKey => $value) {
            if (substr($submitKey, 0, 1) == '_') {
                unset($submit[$submitKey]);
                BEAR_Form::$submitHeader[$submitKey] = $value;
            }
            if ($value === null) {
                $submit[$submitKey] = '';
            }
        }
//        BEAR_Form::$submitValue = $submit;
//        BEAR_Log::appLog('Submit OK', $submit);
        // アクションコール
        self::$page->onAction($submit);
        //追加でアクションコール
        $methodExists = method_exists(self::$page, "onAction{$formName}");
        if ($methodExists) {
            // onAction.フォーム名() コール
            $actionMethodName = 'onAction' . $formName;
            self::$page->$actionMethodName($submit);
        }
    }

    /**
     * Mainクラスでのデバック用表示
     *
     * ページ実行終了時にdevツールへのリンクBEARバッジを表示します。
     *
     * @return void
     * @static
     * @ignore
     */
    private static function _showDebugBearBadge()
    {
        // 時間表示
        $endLog                = array();
        $functionExisits       = function_exists('memory_get_peak_usage');
        $endLog['peak memory'] = $functionExisits ? number_format(memory_get_peak_usage(true)) : 'n/a';
        if (App::$debug) {
            $endLog['time'] = (self::$_startTime != 0) ? microtime(true) - self::$_startTime : 'n/a';
            //コンパイルオプション依存
        }
        BEAR_Log::appLog('End', $endLog);
        if (!App::$debug) {
            return;
        }
    }

    /**
     * ページ終了
     *
     * ページ表示してスクリプトを終了させます。exit();のソフト終了です。
     * <code>
     * // 終了
     * BEAR_Main::end();
     * </code>
     *
     * @param bool $exit 終了フラグ
     *
     * @return void
     * @static
     */
    public static function end($exit = true)
    {
        // デバック情報
        if (App::$debug) {
            self::_showDebugBearBadge();
        }
        //　ヘッダー出力
        //　BEAR_Mainではない直接コールの場合のみ
        if (BEAR_Page::$enableHeader) {
            BEAR_Main::outputHeader();
        }
        if ($exit) {
            exit();
        }
    }

    /**
     * ヘッダー出力
     *
     * <pre>
     * BEAR_Page::header()でバッファされていたヘッダーが出力されます
     * ページキャッシュにも利用されます。
     * </pre>
     *
     * @return  void
     * @static
     *
     */
    public static function outputHeader()
    {
        static $hasOut = false;
        if (BEAR_Page::$headers && !$hasOut) {
            //出力フラグON
            $hasOut = true;
            //ヘッダー出力
            BEAR_Log::appLog('Header', BEAR_Page::$headers);
            foreach (BEAR_Page::$headers as $header) {
                //同じヘッダーは上書きされる
                header($header, true);
            }
        }
    }

    /**
     * AJAXフォームでバリデーションNG
     *
     * エラーフォームエレメント名とエラーメッセージの連想配列をJSONで返す
     *
     * @param object $form フォームオブジェクト
     *
     * @return void
     */
    private function _ajaxValidationNG($form)
    {
        /**
         * ルール
         */
        foreach ($form->_rules as $key => $value) {
            $ruleKeys[] = $key;
        }
        $ajaxErrorResult = array('quickform' => array('form_id' => $form->_attributes['id'], 'rules' => $ruleKeys, 'errors' => $form->_errors));
        BEAR_Log::appLog('AJAX Form NG', $ajaxErrorResult);
        $formResult = array('validate'=>false, 'id'=>$form->_attributes['id'] , 'errors'=>$form->_errors);
        self::$page->addAjax('quickform', $formResult);
        self::$page->output('ajax');
        $this->_endPage();
    }

    /**
     * AJAXフォームでバリデーションOK
     *
     * フォームエレメント名をJSONで返す
     *
     * @param object $form フォームオブジェクト
     *
     * @return void
     * @ignore
     */
    private function _ajaxValidationOk($form)
    {
        // ルール
        foreach ($form->_rules as $key => $value) {
            $ruleKeys[] = $key;
        }
        BEAR_Page::$formElement = array('quickform' => array('form_id' => $form->_attributes['id'], 'rules' => $ruleKeys));
    }
}

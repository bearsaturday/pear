<?php

/**
 * BEAR_Page
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Page
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Page.php 572 2009-04-10 01:26:15Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Page/BEAR_Page.html
 */

/**
 * BEAR_Pageクラス
 *
 * <pre>
 * ページの抽象クラスです。onで始まるメソッドがイベントドリブンでコールされます。
 * が基本3メソッドです。
 *
 * onInit($args)        初期化
 * onOutput()           ページ出力処理
 * onAction($submit)    フォーム送信後の処理
 *
 * Example 1. テンプレートにアサインしてページ表示
 *
 * </pre>
 * <code>
 * // ページ実行
 * class Admin_Index extends App_Page
 * {
 *     public function onInit()
 *     {
 *         $res = BEAR_Resource('/usr/profile');
 *         $profile = $res->reard(array('id=>1'));
 *         // $viewにアサインする変数
 *         $this->set('profile', $profile);
 *     }
 *
 *     public function onOutput()
 *     {
 *         $this->display();
 *     }
 * }
 * new BEAR_Main('Admin_Index');
 * </code>
 *
 * Example 2. フォーム投稿
 *
 * <code>
 * // ページ実行
 * class Page_Register extends App_Page
 * {
 *     public function onAction($submit)
 *     {
 *         print "{$submit['name']}さんを登録しました";
 *         $this->display('admin/registered.tpl');
 *     }
 * }
 * BEAR_Main('Admin_Index');
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Page
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Page.php 572 2009-04-10 01:26:15Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Page/BEAR_Page.html
 * @abstract
 */
abstract class BEAR_Page
{

    /**
     * アクティブリンククエリーキー
     *
     */
    const ACTIVE_LINK_KEY = '_c';

    /**
     * {a}タグバリュー
     */
    const VALUES_KEY = 'val';

    /**
     * スカラーキー
     *
     */
    const SCALAR_KEY = '_sc';

    /**
     * 携帯サ絵文字ポート対応なし
     *
     * @var integer
     */
    const SUPPORT_NONE = 0;

    /*
     * 携帯絵文字サポートIMG変換
     *
     * @var integer
     */
    const SUPPORT_IMG = 1;

    /*
     * 携帯絵文字サポートIMG変換
     *
     * @var integer
     */
    const SUPPORT_CONV = 2;

    /**
     * HTTP出力ヘッダー
     *
     * @var array
     */
    public static $headers = array();

    /**
     * 出力ボディ
     *
     * @var string
     */
    public static $body = '';

    /**
     * Click名
     *
     * @var string
     */
    public static $onClick = null;

    /**
     * onInit()でSmartyアサインされた値
     *
     * @var array
     */
    public static $initValue = array();

    /**
     * Smartyオブジェクト
     *
     * 継承したPageクラスでfalseにするとSmartyを使用しません
     *
     * @var mixed
     */
    public $smarty = null;

    /**
     * ヘッダー出力スイッチ
     *
     * BEARによりヘッダー出力をしない場合にはfalseにします。
     */
    public static $enableHeader = true;

    /**
     * Ajaxサブミット
     */
    public $isAjaxSubmit = false;
    
    /**
     * onInit()等の引数
     *
     * @var array
     */
    protected static $_args = array();

    /**
     * サブミット文字列を変換するか
     *
     * @var bool
     */
    private static $_submitConvert = false;

    /**
     * 文字コード変換の場合のモバイルの文字コード
     */
    private static $_codeFromMoble;

    /**
     * SB WebCode絵文字を変換するか
     */
    private static $_convertThreeGcWebEncode = false;

    /**
     * ページキャッシュ
     *
     * @var string
     */
    private $_cache = array('use_cache' => false, 'headers' => null, 'html' => null);

    /**
     * AJAX QuickFormで使用
     *
     * @var array
     */
    private static $_formElement;

    /**
     * モバイル出力ヘッダー
     *
     * @var string
     */
    private static $_mobileHeader = 'application/xhtml+xml';

    /**
     * AJAXコマンドデータ
     * 
     * @var array
     */
    private static $_ajax = array();

    /**
     * charset
     * 
     * マルチエージェントの場合のcharset
     */
    private static $_charset = null;

    /**
     * ページコンストラクタ
     *
     * <pre>
     * Smarty,HTMLHTML_QuickFormオブジェクトをプロパティとして生成し、
     * 携帯端末からPOSTされた文字のコード、絵文字を処理します。
     * </pre>
     *
     */
    function __construct()
    {
        // smarty生成
        if ($this->smarty !== false) {
            //smartyオブジェクト生成
            $this->smarty = BEAR::dependency('BEAR_Smarty');
        
        }
        // PC/Mobile対応
        if (App::$config['agent'] !== 0) {
            $this->_initAgent(App::$config['agent']);
        }
    }

    /**
     * 認証ハンドラ
     *
     * <pre>
     * onInit()の前に呼ばれます。
     * 認証NGのときはredirectするかfalseを返してページを終了させます。
     * </pre>
     *
     * @return void
     */
    public function onAuth()
    {}

    /**
     * Ajaxリクエストハンドラ
     *
     * @ignore
     * @return bool
     */
    public function onAjax()
    {}

    /**
     * ページ初期化ハンドラ
     *
     * ページの初期化を行います。onOutput()で出力させる変数を全て用意しsetします。<br/>
     * setした変数はキャッシュ可能です。
     *
     * @param mixed $args ページ引数
     *
     * @return void
     */
    public function onInit($args)
    {}

    /**
     * ページ表示ハンドラ
     *
     * <pre>
     * onInit()で実行された後、フォーム送信されてない、
     * またはバリデーションNGのときにコールされます。
     * </pre>
     *
     * @return void
     */
    public function onOutput()
    {}

    /**
     * バリデーションOKハンドラ
     *
     * <pre>フォーム送信されバリデーションOKの場合にonInit()の後にコールされます</pre>
     *
     * @param mixed $submit フォーム内容
     *
     * @return void
     *
     */
    public function onAction($submit)
    {
        trigger_error('onAction method is not implemented in your page class.' . print_r($submit, true), E_USER_WARNING);
    }

    /**
     * モバイル用のヘッダーをセットする
     *
     * <code>
     * class App_Page extends BEAR_Page
     * {
     *   function __construct()
     *   {
     *     // html対応にする
     *     $this->setMobileHeader();
     *     parent::__construct();
     *   }
     * </code>
     *
     * @param string $header text/html
     *
     * @return void
     */
    protected function setMobileHeader($header = 'text/html')
    {
        self::$_mobileHeader = $header;
    }

    /**
     * ページ出力
     *
     * <pre>
     * 指定したテンプレートをsmartyオブジェクトとフォームオブジェクトを
     * テンプレートにアサインして画面出力します。画面出力の代わりにHTMLを
     * 文字列として取得する場合はfetch()メソッドを使用します。
     * 引数を省略するとページクラスからパスが生成されたテンプレートが使用されます
     *
     * $options
     *
     * 'override'  設定ファイル上書き配列 key=>value
     *
     * </pre>
     *
     * @param string $tplName テンプレートファイル名
     * @param mixed  $options オプション
     *
     * @return   mixed
     */
    public function display($tplName = null, $options = null)
    {
        // charset
        if (self::$_charset) {
            $this->set('charset', self::$_charset);
        }
        $path = $this->_getTemplateNameByPageClass($tplName); // ex) user.ceate.preview
        // mobile
        if (BEAR::$ua) {
            $path = $this->_getTemplateNameByMobile($path, BEAR::$ua);
        }
        $matches = array();
        preg_match('/(.+?)[\.]/', $path, $matches);
        if (is_array($matches)) {
            $firstWordForConfig = (isset($matches[0]) && $matches[0]) ? $matches[0] : $path . '.';
        } else {
            $firstWordForConfig = '';
        }
        $templatePath = 'pages/' . $path . '.tpl';
        $configFileHead = _BEAR_APP_HOME . '/App/views/pages/' . $firstWordForConfig;
        
        // 設定ファイル
        if (file_exists($configFileHead . 'yml')) {
            $configFile = $configFileHead . 'yml';
        } elseif (file_exists($configFileHead . 'ini')) {
            $configFile = $configFileHead . 'ini';
        } else {
            $configFile = false;
        }
        // yml,ini
        if ($configFile === false) {
            BEAR_Smarty::$doEmojiOutputFilter = 1;
            //html
            $html = $this->fetch($templatePath);
        } else {
            $config = BEAR::loadValues($configFile);
            $lv = isset($config['default']) ? $config['default'] : array();
            //携帯config
            if (isset($config['mobile']) && (BEAR::$ua != BEAR_Agent::UA_PC)) {
                $isArray = is_array($lv);
                if ($isArray) {
                    $mobile = $config['mobile'];
                    $lv = array_merge($lv, $mobile);
                } else {
                    $lv = $config['mobile'];
                }
            }
            if (is_array($options) && is_array($lv) && is_array($config[$options['override']])) {
                $lv = array_merge($lv, $config[$options['override']]);
            }
            $this->smarty->assign('layout', $lv);
            $this->smarty->assign('static', $lv);
            if (isset($config['layout'])) {
                $contetForLayout = $this->fetch($templatePath);
                $this->smarty->assign('content_for_layout', $contetForLayout);
                $layoutFile = 'layouts/' . $config['layout'];
                //モバイル用のレイアウトファイル
                $ua = BEAR::$ua;
                if ($ua != BEAR_Agent::UA_PC) {
                    $mobileLayoutNoExtention = $this->_removeExtention($layoutFile);
                    $path = _BEAR_APP_HOME . "/App/views/{$mobileLayoutNoExtention}.mobile.tpl";
                    $isExists = file_exists($path);
                    if ($isExists) {
                        $layoutFile = $mobileLayoutNoExtention . '.mobile.tpl';
                    }
                }
                BEAR_Smarty::$doEmojiOutputFilter = 1;
                $html = $this->fetch($layoutFile);
            } else {
                $html = $this->fetch($templatePath);
            }
        }
        ;
        $this->_output($html);
        // 使用テンプレートのログ
        $result = $this->onTemplateLog($tplName);
        if ($result !== false) {
            $display = array();
            $display['config'] = isset($configFile) ? $configFile : 'n/a';
            $display['page'] = $tplName;
            BEAR_Log::appLog('display', $display);
        }
    }

    /**
     * テンプレート名の取得
     *
     * @param string $tplName テンプレート名（省略可）
     *
     * @return array
     *
     */
    private function _getTemplate($tplName = null)
    {
        $path = $this->_getTemplateNameByPageClass($tplName);
        // mobile
        $path = (BEAR::$ua) ? $this->_getTemplateNameByMobile($path, BEAR::$ua) : $path;
        return $path;
    }

    /**
     * ページクラスからパスを取得する
     *
     * <pre>
     * /はじまりだと絶対パス、テンプレート名省略または相対パスなら
     * ページクラスからパス名を組み立てます。相対パスでテンプレートを
     * 指定していれば指定したものにおきかわる。
     *
     * 例
     * 絶対パス
     *  '/index.tpl'　=> '/index'
     *  '/some/index.tpl' => '/some/index'
     * 相対パス　Sample_Test_Pageクラスの場合
     *  '' =>　'sample/test/page'
     *  'help.tpl' => 'sample/test/help'
     *  'another/help.tpl' => 'sample/test/another/help'
     * </pre>
     *
     * @param string $tplName テンプレート名
     *
     * @return string
     */
    private function _getTemplateNameByPageClass($tplName)
    {
        // 絶対パス
        if (substr($tplName, 0, 1) == '/') {
            // 先頭の/を除いて返す
            $absPath = $this->_removeExtention($tplName);
            return substr($absPath, 0);
        }
        // 相対パスの場合はクラス名からベースパスを作成する
        $pageClass = preg_replace('/^Page_/', '', get_class($this));
        $base = str_replace('_', '/', strtolower($pageClass));
        if ($tplName == null) {
            return $base;
        }
        $bodyTpl = $this->_removeExtention($tplName);
        //テンプレート名の指定があればページクラス名の相対パスで置換
        $regx = '/\/([\w]+)$/i';
        $result = ($tplName) ? preg_replace($regx, '/' . $bodyTpl, $base) : $base;
        return $result;
    }

    /**
     * ファイルの拡張子を除いたものを返します
     *
     * @param string $file ファイル名
     *
     * @return string
     *
     */
    private function _removeExtention($file)
    {
        $pathinfo = pathinfo($file);
        switch ($pathinfo['dirname']) {
            case '/' :
                $result = $pathinfo['filename'];
                break;
            case '.' :
                $result = $pathinfo['filename'];
                break;
            default :
                $result = $pathinfo['dirname'] . '/' . $pathinfo['filename'];
                break;
        }
        return $result;
    }

    /**
     * モバイルテンプレート名
     *
     * index.tplに対してindex.mobile.tplという風に.mobile.というファイルが用意されていれば
     * モバイル用のテンプレート名を返します
     *
     * @param string $file ファイル名
     * @param string $ua   ユーザーエージェント
     *
     * @return string
     */
    private function _getTemplateNameByMobile($file, $ua)
    {
        //クリックメソッドの時はクリックテンプレート優先
        if ($ua == BEAR_Agent::UA_PC) {
            return $file;
        }
        if (file_exists(_BEAR_APP_HOME . '/App/views/pages/' . $file . '.mobile.tpl')) {
            $file = $file . '.mobile';
        }
        return $file;
    }

    /**
     * テンプレートに値をセット
     *
     * <pre>
     * ここでsetされた値がSmartyテンプレートでアサインされる以外に
     * initキャッシュとして再利用することができます。
     * また他クラスからBEAR_Page::getInit($class, $args)として
     * Init値のみ取得することができます。
     * </pre>
     *
     * @param mixed $tplVar キー array|string
     * @param mixed $value  値
     *
     * @return void
     */
    public function set($tplVar, $value)
    {
        $this->smarty->assign($tplVar, $value);
        BEAR_Page::$initValue[$tplVar] = $value;
    }

    /**
     * ページ文字列取得
     *
     * アサイン済みテンプレートのHTMLを文字列として取得します。
     *
     * @param string $tplName テンプレート名
     *
     * @return string
     */
    public function fetch($tplName)
    {
        // プレフィックス付きテンプレートファイル優先
        // 無ければプレフィックス無しを使用
        $file = $this->smarty->template_dir . $tplName;
        if (!file_exists($file)) {
            //テンプレートファイルがない
            $info = array('tpl name'=>$tplName, 'template_file' => $file);
            $msg = 'Template file is missing.（テンプレートファイルがありません)';
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', $info, $msg);
        }
        // フォーム
        if (BEAR_Form::$formNames) {
            BEAR_Form::renderForms();
        }
        $html = $this->smarty->fetch($file);
        return $html;
    }

    /**
     * http出力
     *
     * <pre>
     * HTTPヘッダーとコンテンツを出力します。
     * HTMLコンテンツ(text/html)やXMLコンテンツ(application/xml)などを出力します。
     *
     * Example 1. XML出力
     * </pre>
     * <code>
     * //XML出力
     * $option = array('header' => "Content-Type: application/xml");
     * $this->_output($contens, $option);
     * </code>
     *
     * Example 2. 複数ヘッダー出力
     *
     * <code>
     * $option[] = array('header' => "Content-Type: application/xml");
     * $option[] = array('x-hoge-time' => "{$time}");
     * $this->_output($contens, $option);
     * </code>
     *
     * @param string $html    HTMLコンテンツ
     * @param mixed  $headers HTTPヘッダー
     *
     * @return mixed
     */
    private function _output($html, $headers = false)
    {
        // ヘッダーを出力
        if ($headers) {
            BEAR_Page::header($headers);
        }
        // ボディ出力
        echo $html;
    }

    /**
     * ヘッダー出力
     *
     * <pre>
     * ヘッダーを出力用にバッファリングします。
     * 引数は配列または文字列で指定できます。
     * スタティック変数として保存されBEAR_Mainで出力バッファを
     * フラッシュする時に送出されます。
     * 同じ<
     * /pre>
     *
     * @param mixed $header HTTPヘッダー
     *
     * @return void
     * @static
     */
    public static function header($header)
    {
        self::$headers[] = $header;
    }

    /**
     * ヘッダーのフラッシュ
     *
     * <pre>
     * ページにヘッダーを取得します。
     * 通常はページ出力時に自動で出力されます。
     * </pre>
     *
     * @return void
     * @static
     */
    public static function flushHeader()
    {
        BEAR_Log::appLog('Headers', self::$headers);
        foreach(self::$headers as $header) {
            BEAR_Log::appLog('header', $header);
            if (is_string($header)) {
                header($header);
            }
        }
    }

    /**
     * PC/モバイル両用の設定を行う
     *
     * <pre>
     * 以下の使用のWebアプリに設定を行います。
     *
     * 1)PCおよびSB/3GCはUTF-8出力その他携帯はSJIS
     * 2)スクリプトはUTF-8
     * 3)フォームから送られる$submitはUTF-8
     * 4)エージェントに応じたヘッダーを出力します
     * </pre>
     *
     * @param int $mobileSupport モバイルサポート
     *
     * @return void
     */
    private function _initAgent($mobileSupport)
    {
        // POSTエンコード変換コンバートスイッチ
        $bearAgent = BEAR::dependency('BEAR_Agent');
        BEAR::$ua = $bearAgent->getCarrierShortName();
        if (BEAR::$ua == BEAR_Agent::UA_DOCOMO || BEAR::$ua == BEAR_Agent::UA_AU || BEAR::$ua == BEAR_Agent::UA_SOFTBANK ) {
            BEAR_Agent::$isMobile = true;
        } else {
            BEAR_Agent::$isMobile = false;
        }
        // 変換ON
        self::$_submitConvert = true;
        // ヘッダー
        $isThreeGC = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) && $bearAgent->isType3GC();
        if (BEAR_Agent::$isBot) {
            // Bot
            BEAR_Page::header('Content-Type: text/html; charset=Shift_JIS;');
            
            self::$_codeFromMoble = 'SJIS-win';
            self::$_charset = 'Shift_JIS';
        } elseif (BEAR::$ua == BEAR_Agent::UA_PC) {
            // PC
            BEAR_Page::header('Content-Type: text/html; charset=utf-8;');
            self::$_charset = 'utf-8';
        } elseif ($isThreeGC) {
            //3gc mobile
            BEAR_Page::header('Content-Type: text/html; charset=utf-8;');
            self::$_codeFromMoble = 'SJIS-win';
            self::$_convertThreeGcWebEncode = true;
            self::$_charset = 'Shift_JIS';
        } else {
            // Mobile General (Docomo/AU)
            $header = 'Content-Type: ' . self::$_mobileHeader . '; charset=Shift_JIS;';
            BEAR_Page::header($header);
            self::$_codeFromMoble = 'SJIS-win';
            self::$_charset = 'Shift_JIS';
        }
        switch ($mobileSupport) {
            // 絵文字を表示できない時はイメージタグで表示
            case self::SUPPORT_IMG :
                // 絵文字出力アウトプットフィルター出力関数
                $this->smarty->register_outputfilter(array('BEAR_Smarty', 'onEmojiOutput'));
                break;
            case self::SUPPORT_CONV :
            case 2 :
            default :
                break;
        }
        // 絵文字エンティティconfig
        $emojiConfig = _BEAR_BEAR_HOME . '/BEAR/Smarty/config/emoji/' . BEAR::$ua . '/emoji.conf';
        $this->smarty->config_load($emojiConfig);
    }

    public static function isMobile()
    {
        return self::$_isMobile;
    }


    /**
     * UTF-8化コールバック関数
     *
     * @param string &$value 文字列
     *
     * @return void
     * @ignore
     */
    public static function onUTF8(&$value)
    {
        if (!mb_check_encoding($value, self::$_codeFromMoble)) {
            throw new BEAR_Exception('Illigal Submit Values', BEAR::CODE_BAD_REQUEST, array('values'=>$value));
        }
        $value = mb_convert_encoding($value, 'UTF-8', self::$_codeFromMoble);
        if (!mb_check_encoding($value, 'UTF-8')) {
            throw new BEAR_Exception('Illigal UTF-8', BEAR::CODE_BAD_REQUEST, array('values'=>$value));
        }
        
    }

    /**
     * リダイレクト
     *
     * <pre>Locationヘッダーを用いてページの移動を行います。
     * クッキーが対応してないエージェントの場合はクエリーに
     * セッションIDを付加します。
     *
     * .(dot)を指定すると同一ページのリフレッシュになります。
     * ページが完全に移動した場合は$config['permanent']をtrueにすると
     * 301ヘッダーを付加してリダイレクトしボットなどに移転を知らせます。
     *
     * -----------------------------------------
     *
     * Example 1. リダイレクト
     * </pre>
     * <code>
     *  BEAR_Page::redirect('http://www.example.co.jp/');
     * </code>
     * <pre>
     * Example 2. リダイレクト（301 パーマネント)
     * </pre<
     * <code>
     * BEAR_Page::redirect('/', array('permanent'=>true));
     * </code>
     * <pre>
     * Example 3. 値を渡してリロード 
     * </pre
     * <code>
     * // onInit($args)の$argsに渡されます
     * BEAR_Page::redirect('.', array('args'=$values);
     * </code>
     *
     * <b>$options</b>
     *
     * 'val'       string セッション利用して値を次ページのonInit($args)に変数を渡す値
     * 'click'     string コールするonClickハンドラ
     * 'permanent' bool   301ヘッダー(パーマネントムーブ)を出力するか
     *
     * @param string $url     URL
     * @param array  $options オプション
     *
     * @return      void
     */
    public static function redirect($url, array $options = array('val'=>null, 'click'=>null, 'permanent'=>false))
    {
        // .なら現在のファイル
        if ($url == '.' || $url == './') {
            $url = $_SERVER['PHP_SELF'];
        }
        // 相対パスならフルパスに変換
        $remoteAddr = $_SERVER["HTTP_HOST"];
        if (strpos($url, "http") === false) {
            if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') {
                $url = "https://{$remoteAddr}$url";
            } else {
                $url = "http://{$remoteAddr}$url";
            }
        }
        // 携帯の場合などクッキーが使用できない環境ではセッションクエリーをURLに付加
        $sessionName = session_name();
        $sessionId = session_id();
        if (!isset($_COOKIE[$sessionName]) && $sessionId && isset($options['session']) && $options['session']) {
            // セッションクエリーが付いてれば消去
            //        $url = preg_replace("/&*{$sessionName}=[^&]+/is", '', $url);
            $url = preg_replace("/([&\\?]){$sessionName}=[^&]?/is", '$1', $url);
            $con = (strpos($url, "?")) ? '&' : '?';
            $url .= "{$con}{$sessionName}={$sessionId}";
            if (strlen($sessionId) != 32) {
                trigger_error('session key error' . $url, E_USER_WARNING);
            }
        }
        //argsオプション
        $query = (isset($options['val'])) ? $options['val'] : "";
        if (isset($options['click'])) {
            $click = array(BEAR_Page::ACTIVE_LINK_KEY => $options['click']);
            if (is_array($query)) {
                $query = array_merge($query, $click);
            } else {
                $query = $click;
            }
        }
        if ($query) {
            $url = $url . '?' . http_build_query($query);
        }
        if (isset($options['permanent']) && $options['permanent']) {
            self::header("HTTP/1.1 301 Moved Permanently");
        }
        //　ロケーションヘッダー出力
        self::header("Location: {$url}");
        BEAR_Log::appLog('redirect', BEAR_Page::$headers);
        self::flushHeader();
    }

    /**
     * Bad Requestアサーション
     *
     * <pre>
     * ページに値が正しく渡されているか確認します。
     * falseの時はリソースの結果は400エラーの
     * バリューオブジェクト(BEAR_Voオブジェクト)になります。
     * </pre>
     *
     * @param bool $bool 条件
     *
     * @return void
     */
    public static function assert($bool)
    {
        if (!$bool) {
            throw new BEAR_Error_Exception(BEAR::CODE_BAD_REQUEST);
        }
    }

    /**
     * 必須項目アサーション
     *
     * <pre>
     * 連想配列に指定のキー配列が全て含まれてるか検査し、問題があれば例外を投げます。
     * リソースの結果は400エラー(Bad Request)のバリューオブジェクト(BEAR_Voオブジェクト)になります。
     * ページに値が正しく渡されているか確認するために使用します。
     *
     * 問題があるとBad Request画面を出力して終了します。
     * </pre>
     *
     * <code>
     * //クエリーにuser_idとblog_idが必要
     * self::(array('user_id', 'blog_id'));
     * </code>
     *
     * @param array $keys  必要なキーの配列
     * @param array $array サーチする配列、省略するとページ引数($args)
     * 
     * @return void
     * @throw BEAR_Error_Exception
     */
    public function assertRequired(array $keys, $array = false)
    {
        if ($array === false) {
            $array = self::$_args;
        }
        if (count(array_intersect($keys, array_keys($array))) != count($keys)) {
            BEAR_Log::appLog('Bad Page Request', array('required' => $keys, 'data' => $array));
            throw new BEAR_Error_Exception(BEAR::CODE_BAD_REQUEST);
        }
    }

    /**
     * ページエラー
     *
     * ページ500エラーを出力します。
     *
     * @param string $msg        エラーメッセージ
     * @param int    $httpStatus HTTPステータスコード
     *
     * @return void
     */
    public static function error($msg = '', $httpStatus = BEAR::CODE_ERROR)
    {
        throw new BEAR_Error_Exception($httpStatus, $msg);
    }

    /**
     * HTTPステータスコード出力
     *
     * HTTPステータスコードを出力します。
     *
     * @param int    $httpStatus HTTPステータスコード
     * @param bool   $withBody   ボディの出力をするか
     * @param string $body       メッセージボディ
     *
     * @return void
     */
    public static function outputHttpStatus($httpStatus, $withBody = true, $body = '')
    {
        assert(is_numeric($httpStatus));
        assert(is_bool($withBody));
        
        $codeMsgTable = array('200' => 'OK', '201' => 'Created', '202' => 'Accepted', '203' => 'Non-Authoritative Information', '204' => 'No Content', '205' => 'Reset Content', '206' => 'Partial Content', '300' => 'Multiple Choices', '301' => 'Moved Permanently', '302' => 'Found', '304' => 'Not Modified', '305' => 'Use Proxy', '307' => 'Temporary Redirect', '400' => 'Bad Request', '401' => 'Unauthorized', '403' => 'Forbidden', '404' => 'Not Found', '405' => 'Method Not Allowed', '406' => 'Not Acceptable', '407' => 'Proxy Authentication Required', '408' => 'Request Timeout', '409' => 'Conflict', '410' => 'Gone', '411' => 'Length Required', '412' => 'Precondition Failed', '413' => 'Request Entity Too Large', '414' => 'Request-URI Too Long', '415' => 'Unsupported Media Type', '416' => 'Requested Range Not Satisfiable', '417' => 'Expectation Failed', 

        '500' => 'Internal Server Error', '501' => 'Not Implemented', '502' => 'Bad Gateway', '503' => 'Service Unavailable', '504' => 'Gateway Timeout', '505' => 'HTTP Version Not Supported');
        if (isset($codeMsgTable[$httpStatus])) {
            $codeMsg = $codeMsgTable[$httpStatus];
        } else {
            $codeMsg = '';
        }
        $serverProtocol = (isset($_SERVER['SERVER_PROTOCOL'])) ? $_SERVER['SERVER_PROTOCOL'] : false;
        if (substr(php_sapi_name(), 0, 3) == 'cgi') {
            header("Status: {$httpStatus} {$codeMsg}", true);
        } elseif ($serverProtocol == 'HTTP/1.1' or $serverProtocol == 'HTTP/1.0') {
            header($serverProtocol . " {$httpStatus} {$codeMsg}", true, $httpStatus);
        } else {
            header("HTTP/1.1 {$httpStatus} {$codeMsg}", true, $httpStatus);
        }
        // ボディ
        if (!$withBody) {
            return;
        }
        if ($serverProtocol && !BEAR_Agent::isBearAgent()) {
            $smarty = new BEAR_Smarty();
            $smarty->assign('code', $httpStatus);
            $smarty->assign('codeMsg', $codeMsg);
            $smarty->assign('body', $body);
            $smarty->assign('serverProtocol', $serverProtocol);
            $mobile = '';
            $tpl = _BEAR_BEAR_HOME . '/BEAR/Error/error' . $mobile . '.tpl';
            $smarty->display($tpl);
        } else {
            echo "{$code} {$codeMsg}" . PHP_EOL . PHP_EOL;
        }
        //ログ
        BEAR_Log::appLog("HTTP {$code}", array('trace' => debug_backtrace()));
    }

    /**
     * BEAR_Page::onInit()に渡す引数を作成
     *
     * <pre>
     * $_GETをページ引数として利用し、ここの返り値がonInitの引数$argsになります。
     * _アンダースコアで始まる$_GETはFW使用でonInit()には渡りません。
     * </pre>
     * 
     * @param array $array 配列
     *
     * @return array
     *
     */
    public function onArgs(array $array = array())
    {
        // AJAXならクライアント値を取得
        $array += $this->_getBearJsArgs();
        // スカラー
        if (isset($_GET[BEAR_Page::SCALAR_KEY])) {
            return is_array($array) ? array_merge($_GET[BEAR_Page::SCALAR_KEY], $array) : $_GET[BEAR_Page::SCALAR_KEY];
        }
        //　配列orオブジェクト
        $args = is_array($array) ? array_merge($_GET, $array) : $_GET;
        foreach($args as $key => $value) {
            if (substr($key, 0, 1) == '_') {
                unset($args[$key]);
            }
            if ($value === null) {
                $args[$key] = '';
            }
        }
        return $args;
    }
    
    /**
     * bear.jsからのAJAXリクエストのクライアント値を受け取る
     * 
     * <pre>
     * クライアントのフォームとBear.Valueの値をonInit($args)の$argsにします。
     * 
     * フォーマット:
     * array('form'=>array('フォーム名1'=>'フォーム1データ', 'フォーム名2'=>'フォーム1データ',
     *   'value'=>'Bear.Value');
     * </pre>
     * 
     * <code>
     * <a href="/" rel="ajax[loading1]">ajax request</a>
     * </code> 
     */
    private function _getBearJsArgs()
    {
        if ($this->isAjaxRequest() && isset($_SERVER['HTTP_X_BEAR_AJAX_ARGS'])){
            $client = $result = $form = $arr = array();
            parse_str($_SERVER['HTTP_X_BEAR_AJAX_ARGS'], $client);
            $form = $client['_form'];
            parse_str($form, $form);
            $formArr = array();
            foreach ($form as $key => &$value){
                parse_str($value, $arr);
                $formArr[$key] = $arr;
            }
            $result['form'] = $formArr;
            parse_str($form, $arr);
            $result['value'] = $arr;
            BEAR_Log::appLog('AJAX $args', $result);
        } else {
            $result = array();
        }
        return $result;
    }
    
    /**
     * AJAXリクエストかどうかを返す
     *
     * prototype.js jQuery他で動作します
     *
     * @return boolean
     */
    public static function isAjaxRequest()
    {
        return (self::getHeader('X_REQUESTED_WITH') == 'XMLHttpRequest');
    }

    /**
     * リクエストヘッダーの取得
     *
     * @param string $header HTTPヘッダー名
     * 
     * @return string|false HTTPヘッダー値、みつからなければfalse
     */
    public static function getHeader($header)
    {
        $temp = 'HTTP_' . strtoupper(str_replace('-', '_', $header));
        if (!empty($_SERVER[$temp])) {
            return $_SERVER[$temp];
        }
        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (!empty($headers[$header])) {
                return $headers[$header];
            }
        }
        return false;
    }
    
    /**
     * AJAXコマンドを追加
     * 
     * <code>
     *  // リソースをアサイン
     *  $this->addAjax('resource', array('div_person1' => 'person'), array('effect' => 'slideup'));
     *  // 生のデータをアサイン 
     *  $this->addAjax('html', array('msg' => '使用できます!'), array('effect' => 'splash'));
     *  // フォームの値を変更 
     *  $this->addAjax('form', array('post'=> '123', 'post2'=>'4567'));
     *  // JSをコール 
     *  $this->addAjax('js', array('callback1' => $_SERVER, 'callback2' => $_COOKIE));
     * // 出力
     *  $this->output('ajax');
     * </code>
     *
     * @param string $ajaxCommand 'html' | 'resource' |'form' | 'js'
     * @param array $data
     * @param array $options
     * 
     * @return void
     */
    public function addAjax($ajaxCommand, array $data, array $options=array())
    {
        switch ($ajaxCommand) {
            case 'resource' :
                $ajaxHtmlData = array();
                foreach($data as $div => $initValueKey) {
                    $ajaxDivBody[$div] = self::$initValue[$initValueKey];
                }
                $htmlData = array('body' => $ajaxDivBody, 'options' => $options);
                self::$_ajax['html'][] = $htmlData;
                break;
            case 'html' :
                $ajaxHtmlData = array();
                $htmlData = array('body' => $data, 'options' => $options);
                self::$_ajax['html'][] = $htmlData;
                break;
            default :
                self::$_ajax[$ajaxCommand][] = $data;
                break;
        }
    
    }

    /**
     * AJAXコマンドを取得
     * 
     * @return array
     * @ignore 
     */
    public function getAjaxValues()
    {
        return self::$_ajax;
    }

    /**
     * HTTP出力
     *
     * 指定されたフォーマットでHTTP出力します。
     * 指定フォーマットのアウトプットファイルを以下の順（BEAR, App)で探します。
     *
     * 1) /BEAR/Resource/output/
     * 2) /App/output/
     *
     * @param string $format  フォーマット
     * @param mixed  $options オプション
     *
     * @return void
     */
    public function output($format = 'php', array $options = array())
    {
        if (file_exists(_BEAR_BEAR_HOME . '/BEAR/Resource/output/' . $format . '.php')) {
            $formatFile = _BEAR_BEAR_HOME . '/BEAR/Resource/output/' . $format . '.php';
        } elseif (file_exists(_BEAR_APP_HOME . '/App/Resource/output/' . $format . '.php')) {
            $formatFile = _BEAR_APP_HOME . '/App/output/' . $format . '.php';
        } else {
            $vo = new BEAR_Vo();
            $vo->setCode(BEAR::CODE_BAD_REQUEST);
            $vo->httpOutput();
        }
        include_once $formatFile;
        if (!function_exists('output' . $format)) {
            $info = array('format' => $format);
            $msg = 'Output format is unavailable.（アウトプットフォーマットが利用できません)';
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', $info, $msg);
        }
        $body = BEAR_Page::$initValue;
        $vo = call_user_func('output' . $format, $body, $options);
        /* @var $vo BEAR_Vo */
        $vo->outputHttp();
        exit();
    }
}

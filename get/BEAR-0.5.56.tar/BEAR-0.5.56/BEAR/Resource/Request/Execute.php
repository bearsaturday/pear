<?php

/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Execute.php 524 2009-03-07 06:55:47Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * リソース実行クラス
 *
 * <pre>
 * リソースリクエストを実行するクラスです。どの方法で実行するかををfacotryで判断しています。
 * DIコンテナでBEAR_Resource_Requestクラスに注入されます。
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Execute.php 524 2009-03-07 06:55:47Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */
class BEAR_Resource_Request_Execute extends BEAR_Base
{

    /**
     * HTTPリソース
     */
    CONST FORMAT_HTTP = 'Http';

    /**
     * VO（クラス）リソース
     */
    CONST FORMAT_VO = 'Vo';

    /**
     * スタティックファイルリソース
     */
    CONST FORMAT_FILE = 'StaticFile';

    /**
     * ソケットリソース
     */
    CONST FORMAT_SOCKET = 'Socket';

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * ファクトリー
     * 
     * <pre>
     * URIによってリソースリクエスト実行クラスを確定して
     * インジェクションオブジェクトを生成します
     * </pre>
     * 
     * @param array $config コンフィグ
     * 
     * @return void
     */
    public function factory(array $config)
    {
        // モック
        if (isset($config['options']['mock']) && $config['options']['mock']) {
            return BEAR::dependency('BEAR_Resource_Execute_Mock', $this->_config);
        }
        // パス情報も見て実行ファイルを決定
        $this->_config['url'] = $url = parse_url($this->_config['uri']);
        $this->_config['path'] = $path = pathinfo($this->_config['uri']);
        // スタティックバリューファイル　file:///var/data/data.ymlなど
        if (isset($url['scheme']) && ($url['scheme'] === 'file')) {
            $this->_config['file'] = $url['path'];
            $format = self::FORMAT_FILE;
            $obj = BEAR::dependency('BEAR_Resource_Execute_' . $format, $this->_config);
            return $obj;
        }
        if (isset($path['filename']) && !(isset($url['host']))) {
            return $this->_localResourceExcute();
        } else {
            //ファイルでない
            switch (true) {
            case (isset($url['scheme']) && ($url['scheme'] = 'http' || $url['scheme'] = 'https')) :
                $format = self::FORMAT_HTTP;
                break;
            case (isset($url['scheme']) && $url['scheme'] = 'socket') :
                $format = self::FORMAT_SOCKET;
                break;
            default :
                PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('uri' => $this->_config['uri']), 'URI is not valid.');
            }
        }
        $obj = BEAR::dependency('BEAR_Resource_Execute_' . $format, $this->_config);
        return $obj;
    }

    /**
     * ローカルリソースの実行
     * 
     * <pre>
     * ローカルのリソースファイル(Vo, Function, スタティックファイル等）の
     * リソースファイルを実行します。
     * </pre>
     * 
     * @param array $config 設定
     * 
     * @return object
     */
    private function _localResourceExcute()
    {
        $file = _BEAR_APP_HOME . '/App/resources/' . $this->_config['uri'] . '.php';
        $isFileExists = file_exists($file);
        if ($isFileExists) {
            include_once $file;
            $resourcePathName = str_replace(DIRECTORY_SEPARATOR, '_', $this->_config['uri']);
            switch (true) {
            case (class_exists($resourcePathName, false)) :
                $this->_config['class'] = $resourcePathName;
                $format = 'Vo';
                break;
            case (function_exists($resourcePathName)) :
                //@deprecated
                $this->_config['function'] = $resourcePathName;
                $format = 'Function';
                break;
            default :
                $msg = 'Mismatch resource class/function error.（ファイル名とクラス/関数名がミスマッチです。)';
                $info = array('resource name' => $resourcePathName, 'resource file' => $file);
                PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', $info, $msg);
                $format = 'Mock';
            }
        } else {
            $file = _BEAR_APP_HOME . '/App/resources/' . $this->_config['uri'];
            if (file_exists($file)) {
                $this->_config['file'] = $file;
                $format = self::FORMAT_FILE;
            } else {
                BEAR_Log::appLog('Resource Error', 'file is not exist.[' . $this->_config['uri'] . ']');
                $format = 'Null';
            }
        }
        BEAR_Log::appLog('Resource Format', $format);
        $obj = BEAR::dependency('BEAR_Resource_Execute_' . $format, $this->_config);
        return $obj;
    }
}
<?php

/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Exception
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Exception.php 512 2009-03-04 19:29:35Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR/BEAR.html
 */

/**
 * 汎用例外クラス
 * 
 * <pre>
 * 標準の例外から3番名のパラメーターにヘッダーが付加されています。
 * catchして$e->getHeaders()でヘッダー情報を取得できます。
 * コード、ヘッダー、ボディ（メッセージ）とミニweb(Voコンテナ)のように使います。
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Exception
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Exception.php 512 2009-03-04 19:29:35Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR/BEAR.html
 */
class BEAR_Exception extends Exception
{

    /**
     * ヘッダー
     */
    private $_headers;

    /**
     * コンストラクタ
     *
     * @param string $message メッセージ
     * @param int    $code    コード
     * @param array  $headers ヘッダー
     */
    public function __construct($message, $code = BEAR::CODE_OK, array $headers = array())
    {
        parent::__construct($message, $code);
        $this->_headers = $headers;
    }

    /**
     * ヘッダー取得
     */
    public function getHeaders()
    {
        return $this->_headers;
    }

}

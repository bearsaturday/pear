<?php
/**
 * BEAR_Smarty
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Smarty
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Smarty.php 575 2009-04-10 10:46:42Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Smarty/BEAR_Smarty.html
 */

/**
 * Smartyライブラリ読み込み
 */
require_once 'BEAR/inc/Smarty/libs/Smarty.class.php';

/**
 * Smartyクラス
 *
 * <pre>
 * BEARで使うテンプレートエンジンのSmartyです。コンストラクタで
 * 初期設定をしています。
 * 
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Smarty
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Smarty.php 575 2009-04-10 10:46:42Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Smarty/BEAR_Smarty.html
 */
class BEAR_Smarty extends Smarty
{

    /**
     * outputフィルターを一度しか実行しないためのコントロール値
     *
     * <pre>
     *   0 未実行
     *   1 実行
     *   2 実行済み
     * </pre>
     *
     * 　@var interger
     *
     */
    public static $doEmojiOutputFilter = 0;

    /**
     * コンストラクタ
     */
    function __construct()
    {
        //親コンストラクタ
        parent::Smarty();
        //フォルダパス設定
        $this->template_dir = _BEAR_APP_HOME . '/App/views/';
        $this->config_dir   = _BEAR_APP_HOME . '/App/smarty/configs/';
        $this->compile_dir  = _BEAR_APP_HOME . '/tmp/smarty_templates_c/';
        $this->cache_dir    = _BEAR_APP_HOME . '/tmp/smarty_cache/';
        $this->plugins_dir  = array('plugins', 'App/smarty/plugins/',
                'BEAR/BEAR/Smarty/plugins/');
        // デバックモード
        if (App::$debug) {
            // テンプレートキャッシュなし
            $this->caching = 0;
            // テンプレートキャッシュは常に再生成
            $this->force_compile = true;
            // BEARバッジ表示
            if (BEAR::$ua != BEAR_Agent::UA_DOCOMO &&
            BEAR::$ua != BEAR_Agent::UA_AU &&
            BEAR::$ua != BEAR_Agent::UA_SOFTBANK &&
            !BEAR_Agent::isBearAgent()) {
                $this->register_outputfilter(array(
                                'BEAR_Smarty', 
                                'onPageRenderDebug'));
            }
        }
    }
    /**
     * 絵文字用アオウトプットフィルター
     *
     * <pre>
     * 絵文字を画像表示します。ネイティブ表示できる場合はそちらを優先します。
     * </pre>
     *
     * @param string $html   HTML
     * @param Smarty $smarty smartyオブジェクト
     *
     * @return string
     * @static
     */
    public static function onEmojiOutput($html, $smarty)
    {
        if (self::$doEmojiOutputFilter != 1) {
            return $html;
        }
        self::$doEmojiOutputFilter = 2; //済み
//        assert(class_exists('BEAR_Emoji'));
//        $agent     = BEAR::dependency('BEAR_Agent');
//        $isThreeGC = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) && $agent->isType3GC();
//        if (BEAR::$ua != BEAR_Agent::UA_PC && !$isThreeGC) {
//            $html = mb_convert_encoding($html, 'SJIS-win', 'UTF-8');
//        }
        // SBの場合のvalidation=""の中に入った文字のアンエスケープ
//        if (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) {
//            $html = BEAR_Emoji::unescapeSBEmoji($html);
//        }
        // QFによりエスケープされてしまった絵文字エンティティをアンエスケープ
        // (フィルターによりバイナリにパックされる）
        $regex = '/&amp;#(\d{5});/s';
        $html  = preg_replace($regex, "&#$1;", $html);
        // PC
//        if (BEAR::$ua == BEAR_Agent::UA_PC) {
            $html = BEAR_Emoji::ImageTag($html);
//        }
        return $html;
    }

    /**
     * デバック時のページレンダリングフィルター
     *
     * <pre>
     * エラー状態を表し、beardevページにリンクするデバック時に
     * 画面右上に現れる「BEARバッジ」を表示します。
     *
     * ページの状態によって色が変わります。
     *
     * 赤　Fatal, PEARエラーなど
     * 黄　Warningレベルのエラーはあり
     * 青　noticeは出てる
     * 緑 noticeも出てない
     *
     * </pre>
     *
     * @param string $html   HTML
     * @param Smarty $smarty smartyオブジェクト
     *
     * @return string
     * @static
     */
    public static function onPageRenderDebug($html, $smarty)
    {
        if (!App::$debug || BEAR_Agent::isBearAgent()) {
            return;
        }
        // エラー統計
        $errorFgColor = "white";
        if (BEAR_Error::$errorStat & E_ERROR) {
            $errorBgColor = "red";
            $errorMsg     = "Fatal Error";
        } elseif (BEAR_Error::$errorStat & E_WARNING) {
            $errorBgColor = "yellow";
            $errorFgColor = "black";
            $errorMsg     = "Warning";
        } elseif (BEAR_Error::$errorStat & E_NOTICE) {
            $errorBgColor = "#2D41D7";
            $errorMsg     = "Notice";
        } else {
            $errorBgColor = "green";
            $errorMsg     = '';
        }
        // デバック情報表示HTML
        // bear.jsを使用する場合はbear_debuggingがtrueになる
        $budgeHtml  = '<div id="bear_budge" style=" font-size: 9px; position: absolute;  top: 0px;';
        $budgeHtml .= ' right: 0px; text-align: right;"><a href="/beardev/" accesskey="b" target="bearlog" name="';
        $budgeHtml .= $errorMsg . '" style="padding:5px 3px 3px 3px;background-color:' . $errorBgColor;
        $budgeHtml .= ';color:' . $errorFgColor . ';font:bold 8pt Verdana; margin-top:100px; ';
        $budgeHtml .= 'border: 1px solid #dddddd">BEAR</a></div>' . '</div></div></body>';
        $html       = str_ireplace('</body>', $budgeHtml, $html);
        return $html;
    }

}
<?php
/**
 * App
 *
 * @package App
 * @subpackage page
 */
require_once 'App.php';
$_SERVER['beardev'] = 1;

require_once 'BEAR/inc/debuglib.php';

/**
 * Shellサービス
 *
 * <pre>
 * </pre>
 *
 * @package     App
 * @subpackage  page
 * @author      $Author: koriyama@users.sourceforge.jp $
 * @version     $$
 */
class Page_Shell extends App_Page
{

    /**
     * Init
     * 
     * @return void
     */
    public function onInit($args)
    {
        App::$debug = true;
        $q = trim($args['form']['form']['q']);
        $argv = explode(' ', $q);
        switch (true) {
        case ($q == 'help') :
            $help = <<<END
Commands:
  clear        clear screen
  config       show application configulation.
  info         show server info.
  bear         bear command, type bear -h for more info.
END;
            $this->addAjax('js', array('shell' => "<pre>$help</pre>"));
            break;
        case ($q == 'clear') :
            $this->addAjax('js', array('clear' => ''));
            break;
        case ($q == 'config') :
            $info = '<strong>App::$config<strong><br />' . print_a(App::$config, 'return:1');
            $this->addAjax('js', array('shell' => $info));
            break;
        case ($q == 'info') :
            $info = '<strong>$_SERVER<strong><br />';
            $info .= print_a($_SERVER, 'return:1');
            $info .= '<strong>$_ENV<strong><br />';
            $info .= print_a($_ENV, 'return:1');
            $info .= '<strong>$_COOKIE<strong><br />';
            $info .= print_a($_COOKIE, 'return:1');
            $this->addAjax('js', array('shell' => $info));
            break;
        case (isset($argv[0]) && $argv[0] === 'bear') : //bearコマンド
            $this->_shell($argv);
            break;
        default :
            $this->addAjax('js', array('shell' => "BEAR: {$argv[0]}: command not found<br/>"));
            break;
        }
    }

    public function onOutput()
    {
        App::$debug = false;
        $this->output('ajax');
    }

    private function _shell(array $argv)
    {
        if (!isset($argv[1])) {
            $argv[1] = '--help';
        }
        $_SERVER['argv'] = $argv;
        $config = array('argv' => $argv, 'cli' => false);
        $shell = BEAR::dependency('BEAR_Dev_Shell', $config);
        $shell->execute();
        $display = $shell->getDisplay();
        $display = $display ? $display : 'none';
        $buff = ob_get_clean();
        $result = '<pre>' . $display . $buff . '</pre>';
        $this->addAjax('js', array('shell' => $result));
    }
}

BEAR_Main::run('Page_Shell');
<?php
/**
 * App
 *
 * @category   BEAR
 * @package    App
 * @subpackage Class
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: App.php 697 2009-07-06 11:27:32Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 */
/**
 * プロジェクトルートパス
 */
define('_BEAR_APP_HOME', realpath(dirname(__FILE__)));
/**
 * BEAR
 */
include 'BEAR.php';
/**
 * アプリケーションクラス
 *
 * @category   BEAR
 * @package    App
 * @subpackage Class
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @license    unkonwn http://www.example.com/
 * @version    SVN: Release: $Id: App.php 697 2009-07-06 11:27:32Z koriyama@users.sourceforge.jp $
 * @link       http://www.example.com/
 *
 */
class App
{

    /**
     * デバック
     *
     * @var bool
     */
    public static $debug = true;

    /**
     *　設定
     *
     * @var array
     */
    public static $config = array();

    /**
     * イニシャライザ
     *
     * <pre>
     * .htaccessのphp valueによってアプリ動作プロパティ($_SERVER['bearmode'])を決定します。
     * </pre>
     *
     * @return void
     */
    public static function init()
    {
        $app = BEAR::loadConfig(_BEAR_APP_HOME . '/App/app.yml');
        $mode = $_SERVER['bearmode'];
        switch ($mode) {
        case 1 :
            //開発モード 1
            $app['core']['debug'] = true;
            $app['App_Db']['dsn']['default'] = $app['App_Db']['dsn']['slave'] = $app['App_Db']['dsn']['test'];
            break;
        default :
            //ライブサーバー
            $app['core']['debug'] = false;
            break;
        }
        BEAR::init($app);
    }

    /**
     * コールバック
     *
     * @param string $event 　イベント
     * @param array  $config
     */
    public static function onCall($event, array $config)
    {
    }
}
// init
App::init();

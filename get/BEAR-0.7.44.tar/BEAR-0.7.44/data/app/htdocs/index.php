<?php
/**
 * App
 *
 * @category   BEAR
 * @package    App_Page
 */
require_once 'App.php';
/**
 * Untitledページ
 *
 * <pre>
 * Enter description here...
 * </pre>
 *
 * @package    App
 * @subpackage Page
 * @author     $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @version    SVN: Release: $Id: index.php 692 2009-07-03 19:02:35Z koriyama@users.sourceforge.jp $
 */
class Page_Index extends App_Page
{

    /**
     * Injection
     */
    public function onInject()
    {
        parent::onInject();
    }

    /**
     * Init
     *
     * @return void
     */
    public function onInit(array $args)
    {
        // RSS resource
        $uri = 'http://www.excite.co.jp/News/xml/rss_excite_news_odd_index_utf_8.dcg';
        $options['pager'] = 5;
        $params = array('uri' => $uri, 'values' => array(), 'options' => $options);
        $this->_resource->read($params)->set('news');
        $this->set('time', date('n/j H:i'));
    }

    /**
     * Output
     *
     * @return void
     */
    public function onOutput()
    {
        $this->display();
    }
}
$config = array('cache' => array('type' => 'init', 'life' => 10));
BEAR_Main::run('Page_Index', $config);
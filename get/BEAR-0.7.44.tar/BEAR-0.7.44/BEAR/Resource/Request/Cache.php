<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Cache.php 835 2009-08-18 03:54:51Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */
/**
 * リソースキャッシュクラス
 *
 * <pre>
 * リソースリクエストをキャッシュするクラスです。キャッシュするオブジェクトかそうでないかをfacotryで判断しています。
 * DIコンテナでBEAR_Resource_Requestクラスに注入されます。
 * </pre>
 *
 * @category  BEAR
 * @package   BEAR_Resource
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Cache.php 835 2009-08-18 03:54:51Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */
class BEAR_Resource_Request_Cache extends BEAR_Factory
{

    /**
     * コンストラクタ
     *
     * @param array $config 設定
     */
    public function __construct(array $config)
    {
        parent::__construct($config);
    }

    /**
     * factory
     *
     * <pre>
     * DIコンテナで生成されBEAR_Resource_Requesオブジェクトに注入されます
     * </pre>
     *
     * @param array $config コンフィグ
     *
     * @return object
     */
    public function factory()
    {
        $isCacheRequst = isset($config['options']['cache']) && !(isset($_GET['_cc'])) && false;
        if ($isCacheRequst === true) {
            $obj = $this;
        } else {
            $obj = BEAR::factory('BEAR_Resource_Execute', $this->_config);
        }
        return $obj;
    }

    /**
     * リクエスト実行クラスを返す
     *
     * <pre>
     * 実行オブジェクトを作成して返します
     * </pre>
     *
     * @param string $uri    URI
     * @param array  $values 引数
     * @param string $method リクエストメソッド
     *
     * @return BEAR_Ro
     */
    public function request()
    {
        if (isset($options['cache']['key'])) {
            $cacheKey = $options['cache']['key'];
        } else {
            $start = isset($_GET['_start']) ? $_GET['_start'] : '';
            $sval = serialize($this->_values);
            $sopt = serialize($this->_config);
            $cacheKey = "$this->_uri}{$sval}-{$sopt}-{$start}";
            //set
            $options['cache']['key'] = $cacheKey;
        }
        // キャッシュ
        $cache = BEAR::dependency('BEAR_Cache');
        $cache->setLife($options['cache']['life']);
        $ro = $cache->get($cacheKey);
        if ($ro) {
            // キャッシュ読み込み
        } else {
            // キャッシュ書き込み
            $config = compact('method', 'uri', 'values', 'options');
            $obj = BEAR::factory('BEAR_Resource_Execute', $config);
            $ro = $obj->request($method, $uri, $values, $options);
            if (!PEAR::isError($ro)) {
                $cache->set($cacheKey, $ro);
            } else {
                // キャッシュ生成エラー
                $msg = 'No Resource Cache Write';
                $info = array(
                    'ro class' => get_class($ro));
                throw $this->_exception($msg, array(
                    'info' => $info));
            }
        }
        return $ro;
    }
}

<?php

/**
 * BEAR_Resource
 *
 * PHP versions 5
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Output
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: ajax.php 687 2009-07-03 14:49:14Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */
/**
 * JSON出力
 *
 * @param array $values 無効
 * @param array $options 無効
 *
 * @return BEAR_Vo
 */
function outputAjax($values, $options = null)
{
    $ajax = BEAR::get('BEAR_Page_Ajax');
    $values = $ajax->getAjaxValues();
    $body = json_encode($values);
    $log = BEAR::dependency('BEAR_Log');
    $log->log('AJAX', $values);
    $headers = array('X-BEAR-Output: AJAX' => 'Content-Type: text/javascript+json; charset=utf-8');
    $vo = BEAR::factory('BEAR_Vo');
    $vo->setBody($body);
    $vo->setHeaders($headers);
    return $vo;
}
<?php

/**
 * App_Smarty
 * 
 * PHP versions 5
 *
 * @category  BEAR
 * @package   App_Smarty
 * @author    $Author: koriyama@users.sourceforge.jp $ <username@example.com>
 * @version   SVN: Release: $Id: untitledmodfier.php 688 2009-07-03 15:57:58Z koriyama@users.sourceforge.jp $
 */
/**
 * untitledモディファイアー
 *
 * <pre>
 * description here...
 * </pre>
 * 
 * @param string $string 文字列
 * @param int    $opt
 * 
 * @return string
 * @link http://www.smarty.net/manual/ja/language.modifiers.php
 */
function smarty_modifier_untitledmodifier($string, $opt = '')
{
    return $result;
}
<?php
/**
 * App Smarty plugin
 * @package App
 * @subpackage smarty
 */

/**
 * example block plugin
 *
 * Enter description here...
 *
 * @author      $Author:$
 * @version     $Id:$
 * @param array
 *  + key1: unknown_type
 *  + key2: unknown_type
 * @param string $params
 * @param string $content
 * @param object $smarty object
 * @return string
 */
function smarty_block_sample($params, $content, &$smarty)
{
    return $result;
}
 <?php

/**
 * BEARリソースソケットサーバー
 * 
 * <pre>
 * リソースをソケットで使用するサーバーです。
 * <アプリケーション>/cli/server.phpなどにコピーして使います。
 * </pre>
 * 
 * PHP versions 5
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Server
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: server.php 386 2008-12-09 02:21:16Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR/BEAR.html
 */

require_once '../../App.php';

// BEARサーバースタート
$server = new BEAR_Resource_Server();
$port = 10082;
$isFork = false;
$handlerName = 'BEAR_Resource_Server_Handler';
$server->start($port, $isFork, $handlerName);

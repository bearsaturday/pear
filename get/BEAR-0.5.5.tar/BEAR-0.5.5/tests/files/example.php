<?php
define('CAR', 'ROADERSTER');
?>
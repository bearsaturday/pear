<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Error
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Error.php 537 2009-03-10 06:50:01Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Error/BEAR_Error.html
 */

/**
 * エラークラス
 *
 * <pre>
 * エラーを取り扱います。エラーページ表示、エラーログ等の機能があります。
 *
 * Example 1. 重大エラー
 * </pre>
 * <code>
 * PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_APP, E_ERROR, 'error', array('hoge' => $hoge),'Hoge is not valid.');
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Error
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Error.php 537 2009-03-10 06:50:01Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Error/BEAR_Error.html
 */
class BEAR_Error
{

    /**
     * PHPエラーパッケージ名
     *
     */
    const PACKAGE_PHP = 'PHP_Error';

    /**
     * BEARエラーパッケージ名
     *
     */
    const PACKAGE_BEAR = 'BEAR_Error';

    /**
     * Appエラーパッケージ名
     *
     */
    const PACKAGE_APP = 'App_Error';

    /**
     * Resourceエラーパッケージ名
     */
    const PACKAGE_RESOURCE = 'Resource_Error';

    /**
     * 500エラーのデフォルトメッセージ
     */
    const MSG_ERROR_500 = 'Serivice is not temporary available.';

    /**
     * エラー統計
     *
     * @var integer
     */
    public static $errorStat;

    /**
     * デバック用アサートハンドラー
     *
     * <pre>
     * (BEAR使用)
     * デバック用のアサートハンドラです。
     * </pre>s
     *
     * @param string  $file ファイル名 
     * @param integer $line 行番号
     * @param integer $code エラーコード
     *
     * @return void
     * @ignore
     */
    public static function onDebugAssert($file, $line, $code)
    {
        $array = array('File' => $file, 'Line' => $line, 'Code' => $code);
        if (BEAR_Page::isAjaxRequest()) {
            BEAR_Log::appLog(array('!Assert' => $array));
            BEAR_Log::writeHTMLLog();
            BEAR_Error::ajaxError();
        } else {
            BEAR_Log::appLog(array('!Assert' => $array));
            //トレースログ
            $log["Trace"] = debug_backtrace();
            unset($log["Trace"][0]);
            $trace = debug_backtrace();
            unset($trace[0]);
            print_a($trace, "label:Assert in {$trace[1]['file']} on line {$trace[1]['line']}");
        }
    }

    /**
     * ライブ用エラーハンドラー
     *
     * <pre>
     * ライブ用のエラーハンドラーです。アプリケーションのエラーハンドラーが
     * 何もしなければログ保存します。
     * エラーログが全く必要ない場合はApp::onError()でfalseを返します。
     * </pre>
     *
     * @param PEAR_Error $error エラーオブジェクト
     *
     * @return mixed
     * @ignore
     */
    public static function onLveError($error)
    {
        $appError = App::onError($error);
        if ($appError === false) {
            return PEAR_ERRORSTACK_IGNORE;
        } else {
            return PEAR_ERRORSTACK_LOG;
        }
    }

    /**
     * エラーハンドラー
     *
     * <pre>
     * デバック用のエラーハンドラーです。詳細情報を変数に保存し
     * シャットダウン時にシリアライズします。
     * </pre>
     *
     * @param PEAR_Error $error エラーオブジェクト
     *
     * @return mixed
     * @ignore
     */
    public static function onDebugError($error)
    {
        static $reported = array();
        static $pearErrorCnt = 0;

        $appError = App::onError($error);
        if ($appError === false) {
            return $appError;
        }
        //ログの内容
        //パッケージ毎の処理
        switch (strtolower($error['package'])) {
            case 'php_error' :
                $errorStringData = array(E_ERROR => 'E_ERROR', E_WARNING => 'E_WARNING', E_PARSE => 'E_PARSE', E_NOTICE => 'E_NOTICE', E_CORE_ERROR => 'E_CORE_ERROR', E_CORE_WARNING => 'E_CORE_WARNING', E_COMPILE_ERROR => 'E_COMPILE_ERROR', E_COMPILE_WARNING => 'E_COMPILE_WARNING', E_USER_ERROR => 'E_USER_ERROR', E_USER_WARNING => 'E_USER_WARNING', E_USER_NOTICE => 'E_USER_NOTICE', E_STRICT => 'E_STRICT', E_RECOVERABLE_ERROR => 'E_RECOVERABLE_ERROR');
                $errorString = $errorStringData[$error['code']];

                //同じエラーは無視=ignore_repeated_errors 0と同様の処理
                $key = ("{$error['params']['file']}{$error['params']['line']}");
                if (isset($reported[$key])) {
                    $result = PEAR_ERRORSTACK_IGNORE;
                    return $result;
                } else {
                    $reported[$key] = true;
                }
                $location = "{$error['params']['file']} on Line {$error['params']['line']}";
                $trace = debug_backtrace();
                if (isset($trace[5])) {
                    $trace = $trace[5];
                    $traceClass = isset($trace['class']) ? "{$trace['class']}::" : '';
                    $log['message'] = $error['message'];
                    if (isset($trace['args']) && is_array($trace['args'])){
                        foreach ($trace['args'] as &$argItem) {
                            $argItem = BEAR_Util::toString($argItem);
                        }
                        @$args = implode(', ', $trace['args']);
                    }
                    $args = 'void';
                    $class = (isset($trace['class'])) ? ", {$trace['class']}{$trace['type']}{$trace['function']}(" . $args . ")" : '';
                    if (isset($trace['file'])) {
                        $trace['file'] = BEAR_Util::removeKnownPath($trace['file']);
                        $log['trace'] = "{$trace['file']} on Line {$trace['line']}{$class}";
                        if ($log['trace'] == $location) {
                            unset($log['trace']);
                        }
                    }
                }
                //レベル別処理
                switch ($error['code']) {
                    case E_ERROR :
                    case E_USER_ERROR :
                        $fireLevel = 'ERROR';
                        $result = PEAR_ERRORSTACK_LOG;
                    case E_USER_WARNING :
                    case E_WARNING :
                        $fireLevel = 'WARN';
                        BEAR_Log::appLog($errorString, $log);
                        $result = PEAR_ERRORSTACK_LOG;
                        break;
                    case E_USER_NOTICE :
                    case E_NOTICE :
                        $fireLevel = false;
                        BEAR_Log::appLog($errorString, $log);
                        $result = PEAR_ERRORSTACK_IGNORE;
                        break;
                    case E_STRICT :
                    default :
                        $fireLevel = false;
                        $result = PEAR_ERRORSTACK_IGNORE;
                        break;
                }
                if ($fireLevel && !(php_sapi_name() == 'cli' || BEAR_Agent::isBearAgent())) {
                    p("{$errorString}: {$error['message']}", 'fire', array('level' => $fireLevel));
                }
                break;
                    case 'exception' :
                        BEAR_Log::appLog("Exception", $log);
                        $result = PEAR_ERRORSTACK_IGNORE;
                        break;
                    case 'bear_error' :
                        $trace = debug_backtrace();
                        $class = isset($error['context']['class']) ? "{$error['context']['class']}::" : '';
                        $file = $error['context']['file'];
                        $line = $error['context']['line'];
                        $func = $error['context']['function'];
                        $location = "{$file} on Line {$line}, {$class}{$func}()";
                        BEAR_Error::$errorStat |= E_ERROR;
                        if (App::$debug === true) {
                            BEAR_Error::showDebug('A System Error Occurred.', $error['message'], self::_printR($error['params']));
                        }
                        $result = PEAR_ERRORSTACK_LOG;
                        break;
                    case 'mdb2_error' :
                        static $repeat = 0;

                        if ($repeat++ < 3) {
                            BEAR_Error::$errorStat |= E_ERROR;
                            if (App::$debug) {
                                $loc = $error['params']['location'];
                                $info = $error['params']['debug_info'];
                                $msg = $error['message'];
                                BEAR_Error::showDebug('A DB Error Occured .', $msg, $info, $loc);
                            }
                        }
                        $result = PEAR_ERRORSTACK_IGNORE;
                        break;
                    case 'pear_error' :
                        self::showDebug('PEAR Error ', $error['params']['msg'], $error['params']['debug_info']);
                        $trace[] = $error['params']['trace'][1];
                        $trace[] = $error['params']['trace'][2];
                        print_a($trace, 'label: PEAR Error backtrace;');
                        BEAR_Error::$errorStat |= $error['code'];
                        $log['code'] = $error['code'];
                        $log['message'] = $error['message'];
                        $log['location'] = $error['params']['location'];
                        $log['debug_info'] = $error['params']['debug_info'];
                        BEAR_Log::appLog("{$error['package']}", $log);
                        $result = PEAR_ERRORSTACK_PUSH;
                        if ($pearErrorCnt++ > 3) {
                            exit();
                        }
                        break;
                    default :
                        BEAR_Log::appLog("{$error['package']}", $error);
                        $result = PEAR_ERRORSTACK_PUSH;
        }
        return $result;
    }

    /**
     * フィイルロガー
     *
     * <pre>
     * BEARのデフォルトのロガーはsyslogです。
     * ファイルログにしたい時にApp::onErrorでコールします。
     * </pre>
     *
     * @param PEAR_Error $error    エラーオブジェクト
     * @param string     $filePath ファイルパス
     *
     * @return void
     */
    public static function fileLog($error, $filePath = false)
    {
        $filePath = ($filePath) ? $filePath : _BEAR_APP_HOME . '/logs/bear.log';
        // ログレベル
        switch ($error['code']) {
            case E_ERROR :
            case E_USER_ERROR :
            case E_CORE_ERROR :
                $level = PEAR_LOG_CRIT;
                break;
            case E_USER_WARNING :
            case E_WARNING :
            case E_COMPILE_WARNING :
                $level = PEAR_LOG_ERR;
                break;
            case E_USER_NOTICE :
            case E_NOTICE :
            case E_RECOVERABLE_ERROR :
                break;
            default :
                $level = PEAR_LOG_NOTICE;
        }
        //ログ内容
        $conf = array('mode' => 0644);
        $logger = &Log::singleton('file', $filePath, 'error', $conf);
        $userAgent = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : 'CLI';
        $class = isset($error['context']['class']) ? "{$error['context']['class']}::" : '';
        $msg = $error['message'];
        $file = $error['context']['file'];
        $line = $error['context']['line'];
        $func = $error['context']['function'];
        $log = "{$msg} in {$file} {$line} {$class}{$func}, agent=$userAgent";
        $logger->log($log, $level);
    }

    /**
     * 配列を文字列にする
     *
     * <pre>
     * エラー情報などの配列で受け取った値をweb画面で
     * 表示するためにシリアライズします。
     * </pre>
     *
     * @param array $array 配列
     *
     * @return string
     */
    static private function _printR($array)
    {
        foreach ($array as $key => $var) {
            if (is_string($key)) {
                if (php_sapi_name() == 'cli' || BEAR_Agent::isBearAgent()) {
                    $result[] .= "{$key}=[{$var}]";
                } else {
                    $result[] .= "<b>{$key}</b>: {$var}";
                }
            } else {
                $result[] .= "{$var}";
            }
        }
        $result = implode(' , ', $result);
        return $result;
    }

    /**
     * PEARエラーハンドラー
     *
     * PEARエラーがレイズされるとError_Stackにしてレイズしなおす
     *
     * @param object $error エラーオブジェクト
     *
     * @return void
     * @ignore
     */
    public static function onPearError($error)
    {
        $errorType = (MDB2::isError($error)) ? 'mdb2_error' : 'pear_Error';
        $trace = $error->getBacktrace();
        PEAR_ErrorStack::staticPush($errorType, $error->getCode(), 'error', array('debug_info' => $error->getDebugInfo(), 'msg' => $error->getMessage(), 'trace' => $trace));
    }

    /**
     * PHPエラーハンドラー debugモード
     *
     * <pre>
     * PHPエラーをPEAR_ErrorStackとしてパッケージしなおします
     * </pre>
     *
     * @param int    $code    コード
     * @param string $message メッセージ
     * @param string $file    ファイル
     * @param int    $line    行番号
     *
     * @return object
     * @ignore
     */
    static function onDebugPhpError($code, $message, $file, $line)
    {
        BEAR_Error::$errorStat |= $code;
        $file = BEAR_Util::removeKnownPath($file);
        $message = $message . ' in ' . $file . ' on line ' . $line;
        PEAR_ErrorStack::staticPush(self::PACKAGE_PHP, $code, 'error', array('file' => $file, 'line' => $line), $message);
    }

    /**
     * PHPエラーハンドラー liveモード
     *
     * <pre>
     * PHPエラーをPEAR_ErrorStackとしてパッケージしなおします
     * </pre>
     *
     * @param int    $code    コード
     * @param string $message メッセージ
     * @param string $file    ファイル名
     * @param int    $line    行番号
     *
     * @return object
     * @ignore
     */
    static function onLivePhpError($code, $message, $file, $line)
    {
        $message = $message . ' in ' . $file . ' on Line ' . $line;
        PEAR_ErrorStack::staticPush(self::PACKAGE_PHP, $code, 'error', array('file' => $file, 'line' => $line), $message);
    }

    /**
     * HTTPエラーまたはキャチされなかった例外ハンドラー
     *
     * <pre>
     * BEAR_Error_ExceptionクラスでスローされたHTTPステータスコードエラー
     * またはキャッチされなかった例外の詳細を表示します。
     * Fatalエラー扱いで例外元への復帰はされません。
     * </pre>
     *
     * @param mixed $e 例外 BEAR_Error_Exception | Exception
     *
     * @return void
     * @ignore
     */
    static function onException(Exception $e)
    {
        $class = get_class($e);
        $code = $e->getCode();
        //$msg = $e->getMessage();
        
        if ($class != 'BEAR_Error_Exception') {
            $code = 500;
        } else {
            BEAR_Log::appLog('BEAR_Error_Exception', $e);
        }
        BEAR_Page::outputHttpStatus($code, true);
        if (App::$debug) {
            $trace = $e->getTrace();
            if (php_sapi_name() == 'cli') {
                echo $e->getTraceAsString();
            } else {
                print_a(array('code' => $e->getCode(), 'msg' => $e->getMessage(), 'trace' => $e->getTrace()), 'label:onException;');
            }
        }
    }

    /**
     * エラーチェック
     *
     * PEAR_ErrorStackエラーオブジェクトかチェックします。
     *
     * @param mixed $error エラー
     *
     * @return bool
     */
    function isError($error)
    {
        return ($error instanceof PEAR_ErrorStack || $error instanceof PEAR_Error);
    }

    /**
     * エラーハンドル初期化
     *
     * BEAR_Errorを初期化します。フレームワークのみが使用します。
     *
     * @return void
     * @ignore
     *
     */
    public static function init()
    {
        ini_set('html_errors', 0);
        if (App::$debug == true) {
            if (isset($_GET['_error'])) {
                // set display_errors at debug.php for simple error output/
                return;
            }
            error_reporting(E_ALL);
            // アサーションを有効
            assert_options(ASSERT_ACTIVE, 1);
            assert_options(ASSERT_WARNING, 0);
            assert_options(ASSERT_QUIET_EVAL, 1);
            assert_options(ASSERT_CALLBACK, (array('BEAR_Error', 'onDebugAssert')));
            //PHP エラーハンドル
            set_error_handler(array('BEAR_Error', 'onDebugPhpError'), E_ALL);
            //例外デフォルトハンドル
            set_exception_handler(array('BEAR_Error', 'onException'));
            //PEAR_Errorハンドル
            PEAR::setErrorHandling(PEAR_ERROR_CALLBACK, array('BEAR_Error', 'onPearError'));
            //PEAR_ErrorStackハンドル
            PEAR_ErrorStack::setDefaultCallback(array('BEAR_Error', 'onDebugError'));
            //ロガー, PEAR::Log を用いたログ出力を設定する
            $logger = &Log::singleton('syslog', BEAR_Log::$local, 'BEAR');
            PEAR_ErrorStack::setDefaultLogger($logger);
        } else {
            error_reporting(E_ALL ^ E_NOTICE);
            // 開発環境ではアサーションを無効にする
            assert_options(ASSERT_ACTIVE, 0);
            // 運用環境エラーハンドラー
            $callback = array('BEAR_Error', 'onLivePhpError');
            set_error_handler($callback, E_ALL ^ E_NOTICE);
            //例外デフォルトハンドル
            set_exception_handler(array('BEAR_Error', 'onException'));
            //PEAR_Errorハンドル
            PEAR::setErrorHandling(PEAR_ERROR_CALLBACK, array('BEAR_Error', 'onPearError'));
            //PEAR_ErrorStackハンドル
            PEAR_ErrorStack::setDefaultCallback(array('BEAR_Error', 'onLveError'));
            //ロガー, PEAR::Log を用いたログ出力を設定する
            //            $log = Log::Factory('file', _BEAR_APP_HOME . '/logs/bear.log', 'bear');
            $logger = &Log::singleton('syslog', BEAR_Log::$local, 'BEAR');
            PEAR_ErrorStack::setDefaultLogger($logger);
        }
        return;
    }

    /**
     * debugエラーメッセージ表示
     *
     * エラーをdebug時にのみ表示します
     *
     * @param string $heading    見出し
     * @param string $subheading サブ見出し
     * @param string $messageOne メッセージ1
     * @param string $messageTwo メッセージ2
     *
     * @return void
     * @access static
     */
    public static function showDebug($heading, $subheading = "", $messageOne = "", $messageTwo = "")
    {
        BEAR_Log::$errorStat |= E_ERROR;
        if (App::$debug) {
            if (php_sapi_name() == 'cli' || BEAR_Agent::isBearAgent()) {
                echo $heading . PHP_EOL;
                echo $subheading . PHP_EOL;
                echo $messageOne . PHP_EOL;
                echo $messageTwo . PHP_EOL;
            } else {
                header('Content-Type: text/html; charset=utf-8');
                echo '<div style="padding: 0.5em 0em 0.5em 0.5em; margin: 1em 2em 1em 2em;';
                echo 'border-style: solid; border-color: #ff0000; background-color: #ffbaba;">';
                echo '<div style="font-size: 16px; font-weight: bold; margin: 10px 0 10px 0;">';
                echo nl2br($heading) . '</div>';
                echo '<div style="font-size: 14px; color: #000000;margin: 10px 0 10px 0;";">';
                echo nl2br($subheading) . '</div>';
                if ($messageOne) {
                    echo '<div style="font-size: 12px; color: #201010;margin: 10px 0 10px 0;";">';
                    echo nl2br($messageOne);
                    echo '</div>';
                }
                if ($messageTwo) {
                    echo '<div style="font-size: 12px; color: #201010;margin: 10px 0 10px 0;";">';
                    echo nl2br($messageTwo);
                    echo '</div>';
                }
                echo '</div><br />';
            }
        }
    }

    /**
     * Fatalエラーハンドラ
     *
     * @param string $buffer バッファ
     *
     * @return string
     * @ignore
     *
     * <code>
     * ob_start(array('BEAR_Errpr', 'fatalErrorHandler'); // Fatal Errorハンドラをセット
     * </code>
     */
    public static function onFatalError($buffer)
    {
        if (strpos($buffer, 'Fatal error:') !== false) {
            //エラーログ
            $matches = array();
            preg_match('/Fatal error: (.*)( in )(.*)( on line )(\d+)/', $buffer, $matches);
            $error = array('all' => $matches[0], 'message' => $matches[1], 'file' => $matches[3], 'line' => $matches[5]);
            // CLI ?
            if (PHP_SAPI == 'cli' || BEAR_Page::isAjaxRequest()) {
                return $buffer;
            }
            // Web
            header("HTTP/1.x 503 Service Temporarily Unavailable (BEAR)");
            header("X-Bear-Error: " . $error['message']);
            if (is_callable(array('App', 'onFatalError'))) {
                $return = call_user_func(array('App', 'onFatalError'), $error);
                if (is_string($return)) {
                    return $return;
                }
            }
            //エラーページを記録
            $errorId = substr(md5($matches[0]), 0, 8);
            $path = _BEAR_APP_HOME . '/logs/' . 'fatal-' . $errorId . '.log';
            error_log("{$matches[0]} fatal-{$errorId}");
            if (!file_exists($path)) {
                file_put_contents($path, $buffer);
            }
            $errorOne = file_get_contents(_BEAR_BEAR_HOME . '/BEAR/Error/error.503.1.php');
            $errorTwo = file_get_contents(_BEAR_BEAR_HOME . '/BEAR/Error/error.503.2.php');
            if (App::$debug === true) {
                $out = $errorOne . $errorId . $errorTwo . $buffer;
            } else {
                $out = $errorOne . $errorId . $errorTwo;
            }
            return $out;
        }
        return $buffer;
    }
}
// PHPバッファスタート
ob_start(array('BEAR_Error', 'onFatalError'));
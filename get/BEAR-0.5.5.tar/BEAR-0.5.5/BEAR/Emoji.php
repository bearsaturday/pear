<?php
/**
 * BEAR
 * 
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR_Emoji
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Emoji.php 421 2009-01-06 11:21:59Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Emoji/BEAR_Emoji.html
 */

/**
 * 絵文字クラス
 *
 * <pre>
 * 絵文字を取り扱うためのクラスです。
 * 携帯の絵文字のキャリア相互変換、imgタグによる絵文字の
 * 画像表示が行えます。
 * ソフトバンクモバイルの3G端末、旧端末どちらもサポートします。
 * UTF8絵文字からwebコード絵文字の変換が行えます。
 * 絵文字変換はメール時の変換にキャリアが仕様してる変換マップに
 * 基づいています。対応する絵文字が無い場合はカタカナで表現されます。
 *
 * Example 1. iモード絵文字の絵文字を含む文字列を閲覧しているUAに応じて変換
 *
 * </pre>
 * <code>
 * //iモード絵文字を現在のUAの携帯絵文字に変換
 * $emoji = BEAR_Emoji::getInstance($string, BEAR_Agent::UA_DOCOMO);
 * $result = $emoji->convert();
 * </code>
 *
 * Example 2. UTF8のSB文字列のポストをWebコードに変換する
 *
 * <code>
 * $result = BEAR_Emoji::encodeWebCode($sb_utf8_emoji);
 * </code>
 *
 * Example 3. 絵文字を除去する
 *
 * <code>
 * $result = BEAR_Emoji::removeEmoji($string);
 * </code>
 *
 * Example 4. 絵文字をIMGタグにする
 *
 * <code>
 * //タグをセット
 * BEAR_Emoji::setDefaultImgTag('<img src="/emoji/');
 * $emoji = BEAR_Emoji::getInstance($string, BEAR_Agent::UA_DOCOMO);
 * $result = $emoji->imgTag();
 * </code>
 *
 * @category  BEAR
 * @package   BEAR_Emoji
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Emoji.php 421 2009-01-06 11:21:59Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Emoji/BEAR_Emoji.html
 */
class BEAR_Emoji
{

    /**
     * iモード絵文字10進数エンティティ開始番号
     *
     */
    const IMODE_MIN = 63552; //#F840

    
    /**
     * iモード絵文字10進数エンティティ終了番号
     *
     */
    const IMODE_MAX = 63996; //#F9FC

    
    /**
     * Ez絵文字10進数エンティティ開始番号
     *
     */
    const EZ_MIN = 62272; //#F340

    
    /**
     * Ez絵文字10進数エンティティ終了番号
     *
     */
    const EZ_MAX = 63484; //#F7FC

    
    /**
     * 絵文字imgタグ
     */
    public static $imgTag = '<img src="/emoji';

    /**
     * 入力文字列
     *
     * @var string
     * @access private
     */
    private $_string;

    /**
     * 携帯キャリアコード
     *
     * @var string
     * @access private
     */
    private $_ua;

    /**
     * 絵文字変換テーブル1
     *
     * @var bool
     * @access private
     */
    private $_emojiConvertMap = false;

    /**
     * シングルトンインスタンス
     *
     * @var BEAR_Emoji
     */
    private static $_instance;

    /**
     * シングルトンパターンクラスのためコンストラクタ不可
     * 
     */
    final private function __construct($string, $ua)
    {
        $this->_string = $string;
        $this->_ua = $ua;
    }

    /**
     * シングルトン
     *
     * シングルトンででインスタンスを取得します
     * 
     * <pre>
     * $options
     * 
     * 'string' string 文字列
     * 'ua'     mixed  false=現在のUAもしくくは文字列でUA指定
     * </pre
     *
     * @param array $options オプション
     * 
     * @return BEAR_Emoji
     */
    public function getInstance($string, $ua = false)
    {
        $ua = ($ua === false) ? BEAR::$ua : $ua;
        $id = md5($string . $ua);
        if (!isset(self::$_instance[$id])) {
            //インスタンス生成
            self::$_instance[$id] = new BEAR_Emoji($string, $ua);
        }
        // SBコード変換 - SBではなくSJISでもない文字列を
        // BEAR_Emojiクラス内でSJIS-winとして処理するため
        $mb = mb_detect_encoding($string, 'SJIS-win, utf-8', true);
        if ($ua != BEAR_Agent::UA_SOFTBANK && $mb != 'SJIS-win') {
            $string = mb_convert_encoding($string, 'SJIS-win', 'UTF-8');
        }
        return self::$_instance[$id];
    }

    /**
     * SB3G端末の絵文字入りUTF-8コードの文字列をwebコードの絵文字文字列に変換
     *
     * <pre>SB3G端末からポストされた絵文字入りのユニコード文字列を
     * webコードのUTF-8に変換します。
     * (注意）3G端末のSJISページでは絵文字はポストされない。
     * SBで絵文字を取り扱うにはUTF8ページを用意する必要があります。
     * </pre>
     *
     * @param string $utfEight 文字列
     * 
     * @return string
     * @static
     */
    public static function encodeWebCode($utfEight)
    {
        $result = array();
        $unicodes = I18N_UnicodeString::utf8ToUnicode($utfEight);
        foreach ($unicodes as $unicodeDecimal) {
            //絵文字処理
            if (($unicodeDecimal > 0xE000 && $unicodeDecimal <= 0xE53E)) {
                if (($unicodeDecimal > 0xE000 && $unicodeDecimal < 0xE100)) {
                    $offset = hexdec('98E0');
                } elseif ($unicodeDecimal > 0xE100 && $unicodeDecimal < 0xE300) {
                    $offset = hexdec('9BE0');
                } else {
                    $offset = hexdec('93E0');
                }
                $webcodeDecimal = $unicodeDecimal - $offset;
                //絵文字
                //1B24 (ESC開き)
                $result[] = 0x1b;
                $result[] = 0x24;
                //絵文字2バイトコード
                $result[] = ($webcodeDecimal >> 8) & 0xff;
                $result[] = $webcodeDecimal & 0xff;
                //0F (ESC閉じ)
                $result[] = 0x0f;
            } else {
                //非絵文字
                $result[] = $unicodeDecimal;
            }
        }
        //unicodeからUTF8に
        $iEighteen = new I18N_UnicodeString($result, 'Unicode');
        $result = $iEighteen->toUtf8String();
        return $result;
    }

    /**
     * 10進数エンティティをつくる
     *
     * <pre>
     * stringプロパティの文字列を10進エンティティにして
     * entityプロパティに格納して返します
     * </pre>
     * 
     * @param bool $isSbUtfPost SBでUTF8からポストされたか
     * 
     * @return string
     */
    public function makeDecEntity($isSbUtfPost = false)
    {
        switch ($this->_ua) {
        case BEAR_Agent::UA_SOFTBANK :
            if ($isSbUtfPost) {
                $unicodes = I18N_UnicodeString::utf8ToUnicode($this->_string);
                $iEighteen = new I18N_UnicodeString($unicodes, 'Unicode');
                $this->_string = $iEighteen->toUtf8String();
                $encode = 'UTF8';
                $converterMap = $this->_getEmojiMap();
                $this->_string = mb_encode_numericentity($this->_string, $converterMap, $encode);
            } else {
                //'SJIS-win'
                $emojiRegex = '[\xE0-\xE4][\x00-\xFF]|[\xE5][\x00-\x3A]';
                $this->_string = $this->_makeEntityByRegex($this->_string, $emojiRegex);
            }
            break;
        case BEAR_Agent::UA_DOCOMO :
            $emojiRegex = '[\xF8\xF9][\x40-\x7E\x80-\xFC]';
            $this->_string = $this->_makeEntityByRegex($this->_string, $emojiRegex);
            break;
        case BEAR_Agent::UA_AU :
            // AUの文字範囲
            // F340～F3FC
            // F440～F493
            // F640～F6FC
            // F740～F7FC
            $emojiRegex = '[\xF3\xF6\xF7][\x40-\xFC]|[\xF4][\x40-\x93]';
            $this->_string = $this->_makeEntityByRegex($this->_string, $emojiRegex);
            break;
        default :
            trigger_error('Agent is not mobile.' , E_USER_NOTICE);
            $encode = '';
            break;
        }
        return $this->_string;
    }

    /**
     * 正規表現により絵文字を数値エンティティに変換
     *
     * makeDecEntity()からコールされます。
     *
     * @param string $string 文字列
     * @param string $emoji  絵文字の正規表現
     * 
     * @return string
     */
    private function _makeEntityByRegex($string, $emoji)
    {
        $mbRegexEncoding = mb_regex_encoding();
        mb_regex_encoding('SJIS');
        $sjis = '[\x81-\x9F\xE0-\xEF][\x40-\x7E\x80-\xFC]|[\x00-\x7F]|[\xA1-\xDF]';
        $pattern = "/\G((?:$sjis)*)(?:($emoji))/";
        // 絵文字を検索
        preg_match_all($pattern, $string, $arr); // $arr[2]に対象絵文字が格納される
        // 絵文字を置換
        $converted = $string;
        foreach ($arr[2] as $value) {
            $patternRep = "$value";
            $emojiCd = unpack("C*", $value);
            $hex = dechex($emojiCd[1]) . dechex($emojiCd[2]);
            $replacement = '&#' . hexdec($hex) . ';';
            $converted = mb_ereg_replace($patternRep, $replacement, $converted);
        }
        mb_regex_encoding($mbRegexEncoding);
        return $converted;
    }

    /**
     * 16進エンティティをつくる
     *
     * <pre>
     *  10進エンティティから16進エンティティをつくります。
     * _stringプロパティの文字列を10進エンティティにして
     * _stringプロパティに格納して返します
     * </pre>
     *
     * @return string
     */
    public function makeHexEntity()
    {
        $regex = '/&#(\d{5});/is';
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', '_onHexEntity'), $this->_string);
        return $this->_string;
    }

    /**
     * PCで携帯絵文字を表示するために対応するgif画像にする
     *
     * <pre>
     *  10進エンティティから絵文字画像のimgタグをつくります。
     * _stringプロパティの文字列を10進エンティティにして
     * entityプロパティに格納して返します
     * </pre>
     *
     * @return string
     */
    public function makeImgTag()
    {
        //変換
        if (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) {
            $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
        } else {
            $regex = '/&#(\d{5});/is';
        }
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', '_onImgTag'), $this->_string);
        return $this->_string;
    }

    /**
     * 絵文字をIMGタグに変換します
     *
     * 絵文字を内部で10進エンティティにした後、
     * キャリアが違えば対応する絵文字のイメージタグにします。
     *
     * @return string
     */
    public function imgTag()
    {
        $this->makeDecEntity();
        $result = $this->makeImgTag();
        return $result;
    }

    /**
     * 16進エンティティ絵文字表記にするための正規表現からコールバックメソッド
     *
     * @param array $matches 検索文字列
     * 
     * @return string
     * @access private
     */
    private function _onHexEntity($matches)
    {
        $result = '&#x' . dechex($matches[1]) . ';';
        return $result;
    }

    /**
     * イメージタグを生成するための正規表現からコールバックメソッド
     *
     * @param array $matches 検索結果
     * 
     * @return $matches　検索文字列
     * @access private
     */
    private static function _onImgTag($matches)
    {
        $imgTag = BEAR_Emoji::$imgTag;
        $ext = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) ? '.png' : '.gif';
        $emojiId = $matches[1];
        switch (BEAR::$ua) {
        case BEAR_Agent::UA_DOCOMO :
            $emojiId = strtoupper(dechex($emojiId));
            $imageFileName = $emojiId . $ext;
            $result = "{$imgTag}/" . BEAR_Agent::UA_DOCOMO . "/{$imageFileName} border=0 />";
            break;
        case BEAR_Agent::UA_AU :
            $emojiId = (dechex($emojiId));
            $imageFileName = $emojiId . $ext;
            $result = "{$imgTag}/" . BEAR_Agent::UA_AU . "/{$imageFileName} border=0 />";
            break;
        case BEAR_Agent::UA_SOFTBANK :
            $sbEmoji = array();
            $stirng = $matches[0];
            for ($i = 3; $i < strlen($stirng) - 1; $i++) {
                $sbEmoji[] = $stirng[$i];
            }
            $result = "";
            foreach ($sbEmoji as $emoji) {
                $webcodeHexHigh = dechex(ord($stirng[2]));
                $webcodeHexLow = dechex(ord($emoji));
                $webcodeHexHighlow = strtoupper($webcodeHexHigh . $webcodeHexLow);
                $imageFileName = $webcodeHexHighlow . $ext;
                $result = "{$imgTag}/" . BEAR_Agent::UA_SOFTBANK . "{$imageFileName} border=0 />";
            }
            break;
        default :
            trigger_error('BEAR_Emoji,piev PEAR static property not defined.');
            break;
        }
        return $result;
    }

    /**
     * imageTag用コールバック関数
     *
     * <pre>自分のキャリアではない絵文字をイメージタグに変換して返します</pre>
     *
     * @param array $matches 検索文字列
     * 
     * @return string
     * @access private
     * @deprecated
     */
    private static function _onEmojiImage($matches)
    {
        $imgTag = & PEAR::getStaticProperty('BEAR_Emoji', 'img_tag');
        if (!$imgTag) {
            $imgTag = '<img src="/emoji';
        }
        $ext = (BEAR::$ua == BEAR_Agent::UA_SOFTBANK) ? '.png' : '.gif';
        $emojiId = $matches[1];
        //キャリア判定
        if (self::IMODE_MIN <= $emojiId && $emojiId <= self::IMODE_MAX) {
            $ua = BEAR_Agent::UA_DOCOMO;
        } elseif (self::EZ_MIN <= $emojiId && $emojiId <= self::EZ_MAX) {
            $ua = BEAR_Agent::UA_AU;
        } else {
            $ua = BEAR_Agent::UA_SOFTBANK;
        }
        $agent = & PEAR::getStaticProperty('BEAR_Emoji', 'agent_piev');
        if ($agent == $ua) {
            //Docomo/Ezの場合はエンティティからpack,SBの場合はWebコードのまま
            $result = pack('n', $emojiId);
        } else {
            switch ($ua) {
            case BEAR_Agent::UA_DOCOMO :
                $emojiId = dechex($emojiId);
                $imageFileName = $emojiId . $ext;
                $result = "{$imgTag}/" . strtolower($ua) . "/{$imageFileName}\" border=0 />";
                break;
            case BEAR_Agent::UA_AU :
                $emojiId = dechex($emojiId);
                $imageFileName = $emojiId . $ext;
                $result = "{$imgTag}/{$ua}/{$imageFileName}\" border=0 />";
                break;
            case BEAR_Agent::UA_SOFTBANK :
                $sbEmoji = array();
                $stirng = $matches[0];
                for ($i = 3; $i < strlen($stirng) - 1; $i++) {
                    $sbEmoji[] = $stirng[$i];
                }
                $result = '';
                foreach ($sbEmoji as $emoji) {
                    $webcodeHexHigh = dechex(ord($stirng[2]));
                    $webcodeHexLow = dechex(ord($emoji));
                    $imageFileName = strtoupper($webcodeHexHigh . $webcodeHexLow) . $ext;
                    $result = "{$imgTag}/{$ua}/{$imageFileName}\" border=0 />";
                }
                break;
            default :
                break;
            }
        }
        return $result;
    }

    /**
     * 絵文字コードマップの取得
     *
     * <pre>
     * 絵文字コードマップの配列を取得します。
     *
     * マップフォーマット
     * i,e
     * 絵文字UNICODE開始, 絵文字UNICODE終了,UNICODE<=>SJISオフセット, マスク
     * v
     * </pre>
     *
     * @param string $ua ユーザーエージェントレター
     * 
     * @return array
     * @access private
     */
    private function _getEmojiMap($ua = false)
    {
        if (!$ua) {
            $ua = $this->_ua;
        }
        switch ($this->_ua) {
        case BEAR_Agent::UA_DOCOMO :
            /*
             * F89F-F8FC(SJIS)
             * F940-F949
             * F972-F97E
             * F980-F9FC
             */
            // Unicode絵文字表
            $result = array(0xE63E, 0xE69B, 0x1261, 0xFFFF, 
                            0xE69C, 0xE6A5, 0x12A4, 0xFFFF, 
                            0xE6CE, 0xE6DA, 0x12A4, 0xFFFF, 
                            0xE6DB, 0xE757, 0x12A5, 0xFFFF); 
            break;
            /**
             * 0xF640 0xF67E
             * 0xF680-0xF6FC
             * 0xF740-0xF77E
             * 0xF780-
             * 0xF7E5-
             * 0xF340-
             * 0xF353-
             * 0xF380-
             * 0xF7D2-
             * 0xF3CF-
             * 0xF440-
             * 0xF480-
             */
        case BEAR_Agent::UA_AU :
            $result = array(0xE468, 0xE4A6, 0x11D8, 0xFFFF,
                            0xE4A7, 0xE523, 0x11D9, 0xFFFF,
                            0xE524, 0xE562, 0x121C, 0xFFFF, 
                            0xE563, 0xE5B4, 0x121D, 0xFFFF,
                            0xE5B5, 0xE5CC, 0x1230, 0xFFFF,
                            0xE5CD, 0xE5DF, 0x0D73, 0xFFFF,
                            0xEA80, 0xEAAB, 0x08D3, 0xFFFF, 
                            0xEAAC, 0xEAFA, 0x08D4, 0xFFFF,
                            0xEAFB, 0xEB0D, 0x0CD7, 0xFFFF,
                            0xEB0E, 0xEB3B, 0x08C1, 0xFFFF,
                            0xEB3C, 0xEB7A, 0x0904, 0xFFFF,
                            0xEB7B, 0xEB88, 0x0905, 0xFFFF); 
            break;
        case BEAR_Agent::UA_SOFTBANK :
            $result = array(0xE000, 0xE53A, 0x000, 0xFFFF);
            break;
        default :
            $result = PEAR::raiseError('invalid ua');
            break;
        }
        return $result;
    }

    /**
     * 絵文字変換
     *
     * <pre>
     * 絵文字変換マップを使って10進エンティティから
     * 他キャリアの対応する絵文字に変換します。
     * </pre>
     *
     * @param string $to デフォルトはエージェント
     * 
     * @return string
     */
    public function convert($to = false)
    {
        //10進エンティティに
        $this->makeDecEntity();
        $toRef = & PEAR::getStaticProperty('BEAR_Emoji', 'to');
        //toを保存
        $toRef = ($to) ? $to : BEAR::$ua;
        //変換
        if ($this->_ua == BEAR_Agent::UA_SOFTBANK) {
            $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
        } else {
            $regex = '/&#(\d{5});/is';
        }
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', '_onConvertEmoji'), $this->_string);
        return $this->_string;
    }

    /**
     * エンティティ化されている絵文字を含んだ文字列をイメージタグに変換します
     *
     * <pre>smartyのoutputフィルターなどに使用します。$uaで指定したエージェント
     * (無指定の場合は使用しているエージェント）の絵文字はバイナリ出力されます。
     * PC(_BAER_UA_PC)を指定すると全ての絵文字がイメージタグ表示されます。</pre>
     *
     * @param string $string 文字列
     * @param string $ua     ユーザーエジェンとトター
     * 
     * @return string
     * @static
     * @deprecated
     * @ignore
     */
    public function imageTag($string, $ua = false)
    {
        if (!$ua) {
            $ua = BEAR::$ua;
        }
        $agent = & PEAR::getStaticProperty('BEAR_Emoji', 'agent_piev');
        $agent = $ua;
        //Docomo/Ezweb変換
        $regex = '/&#(\d{5});/is';
        $func = array('BEAR_Emoji', '_onEmojiImage');
        $string = preg_replace_callback($regex, $func, $string);
        //Softbank変換
        if (BEAR::$ua != BEAR_Agent::UA_SOFTBANK) {
            $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
            $string = preg_replace_callback($regex, $func, $string);
        }
        $result = preg_replace_callback($regex, $func, $string);
        return $result;
    }

    /**
     * AU絵文字変換
     *
     * <pre>local img形式のAU絵文字を10進エンティティ表記に変換します。</pre>
     *
     * @return string
     */
    public function localimg2entity()
    {
        //<img localsrc="334" />
        $regex = '/(<img [^>]*localsrc\s*=\s*["\']?)([^>"\']+)(["\']?[^>]*>)/is';
        $this->_string = preg_replace_callback($regex, array('BEAR_Emoji', '_onConvertLocalSrcEmoji'), $this->_string);
        return $this->_string;
    }

    /**
     * デフォルトイメージタグを指定する
     *
     * イメージタグの先頭部分を指定します。絵文字文字画像のURLの先頭部分です。
     *
     * Example 1. http://www.example.com/jp/mobile/emoji/に絵文字画像が入っている場合
     *
     * <code>
     * //App_Pageクラスなどで指定
     * $img = '<img width="12" height="12" boder="0" src="http://www.example.com/jp/mobile/emoji/';
     * BEAR_Emoji::setDefaultImgTag($img);
     * </code>
     *
     * @param string $imgTag イメージタグ前半HTML
     * 
     * @return void
     */
    public function setDefaultImgTag($imgTag)
    {
        BEAR_Emoji::$imgTag = $imgTag;
    }

    /**
     * 絵文字を除去する
     *
     * @param string $string 文字列
     * 
     * @return string　文字列
     */
    public function removeEmoji($string)
    {
        $log['before'] = $string;
        $ua = BEAR::$ua;
        switch ($ua) {
        // iモード, EZweb
        case BEAR_Agent::UA_DOCOMO :
        case BEAR_Agent::UA_AU :
            $emoji = BEAR_Emoji::getInstance($string, $ua);
            /* @var $emoji BEAR_Emoji */
            $decEntity = $emoji->makeDecEntity();
            $regex = '/&#(\d{5});/is';
            $string = preg_replace($regex, "", $decEntity);
            break;
        // SBモバイル
        case BEAR_Agent::UA_SOFTBANK :
            $regex = '/\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f/is';
            $string = preg_replace($regex, "", $string);
            break;
        default :
            break;
        }
        $log['after'] = $string;
        //BEAR_Log::appLog('removeEmoji', $log);
        return $string;
    }

    /**
     * AU絵文字変換コールバック
     *
     * BEAR_Emoji::localimg2entity()で使用するコールバック関数です。
     *
     * @param array $matches 検索文字列
     * 
     * @return array
     */
    private static function _onConvertLocalSrcEmoji($matches)
    {
        static $localTable;
        if (!isset($localTable)) {
            $mojiAucnvTbl = BEAR_Emoji_Map::ka_au_no2emoji_tbl_make();
        }
        $idx = $matches[2];
        $result = $mojiAucnvTbl[$idx];
        return $result;
    }

    /**
     * 絵文字変換コールバック
     *
     * @param array $matches 検索文字列
     * 
     * @return string
     * @access private
     */
    private static function _onConvertEmoji($matches = false)
    {
        static $convertMap;
        //変換マップ読み込み
        if (!is_array($convertMap)) {
            $convertMap = BEAR_Emoji_Map::getEmojiConvertArray();
        }
        $to = & PEAR::getStaticProperty('BEAR_Emoji', 'to');
        //SB携帯連続絵文字分解
        //
        //最初の文字が1Bで6文字以上の文字列を連続絵文字とする
        //
        if (substr($matches[0], 0, 1) == chr((0x1b)) && (strlen($matches[0]) > 5)) {
            $stirng = $matches[0];
            $sbEmoji = array();
            for ($i = 3; $i < strlen($stirng) - 1; $i++) {
                $sbEmoji[] = $stirng[$i];
            }
            $emojis = array();
            $j = 0;
            foreach ($sbEmoji as $emoji) {
                $webcodeDecimalHigh = ord($stirng[2]);
                $webcodeDecimalLow = ord($emoji);
                //1B24 (ESC開き)
                $emojis[$j] = pack("C*", 0x1b);
                $emojis[$j] .= pack("C*", 0x24);
                $emojis[$j] .= pack("C*", $webcodeDecimalHigh);
                $emojis[$j] .= pack("C*", $webcodeDecimalLow);
                //0F (ESC閉じ)
                $emojis[$j] .= pack("C*", 0x0f);
                $j++;
            }
            //コードの数値配列を文字に
            $result = $emoji = "";
            foreach ($emojis as $emoji) {
                $converted = $convertMap[$emoji][$to];
                $noEmoji = App::$debug ? "＊NOEMOJI*" : "";
                $result .= ($converted) ? $converted : $noEmoji;
            }
            return $result;
        }
        $emoji = $matches[0];
        $converted = $convertMap[$emoji][$to];
        // docomo推奨バイナリ絵文字
        if (($to == BEAR_Agent::UA_DOCOMO || $to == BEAR_Agent::UA_AU) && preg_match('/&#(\d{5});/', $converted)) {
            $decCode = (int)preg_replace('/&#(\d{5});/', '$1', $converted);
            $len = strlen($decCode);
            if ($len > 5) {
                $result = '';
                for ($i = 0; $i < $len / 5; $i++) {
                    $result .= pack('n', substr($decCode, $i * 5, 5));
                }
            } else {
                $result = pack('n', $decCode);
            }
        } else {
            //            $encode =& PEAR::getStaticProperty('BEAR_Emoji', 'encode');
            $encode = mb_detect_encoding($converted);
            $converted = mb_convert_kana($converted, 'ak', $encode);
            $converted = str_replace(' ', '', $converted);
            $noEmoji = App::$debug ? "＊NOEMOJI*" : "";
            $result = ($converted) ? $converted : $noEmoji;
        }
        return $result;
    }

    /**
     * エスケープされた文字列の解除
     *
     * <pre>QuciFormバリデーションNGの場合valuesに入った
     * 文字列がエスケープされます。
     * 
     * SBの絵文字では"（ダブルクオーテーション）などを使用したものがあり、
     * 誤動作してしまいます。
     * この関数をsamrtyのoutputfilterで使用して誤表示を防ぎます。
     *　HTMLとしては誤った表記になるのでPCでの表示はうまくできませんが
     * SB端末では正しく表示されます</pre>
     *
     * @param string $html HTML
     * 
     * @return string
     * @static
     *
     */
    public static function unescapesbEmoji($html)
    {
        $regex = '/\x1b\x24(.*?)\x0f/is';
        $result = preg_replace_callback($regex, array('BEAR_Emoji', '_onSbEmoji'), $html);
        return $result;
    }

    /**
     * unescapesbEmoji用コールバック関数
     *
     * @param array $match 検索文字列
     * 
     * @return string
     * @access private
     */
    private static function _onSbEmoji($match)
    {
        $emoji = $match[1];
        $result = pack('c*', 0x1b, 0x24) . html_entity_decode($emoji) . pack('c*', 0x0f);
        return $result;
    }

    /**
     * 絵文字を全て除去する
     *
     * QuickFormのフィルターなどに使います。
     *
     * @param string $string 文字列
     * 
     * @return string
     */
    public static function removeEmojiEntity($string)
    {
        // iモード絵文字消去
        // EZ絵文字消去
        // SB絵文字消去
        $regex = '/(&#(\d{5});)|(\x1b\x24[GEFOPQ][\x21-\x7a]*\x0f)/is';
        $string = preg_replace($regex, "", $string);
    }

    /**
     * SB3GC端末UTF絵文字をWebコード絵文字に変換（コールバック用関数）
     *
     * <pre>
     * コールバック用SB 3GCWebコード変換関数
     * _BEAR_CONVERT_EMOJI_3GC_WEB_ENCODEがオンのときBEAR_Pageで$_POSTに対して使用しています
     * </pre>
     *
     * @param string $string 文字列
     * 
     * @return string
     */
    public static function onWebEncode($string)
    {
        $log['before'] = $string;
        $string = BEAR_Emoji::encodeWebCode($string);
        $log['after'] = $string;
        BEAR_Log::appLog('WebCode', $log);
        return $string . "@";
    }

    /**
     * 絵文字をエンティティに変換
     * 
     * コールバック用関数です。
     *
     * @param string $string 文字列
     * 
     * @return void
     */
    public static function onEntityEmoji(&$string)
    {
        $log['before'] = $string;
        $emoji = BEAR_Emoji::getInstance($string, BEAR::$ua);
        $string = $emoji->makeDecEntity();
        //    if (BEAR::$ua == BEAR_Agent::UA_AU){
        //        $string = $emoji->makeHexEntity();
        //    }
        $log['after'] = $string;
        BEAR_Log::appLog('Entity Emoji', $log);
    }
}
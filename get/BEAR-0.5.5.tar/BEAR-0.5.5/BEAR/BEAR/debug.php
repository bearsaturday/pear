<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @link      http://api.bear-project.net/BEAR/BEAR.html
 */

/**
 * print_a関数読み込み
 */
include_once 'BEAR/inc/debuglib.php';

/**
 * Fire PHP読み込み
 */
include_once 'FirePHPCore/fb.php';

/**
 * debug用ユーティリティ読み込み
 */
include_once 'BEAR/BEAR/Util.php';

/**
 * デバック用プリント
 *
 * デバック用に変数を表示します。<var>$ouputMode</var>を変えて
 * 様々なフォーマットで変数表示可能です。
 *
 * Example. print_a(http://www.atomar.de/debuglib/)方式
 *
 * <code>
 * p($values)　//件数が多いときはメモリ消費をふせぐために自動的に'v'になります。
 * </code>
 *
 * Example. 通常ではメモリエラーが出るときなどにVar_Dump方式
 *
 * <code>
 * p($values, 'var') // or 'v'
 * </code>
 *
 * Example. アプリケーションログ画面表示（画面をくずしません）
 *
 * <code>
 * p($values, 'app') // or 'a'
 * </code>
 *
 * Example. ヘッダーに出力
 *
 * <code>
 * p($values, 'header') // or 'h'
 * </code>
 *
 * Example. syslog方式
 *
 * <code>
 * p($values, 'syslog') // or 's'
 * </code>
 *
 * @param mixed  $values    変数
 * @param string $ouputMode 出力形式
 * @param array  $options   オプション
 *
 * @return void
 * @see http://www.atomar.de/debuglib/
 */
function p($values = '', $ouputMode = '')
{
    BEAR_Debug::p($values, $ouputMode, array('trace'=>debug_backtrace()));
}

/**
 * リバーシエンジニアリング表示
 *
 * 関数とクラスをリバースエンジリアリングした内容を表示し
 * 内容概略が画面表示されます。
 * オブジェクトを指定するとクラスに直して表示します。
 *
 * <code>
 * r('BEAR_Form');  //クラス
 * r($obj);　//オブジェクト
 * r('p');
 * </code>
 *
 * @param string $target 対象クラス(オブジェクト)
 * @param boll   $parent 親クラスも調べる
 *
 * @return void
 */
function r($target, $parent = false)
{
    BEAR_Debug::reflect($target, $parent);
}

/**
 * Debugクラス
 *
 * <pre>
 * 開発モードで使用するユーティリティ
 * </pre>
 *
 */
class BEAR_Debug
{

    /**
     * printa形式
     */

    const OUTPUT_PRINTA = 'printa';

    /**
     * print_r形式
     */

    const OUTPUT_VAR = 'v';

    /**
     * var_export形式
     */

    const OUTPUT_EXPORT = 'e';

    /**
     * beardevログ出力
     */

    const OUTPUT_APPLOG = 'applog';

    /**
     * syslog出力
     */
    const OUTPUT_SYSLOG = 'syslog';

    /**
     * firephp出力
     */
    const OUTPUT_FIRE = 'fire';

    public static $defaultPrintMode = null;

    public static function p($values = '', $ouputMode = null, array $options = array())
    {
        // VOならarrayに
        if ($values instanceof BEAR_Vo) {
            $values = array('code' => $values->getCode(), 'header' => $values->getHeaders(), 'body' => $values->getBody());
        }
        $trace = isset($options['trace']) ? $options['trace'] : debug_backtrace();
        $file = $trace[0]['file'];
        $includePath = explode(":", get_include_path());
        // include_pathがあれば除去
        foreach($includePath as $var) {
            if ($var != '.') {
                $file = str_replace($var, '', $file);
            }
        }
        $file = BEAR_Util::removeKnownPath($file);
        $method = (isset($trace[1]['class'])) ? " ({$trace[1]['class']}" . '->' . "{$trace[1]['function']})" : '';
        $label = isset($options['label']) ? $options['label'] : "in {$file} on line {$trace[0]['line']}$method";
        $len = (strlen(serialize($values)));
        if ($len > 20000) {
            $ouputMode = 'e';
            $label .= "  $len";
        }
        $label = (is_object($values)) ? get_class($values) . " $label" : $label;
        // ajaxならfirePHPに
        if (BEAR_Page::isAjaxRequest()) {
            if (class_exists('Fire', false)) {
                $ouputMode = 'fire';
            } else {
                $ouputMode = 'applog';
            }
        } elseif (php_sapi_name() == 'cli' || BEAR_Agent::isBearAgent()) {
            echo 'p() ' . $label . PHP_EOL;
            var_export($values);
            echo PHP_EOL . PHP_EOL;
            return;
        }
        $labelField = '<fieldset style="color:#4F5155; border:1px solid black;padding:2px;width:10px;">';
        $labelField .= '<legend style="color:black;font-size:9pt;font-weight:bold;font-family:Verdana,';
        $labelField .= 'Arial,,SunSans-Regular,sans-serif;">' . $label . '</legend>';
        switch ($ouputMode) {
            case 'v' :
            case 'var' :
                include_once 'Var_Dump.php'; // auloader doesn't work
                Var_Dump::displayInit(array('display_mode' => 'HTML4_Text'));
                print $labelField;
                Var_Dump::display($values);
                print "</fieldset>";
                break;
            case 'e' :
            case 'export' :
                echo "$labelField<pre>" . var_export($values, true);
                echo '</fieldset></pre>';
                break;
            case 'a' :
            case 'applog' :
                BEAR_Log::appLog('p()', array('location' => $label, 'values' => $values));
                break;
            case 'h' :
            case 'header' :
                header("x-bear-debug-$label", print_r($values, true));
                break;
            case 's' :
            case 'syslog' :
                syslog("label:$label" . print_r($values, true));
                break;
            case 'f' :
            case 'fire' :
                if (class_exists('FirePHP', false)) {
                    $firephp = FirePHP::getInstance(true);
                    $level = isset($options['level']) ? $options['level'] : '';
                    $label = isset($options['label']) ? $options['label'] : 'p';
                    fb($values);
                }
                break;
            case '' :
            case 'printa' :
            default :
                // array emppty
                if (is_array($values) && count($values) == 0) {
                    $values = array('(array)' => 'empty');
                }
                // boolean false
                if (is_bool($values) && $values === false) {
                    $values = array('(boolean)' => 'false');
                }
                if (is_object($values)) {
                    $label = get_class($values) . " $label";
                }
                $options = "show_objects:0; max_y:50;pickle:1;label:{$label}";
                //print $label;
                print_a($values, $options);
        }
    }

    /**
     * リバーシエンジニアリング表示
     *
     * 関数とクラスをリバースエンジリアリングした内容を表示し
     * 内容概略が画面表示されます。
     * オブジェクトを指定するとクラスに直して表示します。
     *
     * <code>
     * BEAR_Debug::reflect('BEAR_Form');  //クラス
     * BEAR_Debug::reflect($obj);　//オブジェクト
     * BEAR_Debug::reflect('p');
     * </code>
     *
     * @param string $target 対象クラス(オブジェクト)
     * @param boll   $parent 親クラスも調べる
     *
     * @return void
     */
    function reflect($target, $parent = false)
    {
        if (is_object($target)) {
            $target = get_class($target);
        }
        switch (true) {
            case function_exists($target) :
                // ReflectionFunction クラスのインスタンスを生成する
                $ref = new ReflectionFunction($target);
                // 基本情報を表示する
                $info['name'] = $ref->isInternal() ? 'The internal ' : 'The user-defined ';
                $info['name'] .= $targetName = $ref->getName();
                $info['declare in'] = $ref->getFileName() . ' lines ' . $ref->getStartLine() . ' to ' . $ref->getEndline();
                $info['Documentation'] = $ref->getDocComment();
                if ($statics = $ref->getStaticVariables()) {
                    $info['Static variables'] = $statics;
                }
                //            $info['export'] = ReflectionFunction::export($target);
                $type = 'function';
                break;
            case class_exists($target, false) :
                $ref = new ReflectionClass($target);
                $type = 'class';
                // 基本情報を表示する
                $info['name'] = $ref->isInternal() ? 'The internal ' : 'The user-defined ';
                $info['name'] .= $ref->isAbstract() ? ' abstract ' : '';
                $info['name'] .= $ref->isFinal() ? ' final ' : '';
                $info['name'] .= $ref->isInterface() ? 'interface ' : 'class ';
                $info['name'] .= $targetName = $ref->getName();
                $info['declare in'] = $ref->getFileName() . ' lines ' . $ref->getStartLine() . ' to ' . $ref->getEndline();
                $info['modifiers'] = Reflection::getModifierNames($ref->getModifiers());
                // ドキュメントコメントを表示する
                $info['Documentation'] = $ref->getDocComment();
                $info['Implements'] = $ref->getInterfaces();
                $info['Constants'] = $ref->getConstants();
                foreach($ref->getProperties() as $prop) {
                    // ReflectionProperty クラスのインスタンスを生成する
                    $propRef = new ReflectionProperty($targetName, $prop->name);
                    if ($propRef->isPublic()) {
                        $porps[] = $prop->name;
                    }
                }
                $info['Public Properties'] = $porps;
                foreach($ref->getMethods() as $method) {
                    $methodRef = new ReflectionMethod($targetName, $method->name);

                    if ($methodRef->isPublic() || $method->isStatic()) {
                        $final = $method->isFinal() ? 'final ' : '';
                        $pubic = $method->isPublic() ? 'public ' : '';
                        $static = $method->isStatic() ? ' static ' : '';
                        $methods[] = sprintf("%s%s%s %s", $final, $pubic, $static, $method->name);
                    }
                }
                $info['Public Methods'] = $methods;
                // このクラスがインスタンス化可能な場合、インスタンスを生成する
                if ($ref->isInstantiable()) {
                    $info['isInstance ?'] = $ref->isInstance($target) ? 'yes' : 'no';
                }
                if ($parent) {
                    $info['parent'] .= $ref->getParentClass();
                }
                break;

            default :
                ;
                break;
        }
        print_a($info, "show_objects:1;label: Reflection of {$type} '{$targetName}'");
    }

    /**
     * バックトレース表示
     *
     * <code>
     * BEAR_Debug::trace(); //トレースを表示します
     * BEAR_Debug::trace($a == 1); // $aが1の時のみトレース表示します。
     * </code>
     *
     * @param integer $level 省略時はすべて
     *
     * @return void
     */
    public static function trace($condition = true)
    {
        $trace = debug_backtrace();
        if ($condition !== true) {
            BEAR_Log::appLog('Skip Trace', $trace[1]);
            return;
        }
        $label = 'Backtrace in ' . BEAR_Util::removeKnownPath($trace[0]['file']);
        if (isset($trace[0]['line'])) {
            $label .= " on Line {$trace[0]['line']}";
        }
        foreach($trace as &$row) {
            $row['file'] = BEAR_Util::removeKnownPath($row['file']);
            $location = "{$row['file']} on Line {$row['line']}";
            if (isset($row['class'])) {
                $row["{$row['class']}{$row['type']}{$row['function']}"] = array('args' => $row['args'], 'file' => $location);
                //       p($row['object']);
                unset($row['class']);
                unset($row['type']);
                unset($row['function']);
                unset($row['file']);
                unset($row['line']);
                unset($row['args']);
                unset($row['object']);
            }
        }
        unset($trace[0]);
        p($trace, 'printa', array('label' => $label));
    }
}

/**
 * パーミッションチェック
 */
if (PHP_SAPI !== 'cli') {
    $isBearInfo = isset($_GET['_bearinfo']);
    $isNotWritable = !is_writable(_BEAR_APP_HOME . '/log') || !is_writable(_BEAR_APP_HOME . '/tmp/smarty_templates_c');
    $isBearDevExists = file_exists(_BEAR_APP_HOME . '/htdocs/beardev');
    if (isset($_GET['_bearinfo']) || !$isBearDevExists || !$isBearDevExists) {
        $message1 = 'BEAR Ver. ' . BEAR::VERSION;
        $message2 = '<code>BEAR: ' . _BEAR_BEAR_HOME . '<br />';
        $message2 .= 'App : ' . _BEAR_APP_HOME . '<br />';
        BEAR_Error::showDebug($message1, $message2);
    }

    $message2 = '';
    if (!$isNotWritable){
        $message2 .= '<div><code>sudo chmod -R 777 ' . _BEAR_APP_HOME . '/logs;<br />';
        $message2 .= 'sudo chmod -R 777 ' . _BEAR_APP_HOME . '/tmp;<br />';
    }
    if (!$isBearDevExists) {
        $message2 .= 'sudo ln -s  ' . _BEAR_BEAR_HOME . '/data/htdocs/beardev ' . _BEAR_APP_HOME . '/htdocs;<br />';
        $message2 .= 'sudo mv ' . _BEAR_BEAR_HOME . '/data/htdocs/beardev/htaccess.txt ' ._BEAR_BEAR_HOME . '/data/htdocs/beardev/.htaccess;</code></div>';
    }
    if ($message2) {
        $message1 = '現在開発環境で動作しています。このコードをシェルで実行して環境の';
        $message1 .= 'セットアップを完了させてください。';
        BEAR_Error::showDebug('セットアップを完了させてください', $message1, $message2);
    }

    if (isset($_GET['_error'])) {
        error_reporting(E_ALL | E_STRICT);
        ini_set('display_errors', 1);
        return;
    }
}
<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Base.php 420 2009-01-06 11:16:02Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR_Aspect/BEAR_Aspect.html
 */

/**
 * BEARクラスの抽象クラス
 *
 * <pre>
 * BEARで使われるクラスの基底クラスです。
 * コンストラクタによるconfigの読み取りAbstract base class for all Solar objects.
 *
 * @category  BEAR
 * @package   BEAR
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @version   SVN: Release: $Id: Base.php 420 2009-01-06 11:16:02Z koriyama@users.sourceforge.jp $
 * @link      http://api.bear-project.net/BEAR/BEAR.html
 * @abstract
 */
abstract class BEAR_Base
{

    /**
     * コンフィグの値
     *
     * @var array
     *
     */
    protected $_config = array();

    /**
     * コンストラクタ.
     *
     * $configが配列なら$_configプロパティとマージされます。
     * 文字列ならそれをファイルパスとして読み込み初期値とします。
     *
     * @param mixed $config ユーザー設定値
     *
     * @return void
     *
     */
    function __construct($config = array())
    {
        if (is_string($config)) {
            $config = BEAR::loadValues($config);
        }
        $this->_config = array_merge($this->_config, (array) $config);
    }

    /**
     * コンフィグセット
     *
     * @param array $config 設定
     *
     * @return void
     */
    public function setConfig(array $config)
    {
        $this->_config = array_merge($this->_config, $config);
        return $this->_config;
    }

}

<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Session
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * セッションクラス
 *
 * <pre>セッションを取り扱います。設定は.htaccess、またはphp.iniでも行う必要があります。
 *クラスターシステムのためのDBセッション機能があります。セッションエンジンにDBかmemchacheを選ぶことができます</pre>
 *
 * @category    BEAR
 * @package     BEAR_Session
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Session.php 406 2008-07-02 06:41:10Z koriyama $
 */
class BEAR_Session extends HTTP_Session2
{

    const SESSION_KEY = '_s';

    /**
     * セッション不使用
     */
    const ENGINE_NONE = -1;

    /**
     * ファイルセッション（クラスター不可）
     */
    const ENGINE_FILE = 0;

    /**
     * DBセッション
     */
    const ENGINE_DB = 1;

    /**
     * memchacheセッション
     */
    const ENGINE_MEMCACHE = 2;

    /**
     * セッションスタート
     *
     * @param void
     * @param void
     */
    function start()
    {
        if (App::SESSION_ENGINE == self::ENGINE_NONE) {
            return;
        }
        static $session_started = false;
        if (!$session_started) {
            self::init();
            HTTP_Session2::start(self::SESSION_KEY);
            // 有効期限
            HTTP_Session2::setExpire(time() + App::$sessionOptions['expire']);
            // アイドル時間
            HTTP_Session2::setIdle(time() + App::$sessionOptions['idle']);
            // セッションスタート
            session_start();
            BEAR_Log::appLog('Session Start', array('module' => session_module_name(), 'id' => session_id()));
        }
    }

    /**
     * セッションクラス初期化
     *
     * セッションエンジンを指定し初期化します。
     *
     * @param void
     * @return void
     * @static
     * @ignore
     *
     */
    public static function init()
    {
        //セッションハンドラ初期化
        switch (App::SESSION_ENGINE) {
            case self::ENGINE_MEMCACHE :
                ini_set("session.save_handler", "memcache");
                ini_set("session.save_path", _BEAR_SESSION_PATH);
                break;
            case self::ENGINE_DB :
                self::_initSessionDb();
                break;
            case self::ENGINE_FILE :
                // ファイルセッションに関するPHPのバグ対応
                // @link http://bugs.php.net/bug.php?id=25876
                ini_set('session.save_handler', 'files');
                break;
            case self::ENGINE_NONE :
                break;
            default :
                PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, 0, 'error', array('engine' => App::SESSION_ENGINE), 'Invalid Session Engine.');
        }
    }

    private function _initSessionDb()
    {
        HTTP_Session2::useTransSID(false);
        HTTP_Session2::useCookies(true);
        // DSN を指定します
        HTTP_Session2::setContainer('MDB2', array('dsn' => App::$sessionPath, 'table' => 'sessiondata', 'autooptimize' => true));
    }

    /**
     * セッション変数取得
     *
     * <pre>セッション変数を取得します。変数の無い場合に$defaultを指定することができます</pre>
     *
     * @param    string  $name   セッション変数名
     * @return   mixed   セッション変数値
     * @static
     */
    public static function &get($name, $default = null)
    {
        $value = parent::get($name, $default);
        BEAR_Log::appLog('Session[R]', array('name' => $name, 'val' => $value));
        return $value;
    }
}
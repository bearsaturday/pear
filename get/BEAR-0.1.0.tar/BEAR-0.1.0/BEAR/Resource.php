<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Resource
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEAR_Resourceクラス
 *
 * <pre>
 * リソース操作を取り扱うクラスです。リソースの作成、取得、編集、削除などを行うモジュールとのインターフェイスを持ちます。
 *
 * BEAR_Resourceは内部リソース（DB、ファイル）と外部リソース（RSS, API通信、デーモン等)をスクリプトから区別せずに使用でき、
 * ステートレスで統一されたインターフェイスを持ちます。リソースはURIと同様のリソーソパス形式で表す事ができ他のリソーソパスのリンクを持つ事もできます。
 *
 * 操作の動作をオプションで指定します。ページング処理、コールバック関数によるポストプロセス、作成時の二重動作禁止のためのトークン処理などの機能があります。
 *
 * 使用するキャッシュエンジンを選択できます。デフォルトはPEAR::Cache_Lite使用のファイルキャッシュですがmemcacheも選択できます。
 * app.define.phpのApp::CACHE_ENGINEを'memcache'に指定するとPECL::memcache使用のキャッシュサーバーが使用できます。
 * どちらのエンジンでもBEAR_Resourceクラスにアクセスするコードは変わりません。運用環境に応じてキャッシュエンジンを選択できます。
 *
 * リソースファイル（リソースをアクセスするファイル）は単純関数とクラス形式の２つがあります。
 *　どちらも/PROJECT_ROOT/App/resource以下にフォルダの階層も持って配置されます。
 *
 * Example 1. ユーザーのブログリソース取得
 *
 * リソース名
 * /user/blog
 *
 * 関数型リソースファイル
 * App/resource/user/createBlog.php
 * App/resource/user/readBlog.php
 * ...
 *　
 * クラス型リソースファイル
 * App/resource/user/blog.php
 *
 * <code>
 * // 関数型
 * function readBlog($values)
 * {
 *   $db = App_DB::getInstance(App::$dbSlave);
 *   $db->quote($values['id'], 'integer);
 *   $sql  = "SELECT * FROM blog WHERE id={$values{'id'} ORDER BY id DESC LIMIT 5";
 *   $result = $db->queryAll($sql);
 *   return $result;
 * }
 * </code>
 *
 * <code>
 * //クラス型
 * class Blog extends BEAR_Content
 * {
 *   public function create($values){}
 *   public function read($values){
 *     // ...
 *     $result = $db->queryAll($sql);
 *     return $result;
 *   }
 *   public function update($values){}
 *   public function delete($values){}
 * }
 * </code>
 *
 * <pre>
 * エラーを返す場合
 *
 * 関数型の場合はPEARエラーを作成して返します。その場合キャッシュが作成されません。
 * ※PEARエラーを返さないとエラー状態がキャッシュされてしまいます。
 *
 * Example. 取得したデータが配列でなければエラーで返す</pre>
 * <code>
 * function readBlog($values){
 *   //エラー
 *   $result = (is_array($result)) ? $result : PEAR::raiseError('error message');
 *   return $result;
 * }
 * </code>
 *
 * <pre>
 * ページからのリソース読み出し
 * /usr/blog.php
 * </pre>
 *
 * <code>
 * $resoure = new BEAR_Resource('/usr/blog');
 * $values['key'] = 'hoge_id';
 * $blog = $resoruce->get($values);
 * </code>
 *
 * <pre>
 * Example. キャッシュの使用<br>
 *
 * 高速化のため、キャッシュが利用できます
 * </pre>
 * <code>
 * $options['cache']['key'] = 'cacheid_foo'; //省略できます
 * $options['cache']['expire'] = 30;
 * $blog = $resoruce->get($values, $options);
 * </code>
 *
 * <pre>
 * Example. 二重実行防止<br>
 *
 * <code>
 * //二重送信されたものを一度しか実行しない
 * $resoure = new BEAR_Resource('/usr/blog');
 * $options['token'] = true;
 * $resource->create($values, $options);
 * </code>
 *
 * <pre>
 * リソース設計指針
 *
 * アドレス可能性(URIで指定できる）
 * ステートレス性(リソースファイルに状態を保持しない）
 * 接続性（他リソースへのリンクを持つ）
 * 統一インターフェース（なるべくクラス型で）
 * </pre>
 *
 * サポートURI
 * -内部BEARリソース
 *
 * @category    BEAR
 * @package     BEAR_Resource
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Resource.php 419 2008-07-02 12:23:22Z koriyama $
 * @todo        サポート予定URI拡張子 rdf,xml,txt,xhtml,csv,php (外部BEAR)
 */
class BEAR_Resource
{

    /**
     * Resource OK
     */
    const RESULT_CODE_200_OK = '200';

    /**
     * Bad Request
     */
    const RESULT_CODE_400_BAD_REQUEST = '400';

    /**
     * Resource Forbidden
     */
    const RESULT_CODE_403_FORBIDDEN = '403';

    /**
     * Resource Not Found
     */
    const RESULT_CODE_404_NOT_FOUND = '404';

    /**
     * Internal Resource Error
     */
    const RESULT_CODE_500_ERROR = '500';

    /**
     * リソースメソッド - create(POST, INSERT)
     */
    const METHOD_CREATE = 'create';

    /**
     * リソースメソッド - read(GET, SELECT)
     */
    const METHOD_READ = 'read';

    /**
     * リソースメソッド - update(PUT, UPDATE)
     */
    const METHOD_UPDATE = 'update';

    /**
     * リソースメソッド - delete(DELETE, DELETE)
     */
    const METHOD_DELETE = 'delete';

    /**
     * リソースファイルタイプ ファイルなし
     */
    const FILE_ERROR = -1;

    /**
     * リソースファイルタイプ 関数
     */
    const FILE_FUNC = 0;

    /**
     * リソースファイルタイプ CRUDアクセス
     */
    const FILE_CRUD = 1;

    /**
     * URI(リソースパス)
     *
     * @var string
     */
    private $_uri;

    /**
     * 引数
     *
     * @var array
     */
    private $_values = array();

    /**
     * オプション
     *
     * @var array
     */
    private $_options = array();

    /**
     * アクセスメソッド
     *
     * @var string
     */
    private $_method = self::METHOD_READ;

    /**
     * 結果
     *
     * @var mixed
     */
    private $_result;

    /**
     * 結果ヘッダー
     *
     * @var array
     */
    private $_headers;

    /**
     * 結果リンク
     *
     * @var array
     */
    private $_links;

    /**
     * 結果コード
     *
     * @var string
     */
    private $_resultCode;

    /**
     * ファイルタイプ
     *
     * @var int
     */
    private $_fileType;

    /**
     * バリューオブジェクト
     *
     * @var mixed
     */
    private $_vo = null;

    /**
     * トークン
     *
     * @var string
     * @access private
     */
    private $_token;

    /**
     * 結果はVOか配列か
     *
     * @var bool true if vo
     */
    private $_isVo = false;

    /**
     * シングルトンインスタンス
     */
    private static $_instance;

    /**
     * シングルトン
     *
     * @param void
     * @return BEAR_Resource
     */
    public static function getInstance($uri)
    {
        if (!self::$_instance[$url]) {
            self::$_instance[$url] = new self($uri);
        }
        return self::$_instance;
    }

    /**
     * コンストラクタ
     *
     * @param string $uri
     */
    function __construct($uri)
    {
        $this->_uri = $uri;
    }

    /**
     * ページャー情報の取得
     *
     * <pre>ページャーで生成されたナビゲーションHTMLを取得します。
     * DBページャーの場合はページャー情報も取得されます
     * ['links']にナビゲーションリンクが
     * ['info']のページャー情報がはいります
     *
     * DBページャーの場合は結果がバリューオブジェクトになっているので、リンクとメタ情報からページャー情報を生成しています</pre>
     *
     * @return  array
     */
    public function getPager()
    {
        if ($this->_isVo) {
            $result = array();
            $result = array('links' => $this->_links, 'info' => $this->_headers);
        } else {
            $result = $this->_pager;
        }
        return $result;
    }

    /**
     * AJAX用ページャーリンクを取得
     *
     * <pre>paging()等で作成されたページャーのリンクをbear.jsを使った
     * AJAXのページャーリンクにします。
     *
     * Example 1.
     * </pre>
     * <code>
     * $app = new BEAR_Resource();
     * $app->make('example', $values);
     * $app->paging(5)
     * $view = $app->getPagerResult();
     * $links = $app->getAjaxPagerLinks();
     * </code>
     *
     * @param void
     * @return string
     */
    function getAjaxPagerLinks($link)
    {
        $array = array();
        foreach($links as $key => $value) {
            $value = preg_replace('/<a\s/is', '<a rel="bear" ', $value);
            $array[$key] = $value;
        }
        return $array;
    }

    /**
     * 結果の取得
     *
     * @param   void
     * @return  mixed
     * @access  public
     */
    function getResult()
    {
        return $this->_result;
    }

    /**
     * リソース実行
     *
     * <pre>外部リソース（DB、ファイル等）に対しての更新操作を行います。
     * リソース名に対応するリソースファイルが/action/から読み込まれ、<var>$values</var>で受け取った値を渡します。
     * 帰り値を持つリソース関数の場合getResult()メソッドでその値を取得できます。
     *
     * useExternalServerメソッドを使用すると外部のサーバーのリソースをhttp通信で実行することもできます。
     *
     *     /**
     * ビュー取得
     *
     * <pre>
     * DB、ファイルなどの外部リソースからデータを取得します。ビューファイルを
     * App/viewフォルダに用意したものが使われます。引数から外部リソースを操作した値を
     * 連想配列で返します。
     *
     * 外部サーバーのビューの取得:
     * setExternalServer(<var>$url</var>)メソッドをactionメソッドの前に実行することによって
     * リモートプロシージャとして外部サーバーのビューが取得できます。
     *
     * キャッシュオプションを指定することでキャッシュが使用できます。キーは自動で
     * 生成されるのでキャッシュ時間を指定するだけの透過的な使用ができます。リモートの場合
     * もキャッシュは有効です。
     *
     * ビューの作成に失敗した場合はPEARのエラーを返すと、キャッシュが生成されずに次回のアクセスが
     * 正常なものになります。
     *
     * アプリケーションサーバーのwebインターフェイスはBEAR_Classを使って作成します。
     *
     * </pre>
     *
     * <var>$cache_options</var>
     * <ul>
     * <li>
     * <var>expire</var> <kbd>int</kbd> = <samp>30</samp>
     *      <br />キャッシュ生成時間
     * </li><li>
     * <var>cache_id</var> <kbd>string</kbd> = <samp>top_oshirase</samp>
     *      <br />キャッシュID(省略化）
     *      <br />省略した場合はビュー名とシリアライズした引数を合成した文字列を適用
     * </li>
     * </ul>
     * <pre>
     * Example 1.ビュー取得
     * </pre>
     * <code>
     * $values['key'] = 'hoge_id';
     * $topic = BEAR_Resource::make('hogeDiaryTodayTopic', $values);
     * </code>
     *
     * <pre>
     * Example 2　600秒有効のキャッシュ
     * </pre>
     * <code>
     * $values['key'] = 'hoge_id';
     * $options['cache']['key'] = hoge';            //省略化
     * $options['cache']['expire'] = 600;
     * $topic = BEAR_Resource::make('hogeDiaryTodayTopic', $values, $options);
     * </code>
     *
     * <pre>
     * Example 3　外部サーバーのビュー取得(キャッシュ使用)
     * </pre>
     * <code>
     * $app = new BEAR_Resource();
     * //外部サーバーインターフェイス
     * $app->useExternalServer('http://example.com/webif/index.php');
     * $options['cache']['key'] = hoge';   //外部サーバーでもキャッシュは利用可能
     * $options['cache']['expire'] = 600;
     * $view = $app->make('test', $values, $options);
     * </code>
     *
     * <pre>
     * Example 4　ページャービューの取得(一旦結果を全て収得して分割）
     * </pre>
     * <code>
     * $app = new BEAR_Resource();
     * $app->make('normalView', $values);
     * $app->paging(5)
     * $view = $app->getPagerResult();
     * $links = $app->getPagerLinks();
     * </code>
     *
     * <pre>
     * Example 5　ページャービューの取得(DBページャー使用）
     * </pre>
     * <code>
     * $res = new BEAR_Resource();
     * $res->make('entries', $values);
     * $entries = $app->getResult();
     * $links = $app->getPager();
     * </code>
     *
     * リソース名 hoge1の場合
     *
     * リソースファイル名：
     * </pre>
     * <samp>
     * /action/app.action.hoge1.php
     * </samp>
     *
     * リソース関数：
     * <code>
     * function hoge1($values){
     * }
     * </code>
     *
     * @param   string  $uri リソース名
     * @param   string  $values 引数
     * @param   mixed   $options    オプション
     *  - cache:
     *  -- id: string キャッシュID
     *  -- expire: string キャッシュ時間（秒）
     *  - callback: string コールバック関数名
     *  - token: bool トークン処理
     * @return  mixed
     * @access  public
     */
    private function _use($values, $options)
    {
        $this->_values = $values;
        $this->_options = $options;
        // トークン
        if ($this->_poe() === false) {
            return false;
        }
        $isRead = ($this->_method == self::METHOD_READ);
        // キャッシュ
        $isCacheResource = (App::$useCache && $isRead && (isset($this->_options['cache']['expire']))) ? true : false;
        // リソースアクセス
        $this->_result = $isCacheResource ? BEAR_Resource::_cachedResource() : BEAR_Resource::_doResource();
        // VO(バリューオブジェクト）
        if (get_class($this->_result) == 'BEAR_Vo') {
            $this->_isVo = true;
            /* @var $vo BEAR_Vo */
            $vo = $this->_result;
            $this->_result = $vo->getBody();
            $this->_links = $vo->getLinks();
            $this->_headers = $vo->getHeaders();
        }
        return $this->_result;
    }

    /**
     * POE(Post Once Exactly)
     * 
     * <var>$options</var>でpoeが指定されていればワンタイムトークンが有効か調べ
     *
     * @return unknown
     */
    private function _poe()
    {
        $do_double_submit_check = (isset($this->_options['poe']) && $this->_options['poe']) ? true : false;
        //二重投稿防止トークン処理
        if ($do_double_submit_check) {
            $token = isset($_POST['_token']) ? $_POST['_token'] : (isset($_GET['_token']) ? $_GET['_token'] : null);
            //トークン取得
            $token_result = BEAR_Resource::_isTokenValid($token);
            return $token_result;
        } else {
            //トークンなしでリソース実行
            $token = null;
        }
        return $token;
    }

    /**
     * リソース作成
     *
     * @param array $values
     * @param mixed $options
     * @return mixed
     */
    public function create($values, $options = NULL)
    {
        $this->_method = self::METHOD_CREATE;
        BEAR_Log::resourceLog(self::METHOD_CREATE, $this->_uri, $values);
        $result = $this->_use($values, $options);
        return $result;
    }

    /**
     * リソース取得
     *
     * @param array $values
     * @param mixed $options
     * @return mixed
     */
    public function read($values = null, $options = NULL)
    {
        $this->_method = self::METHOD_READ;
        $result = $this->_use($values, $options);
        return $result;
    }

    /**
     * リソース更新
     *
     * @param array $values
     * @param mixed $options
     * @return mixed
     */
    public function update($values, $options = NULL)
    {
        $this->_method = self::METHOD_UPDATE;
        BEAR_Log::resourceLog(self::METHOD_UPDATE, $this->_uri, $values);
        $result = $this->_use($values, $options);
        return $result;
    }

    /**
     * リソース削除
     *
     * @param array $values
     * @param mixed $options
     * @return mixed
     */
    public function delete($values, $options = NULL)
    {
        $this->_method = self::METHOD_DELETE;
        BEAR_Log::resourceLog(self::METHOD_DELETE, $this->_uri, $values);
        $result = $this->_use($values, $options);
        return $result;
    }

    /**
     * リソース後処理
     *
     * <pre>リソース取得の結果に対しての後処理を行います。
     * 後処理にはコールバック関数の適用や、DBページャーの結果取り出しなどがあります。
     * </pre>
     *
     * @param array $result
     * @param array $options
     * @return array
     * @access private
     * @todo templateのアサイン
     */
    function _actionPostProcess($result)
    {
        $options = $this->_options;
        // ページャーリザルト処理
        // 結果
        $is_error_result = PEAR::isError($result);
        if (!$is_error_result) {
            // コールバックオプション 1
            if (isset($options['callback'])) {
                if (is_callable($options['callback'])) {
                    $options['callback']($result);
                } else {
                    PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('callback' => $options['callback']), 'BEAR_Resource callback failed.');
                }
            }
            // コールバックオプション rec
            if (isset($options['callback_r'])) {
                if (is_callable($options['callback_r'])) {
                    array_walk_recursive($result, $options['callback_r']);
                } else {
                    PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('callback' => $options['callback_r']), 'BEAR_Resource callback_r failed.');
                }
            }
        } else {
            //            if (BEAR_Page::isAjaxRequest()) {
        //                // AJAXでのエラー表示
        //                /* @var $result PEAR_Error */
        //                $error_result = array('code' => $result->getCode(), 'userInfo' => $result->getUserInfo(), 'message' => $result->getMessage());
        //                print "AJAX DB Error\n";
        //                print_r($error_result);
        //                exit();
        //            }
        }
        return $result;
    }

    /**
     * キャッシュ機能付きリソース
     *
     * <pre>App::CACHE_ENGINEが'memcache'だとキャッシュエンジンにmemcacheを使用します。
     * デフォルトはPEAR::Cache_Liteです</pre>
     *
     * @param string $uri
     * @param array $values
     * @param array $options
     * @return array
     * @access private
     */
    function _cachedResource($uri, $values, $options)
    {
        $func = (App::$useCache == BEAR_Session::ENGINE_MEMCACHE) ? '_cachedResourceMemCache' : '_cachedResourceCacheLite';
        $result = $this->$func($uri, $values, $options);
        return $result;
    }

    /**
     * キャッシュ機能付きリソース(memcache)
     *
     * <pre>makeもキャッシュされます。
     * action()メソッドからコールされます。
     * </pre>
     *
     * @param string $uri
     * @param array $values
     * @param array $options
     * @return array
     * @access private
     */
    function _cachedResourceMemCache($uri, $values, $options)
    {
        //キャッシュ初期化
        $cahce_expire = isset($options['cache']['expire']) ? $options['cache']['expire'] : $options['expire'];
        if (isset($options['cache']['key'])) {
            $cache_key = $options['cache']['key'];
        } elseif (isset($options['key'])) {
            $cache_key = $options['key'];
        } else {
            $cache_key = $options['cache']['key'] = md5($uri . serialize($values) . serialize($options) . serialize($_GET['page']));
        }
        // キャッシュ
        $bear_cache = BEAR_Cache::getInstance();
        $result = $bear_cache->get($cache_key);
        $log = array("resource name" => $uri, 'Args' => $values, 'options' => $options);
        if ($result) {
            // キャッシュ読み込み
            BEAR_Log::appLog("Resource [R]", $log);
        } else {
            // キャッシュ書き込み
            BEAR_Log::appLog("Resource [W]", $log);
            $result = BEAR_Resource::_doResource();
            if (!PEAR::isError($result)) {
                $bear_cache->set($cache_key, $result, false, $cahce_expire);
            } else {
                // キャッシュ生成エラー
                $bear_error = new BEAR_Error("Resource Cache Error.", BEAR_Error::CODE_WARNING);
                $bear_error->addUserInfo($result->getUserInfo());
            }
        }
        return $result;
    }

    /**
     * キャッシュ機能付きリソース(PEAR::Cache Lite)
     *
     * <pre>makeもキャッシュされます。
     * action()メソッドからコールされます。
     * </pre>
     *
     * @param string $uri
     * @param array $values
     * @param array $options
     * @return array
     * @access private
     */
    function _cachedResourceCacheLite($uri, $values, $options)
    {
        //キャッシュ初期化
        $cahce_expire = isset($options['cache']['expire']) ? $options['cache']['expire'] : $options['expire'];
        if (isset($options['cache']['key'])) {
            $cache_key = $options['cache']['key'];
        } elseif (isset($options['key'])) {
            $cache_key = $options['key'];
        } else {
            $cache_key = $options['cache']['key'] = md5($uri . serialize($values) . serialize($options) . serialize($_GET['page']));
        }
        $pear_error_mode = (App::$debug) ? CACHE_LITE_ERROR_DIE : CACHE_LITE_ERROR_RETURN;
        $params = array('cacheDir' => _BEAR_APP_HOME . '/tmp/App/cache_lite/', 'lifeTime' => $cahce_expire, 'automaticSerialization' => true, 'automaticCleaningFactor' => 100, 'pearErrorMode' => $pear_error_mode);
        $cache = new Cache_Lite($params);
        //キャッシュ取得
        $result = $cache->get($cache_key);
        $log = array("Resource name" => $uri, 'Args' => $values, 'options' => $options);
        if ($result) {
            // キャッシュ読み込み
            BEAR_Log::appLog("Resource[R]", $log);
        } else {
            // キャッシュ書き込み
            BEAR_Log::appLog("Resource[W]", $log);
            $result = BEAR_Resource::_doResource();
            if (!PEAR::isError($result)) {
                $cache->save($result, $cache_key);
            } else {
                // キャッシュ生成エラー
            }
        }
        return $result;
    }

    /**
     * リソース実行
     *
     * actio()メソッドから呼ばれるサブメソッドです。内部実行のインターナルリソースと
     * 外部実行のエクスターナルリソースの切り分けを行っています。
     *
     * @return mixed　                  リソース結果
     * @access private
     */
    private function _doResource()
    {
        $parseUrl = parse_url($this->_uri);
        $pathInfo = pathinfo($this->_uri);
        // XML
        if (isset($pathInfo['extension']) && ($pathInfo['extension'] == 'xml' || $pathInfo['extension'] == 'rdf')) {
            $result = $this->_doXML();
        } else {
            $result = BEAR_Resource::_doInternalBearResource();
        }
        // 外部サーバーリソース
        // $result = BEAR_Resource_Net::doExteralResource($uri, $values, $options, $token);
        //後処理
        $result = BEAR_Resource::_actionPostProcess($result);
        return $result;
    }

    /**
     * 外部XML取得
     *
     * @return unknown
     */
    private function _doXML()
    {
        if ($this->_method != self::METHOD_READ) {
            //エラー
            $this->_resultCode = self::RESULT_CODE_400_BAD_REQUEST;
            return null;
        }
        $rss = & new XML_RSS($this->_uri);
        $rss->parse();
        $result = $rss->getItems();
        return $result;
    }

    /**
     * インターナルリソース実行
     *
     * <pre>自サーバーのリソースを実行します。
     * リソースは個別にApp/actionフォルダーに格納されています。
     * </pre>
     *
     * @param string    $uri    リソース名
     * @param array     $values         リソース変数
     * @param array     $options         オプション(deporecated)
     * @param string    $token          二重送信防止トークン
     * @param bool      $log            画面ログ(キャッシュのときはfalse)
     * @return mixed　                  リソース結果
     * @access private
     */
    private function _doInternalBearResource()
    {
        $pathInfo = pathinfo($this->_uri);
        // リソース関数名
        $resourceName = $pathInfo['filename'];
        // リソースファイル読み込み
        $resourceFile = _BEAR_APP_HOME . '/App/resources/' . $this->_uri . '.php';
        if (!file_exists($resourceFile)) {
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('resource' => $this->_uri, 'file' => $resourceFile), 'Not found resource.（リソースファイルがありません)');
        }
        include_once $resourceFile;
        // リソースファイルタイプ
        if (function_exists($resourceName)) {
            $this->_fileType = self::FILE_FUNC;
        } elseif (class_exists($resourceName, false)) {
            $this->_fileType = self::FILE_CRUD;
        } else {
            $this->_fileType = self::FILE_ERROR;
        }
        switch ($this->_fileType) {
            case self::FILE_FUNC :
                BEAR_Log::appLog('Resource', array("path" => $this->_uri, 'method' => $this->_method, 'values' => $this->_values, 'options' => $this->_options));
                // リソースファイル実行
                $result = $resourceName($this->_values);
                break;
            case self::FILE_CRUD :
                $resouceObj = new $resourceName();
                $method = new ReflectionMethod($resouceObj, 'on' . $this->_method);
                $result = $method->invoke($resouceObj, $this->_values, $this->_options);
                break;
            default :
                PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, E_ERROR, 'error', array('resource' => $this->_uri, 'file' => $resourceFile), 'Mismatch resource.（リソース名とクラス(関数)名にミスマッチがあります)');
                ;
                break;
        }
        return $result;
    }

    /**
     * ページャービューの作成
     *
     * <pre>ビューのページングを行います。
     * makeで作成し内部に保持しているビューに対してページング処理を行います。
     * ページングされたビューとHTMLリンクが生成されるのでそれぞれgetPagerResult()とgetPagerLinks()で取り出すことができます。
     * $optionsはPEAR::Pagerのオプションが設定できます。
     *
     * Example 1. ページあたり10のデータにページング
     * </pre>
     * <code>
     * $res = new BEAR_Resource();
     * $res->make('pager.sample', $values);
     * $res->pager(10);
     * $view['sample'] = $res->getPagerResult();
     * $pager = $res->getPagerLinks();
     * </code>
     *
     * @param string $perPage 1ページあたりのアイテム数
     * @return array
     * @see PEAR::Pager
     */
    function makePager($perPage, $pagerOptions = array())
    {
        //ページャービュー作成
        $pager = new BEAR_Pager();
        //オプション　ページ辺りのアイテム数
        $pagerOptions['perPage'] = $perPage;
        $pager->setOptions($pagerOptions);
        $pager->makePager($this->_result);
        $this->_result = $pager->getResult();
        $this->_pager['links'] = $pager->getLinks();
        return $this->_result;
    }

    /**
     * トークン検査
     *
     * トークンが有効か無効(使用済み含む）を調査します。
     *
     * @param string $token
     * @return bool true=valid
     *
     */
    private function _isTokenValid($token)
    {
        BEAR_Session::start();
        if (is_array($_SESSION['_used_token'])) {
            $isUsed = key_exists($token, $_SESSION['_used_token']);
        } else {
            $isUsed = false;
        }
        if ($token == BEAR_Form::$validToken && !$isUsed) {
            $_SESSION['_used_token'][$token] = 1;
            BEAR_Log::appLog('Token Valid', array('submited token' => $token));
            $result = true;
        } else {
            // invalid token
            BEAR_Log::appLog('Token Invalid', array('resource' => $this->_uri, 'is used' => $isUsed, 'submited token' => $token, 'valid token' => BEAR_Form::$validToken));
            $result = false;
        }
        return $result;
    }
}
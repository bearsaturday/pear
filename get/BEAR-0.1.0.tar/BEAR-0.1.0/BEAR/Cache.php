<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Cache
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEAR_Cache
 *
 * <pre>
 * 指定したキャッシュエンジンでキャッシュを扱うクラスです。
 * 
 * </pre>
 *  * Example 1. キャッシュ保存
 * </pre>
 * <code>
 *   $cache = BEAR_Cache::facotry(BEAR_Cache::ENGINE_MEMCACHE);
 *   $cache->set('topRanking', $ranking);
 * </code>
 *
 * Example 2 キャッシュ取得
 *
 * <code>
 *   $cache = BEAR_Cache::facotry(BEAR_Cache::ENGINE_MEMCACHE);
 *   $cache->get('topRanking');
 * </code>
 *
 * Example 3 キャッシュ削除
 *
 * <code>
 *   $cache = BEAR_Cache::facotry(BEAR_Cache::ENGINE_MEMCACHE);
 *   $cache->delete('topRanking');
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Cache
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 * @see         PECL::Memcache, PEAR::Cache_Lite
 */
class BEAR_Cache
{

    const CONFIG_ENGINE = 'engine';

    /**
     * キャッシュなし
     */
    const ENGINE_NONE = 0;

    /**
     * memcahced
     */
    const ENGINE_MEMCACHE = 1;

    /**
     * Cache_Lite
     */
    const ENGINE_CACHE_LITE = 2;

    /**
     * シングルトンインスタンス
     *
     * @var BEAR_Memcache
     */
    private static $_instance;

    /**
     * 
     * シングルトンパターンのためコンストラクタ不可
     * 
     */
    final private function __construct()
    {}

    /**
     * キャッシュエンジンファクトリー
     *
     * 指定のキャッシュエンジンでキャッシュオブジェクトを返します
     *
     * @return object
     * @return BEAR_Cache_Adapter
     */
    public static function getInstance($config = array('engine' => BEAR_Cache::ENGINE_NONE, 'options' => null))
    {
        if (self::$_instance) {
            return null;
        }
        $config = BEAR::values($config);
        switch ($config['engine']) {
            case self::ENGINE_MEMCACHE :
                $config = array('servers' => App::$memcache);
                self::$_instance = new BEAR_Cache_Adapter_Memcache($config);
                break;
            case self::ENGINE_NONE :
                self::$_instance = new BEAR_Cache_Adapter_Cache_Lite();
                break;
            case self::ENGINE_NONE :
            default :
                self::$_instance = new BEAR_Cache_Adapter_None();
        }
        return self::$_instance;
    }

    public static function destoryInstance()
    {
        self::$_instance = null;
    }
}
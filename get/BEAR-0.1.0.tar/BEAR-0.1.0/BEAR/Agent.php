<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Agent
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * エージェントクラス
 *
 * <pre>
 * 各エージェント（携帯）判別やエージェント毎の詳細情報を取得する
 * PEARのNet_UserAgent_Mobileオブジェクトをプロパティに保持している
 *
 * Example 1. 直接アクセス
 *
 * </pre>
 * <code>
 * $agent = BEAR_Agent::getInstance();
 * $sub_id = $agent->getSubID();
 * </code>
 *
 * Example 2. 内部のNet_UserAgent_Mobileオブジェクトにアクセス
 * <code>
 * $agent = BEAR_Agent::getInstance();
 * $display = $agent->agent->getDisplay()
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Agent
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Agent.php 406 2008-07-02 06:41:10Z koriyama $
 */
class BEAR_Agent
{

    /**
     * PC
     */
    const UA_PC = 'N';

    /**
     * Docomo iモード
     */
    const UA_DOCOMO = 'I';

    /**
     * AU EzWeb
     */
    const UA_AU = 'E';

    /**
     * Softbank 3GC
     */
    const UA_SOFTBANK = 'S';

    /**
     * Willcom
     */
    const UA_WILLCOM = 'W';

    /**
     * ボット用携帯エージェント(Docomo)
     */
    const BOT_DOCOMO = 'DoCoMo/2.0 N900i(c100;TB;W24H12)';

    /**
     * ボット用携帯エージェント(Docomo)
     */
    const BOT_AU = 'KDDI-TS26 UP.Browser/6.2.0.5 (GUI) MMP/1.1';

    /**
     * ボット用携帯エージェント(SB)
     */
    const BOT_SOFTBANK = 'SoftBank/1.0/705P/PJA23 Browser/Teleca-Browser/3.1 Profile/MIDP-2.0 Configuration/CLDC-1.1';

    /**
     * ボット用携帯エージェント(Willcom)
     */
    const BOT_WILLICOM = 'Mozilla/3.0(WILLCOM;KYOCERA/WX310K/2;1.1.5.15.000000/0.1/C100) Opera 7.0';

    /**
     * QVGAと判断するサイズ
     */
    const QVGA_WIDTH = 230;

    /**
     * 小さいと判定するキャッシュサイズ
     */
    const SMALL_CACHE_SIZE = 15000;

    /**
     * BOTかどうか
     * 
     * @var bool
     */
    public static $isBot = false;

    /**
     * ユーザーエージェント
     *
     * ブラウザが送信するユーザーエージェント
     *
     * @var     string
     */
    private $_inputAgent;

    /**
     * モバイルエージェント
     *
     * Net_UserAgent_Mobileクラスが生成したもの
     *
     * @var     string
     */
    public $agent;

    /**
     * シングルトンインスタンス
     *
     * @var object
     */
    private static $_instance;

    /**
     * コンストラクタ
     *
     * <pre>開発のためにエージェントを強制指定することができます。
     * デフォルトは$_SERVERから読み込まれた生のUAが使われます。
     * </pre>
     *
     * @param   string  $user_agent  エージェント文字列
     * @param   void
     */
    function __construct($_inputAgent = NULL)
    {
        $this->_inputAgent = $_inputAgent;
        //Net_UserAgent_Mobileオブジェクト生成
        $this->getAgent();
    }

    /**
     * シングルトンインスタンスの取得
     *
     * BEAR_Agentのインスタンスをシングルトンで取得します
     *
     * @param   array   $config 
     * @return object
     */
    public function getInstance($config = array('agnet' => ''))
    {
        if (!isset(self::$_instance)) {
            //インスタンス生成
            self::$_instance = self::_getAgent($config['agent']);
        }
        return self::$_instance;
    }

    /**
     * Net_UserAgent_Mobileクラスのインスタンス生成
     *
     * <pre>Net_UserAgent_Mobileクラスのインスタンスを生成してagentプロパティに格納します</pre>
     *
     * @param  void
     * @return  object
     * @access public
     */
    protected function _getAgent($agent)
    {
        $httpUserAgent = $this->agent = &Net_UserAgent_Mobile::factory($agent);
        if (PEAR::isError($this->agent)) {
            switch (true) {
                case (strstr($httpUserAgent, 'DoCoMo')) :
                    $botAgent = self::BOT_DOCOMO;
                    break;
                case (strstr($httpUserAgent, 'KDDI-')) :
                    $botAgent = self::BOT_AU;
                    break;
                case (preg_match('/(SoftBank|Vodafone|J-PHONE|MOT-)/', $httpUserAgent)) :
                    $botAgent = self::BOT_SOFTBANK;
                    break;
                case (preg_match('/(DDIPOCKET|WILLCOM)/', $httpUserAgent)) :
                    $botAgent = self::BOT_WILLCOM;
                    break;
                default :
                    $botAgent = '';
            }
            $this->agent = &Net_UserAgent_Mobile::factory($botAgent);
            self::$isBot = true;
        }
        return $this->agent;
    }

    /**
     * キャリア名をショートネームで取得
     *
     * BEAR_Agent::UA_PC
     * BEAR_Agent::UA_DOCOMO
     * BEAR_Agent::UA_AU
     * BEAR_Agent::UA_SOFTBANK
     * BEAR_Agent::UA_WILLCOM
     * 上記ののいずれかを返します
     *
     * @return string
     */
    public function getCarrierShortName()
    {
        assert(is_object($this->agent));
        return strtolower($this->agent->getCarrierShortName());
    }

    /**
     * EZ端末でサブスクライバIDの取得
     *
     * @param  void
     * @return string
     * @access public
     * @static 
     */
    static function getSubID()
    {
        $headers = getallheaders();
        $result = $this->subID = $headers['x-up-subno'];
        BEAR_Log::appLog('EZ Sub ID', $result);
        return $result;
    }

    /**
     * QVGA端末かどうかを取得
     *
     * @internal  横幅がself::QVGA_WIDTHより大きかればQVGA判定
     * @param void
     * @return bool
     */
    static function isQVGA()
    {
        static $is_QVGA;
        if (!isset($is_QVGA)) {
            $size = $this->getDisplaySize();
            $is_QVGA = ($size[0] > self::QVGA_WIDTH) ? true : false;
            //DoCoMoでディスプレイサイズが分からない場合QVGAとする
            if (!$is_QVGA && ((BEAR::$ua == BEAR_Agent::UA_DOCOMO) && ($size[0] == 0))) {
                $is_QVGA = true;
            }
        }
        return $is_QVGA;
    }

    /**
     * 画面サイズの縦、横のサイズを取得
     *
     * @param void
     * @return array    (width, height)
     */
    function getDisplaySize()
    {
        static $size;
        if (!isset($size)) {
            $display = $this->agent->getDisplay();
            $size = $display->getSize();
        }
        return $size;
    }

    /**
     * 携帯の表示可能文字数を取得
     *
     * 携帯の表示可能文字数を取得します。結果はキャッシュされます。
     *
     * @return array
     */
    function getDisplayByteSize()
    {
        static $byte_size;
        if (!isset($byte_size)) {
            $display = $this->agent->getDisplay();
            $byte_size = array($display->getWidthBytes(), $display->getHeightBytes());
        }
        return $byte_size;
    }

    /**
     * キャッシュサイズの取得
     *
     * 端末のキャッシュサイズをバイト数で返します。
     *
     * @param void
     * @return integer
     */
    function getCacheSize()
    {
        switch (BEAR::$ua) {
            case BEAR_Agent::UA_DOCOMO :
                $size = $this->agent->getCacheSize() * 1024;
                break;
            case BEAR_Agent::UA_AU :
                $headers = getallheaders();
                $size = $headers['x-up-devcap-max-pdu'];
                break;
            case BEAR_Agent::UA_SOFTBANK :
                $phone = $this->agent->getName(); // 'J-PHONE'
                $version = (int)$this->agent->getVersion(); // 2.0
                if ($phone == 'J-PHONE') {
                    if ($version <= 3.0) {
                        $size = 6000;
                    } elseif ($version <= 4.2) {
                        $size = 12000;
                    } elseif ($version <= 4.3) {
                        $size = 30000;
                    } elseif ($version <= 5.0) {
                        $size = 200000;
                    } else {
                        $size = 200000;
                    }
                } else {
                    $size = 300000;
                }
                break;
            default :
                $size = false;
        }
        return $size;
    }

    /**
     * キャッシュサイズの小さな端末かチェック
     *
     * @param integer $small_size
     * @return bool
     */
    function isSmallCacheSize($small_size = self::SMALL_CACHE_SIZE)
    {
        $cache_size = $this->getCacheSize();
        $result = ($cache_size && $cache_size < $small_size) ? true : false;
        return $result;
    }

    /**
     * セッションクエリーを付加
     *
     * クッキーが使えないエージェント用にURLからセッションクエリー付きURLを返します。<
     *
     * @param string $url
     * @return string
     */
    public function getSessionQuery($url = false)
    {
        $session_name = session_name();
        $session_id = session_id();
        if (!isset($_COOKIE[$session_name])) {
            /**
             * セッションクエリーが付いてれば消去
             */
            $url = preg_replace("/&*{$session_name}=[^&]+/is", '', $url);
            $con = ($url && strpos($url, "?")) ? '&' : '?';
            $url .= "{$con}{$session_name}={$session_id}";
        }
        return $url;
    }

    /**
     * DoCoMoのHTMLバージョンを取得
     *
     * Docomoの場合の利用可能HTMLバージョンを返します。
     *
     * @param   void
     * @return  string バージョン
     * @access  public
     */
    public function getHTMLVersion()
    {
        static $result;
        if (isset($result)) {
            return $result;
        }
        $htmlVersionMap = array('M702i' => '5.0');
        $res = $this->agent->getModel();
        foreach($htmlVersionMap as $key => $value) {
            if (preg_match("/$key/", $res)) {
                $result = $value;
                return $result;
            }
        }
        $result = $this->agent->getHTMLVersion();
        return $result;
    }
}
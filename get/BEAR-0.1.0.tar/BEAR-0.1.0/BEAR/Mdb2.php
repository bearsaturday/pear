<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Mdb2
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * MDB2クラス
 *
 * <pre>
 * PEAR::MDB2を継承したDBアクセスクラスです。
 * アプリケーションではこのクラスを継承したアプリケーションDBアクセス
 * クラスを(App_DB)を定義しアプリケーションからはそちらを使用します。
 *
 *
 * 拡張機能
 * +同じクエリーなら同じ結果を返すクエリーキャッシュ
 * +実行計画の自動ログ
 * +DBハンドル自動再利用
 * +二重実行防止トークン処理
 * +実行時間計測
 * +INSERT文、UPDATE文生成
 *
 * MDB2結果コード
 *
 * ('MDB2_OK',                      true);
 * ('MDB2_ERROR',                     -1);
 * ('MDB2_ERROR_SYNTAX',              -2);
 * ('MDB2_ERROR_CONSTRAINT',          -3);
 * ('MDB2_ERROR_NOT_FOUND',           -4);
 * ('MDB2_ERROR_ALREADY_EXISTS',      -5);
 * ('MDB2_ERROR_UNSUPPORTED',         -6);
 * ('MDB2_ERROR_MISMATCH',            -7);
 * ('MDB2_ERROR_INVALID',             -8);
 * ('MDB2_ERROR_NOT_CAPABLE',         -9);
 * ('MDB2_ERROR_TRUNCATED',          -10);
 * ('MDB2_ERROR_INVALID_NUMBER',     -11);
 * ('MDB2_ERROR_INVALID_DATE',       -12);
 * ('MDB2_ERROR_DIVZERO',            -13);
 * ('MDB2_ERROR_NODBSELECTED',       -14);
 * ('MDB2_ERROR_CANNOT_CREATE',      -15);
 * ('MDB2_ERROR_CANNOT_DELETE',      -16);
 * ('MDB2_ERROR_CANNOT_DROP',        -17);
 * ('MDB2_ERROR_NOSUCHTABLE',        -18);
 * ('MDB2_ERROR_NOSUCHFIELD',        -19);
 * ('MDB2_ERROR_NEED_MORE_DATA',     -20);
 * ('MDB2_ERROR_NOT_LOCKED',         -21);
 * ('MDB2_ERROR_VALUE_COUNT_ON_ROW', -22);
 * ('MDB2_ERROR_INVALID_DSN',        -23);
 * ('MDB2_ERROR_CONNECT_FAILED',     -24);
 * ('MDB2_ERROR_EXTENSION_NOT_FOUND',-25);
 * ('MDB2_ERROR_NOSUCHDB',           -26);
 * ('MDB2_ERROR_ACCESS_VIOLATION',   -27);
 * ('MDB2_ERROR_CANNOT_REPLACE',     -28);
 * ('MDB2_ERROR_CONSTRAINT_NOT_NULL',-29);
 * ('MDB2_ERROR_DEADLOCK',           -30);
 * ('MDB2_ERROR_CANNOT_ALTER',       -31);
 * ('MDB2_ERROR_MANAGER',            -32);
 * ('MDB2_ERROR_MANAGER_PARSE',      -33);
 * ('MDB2_ERROR_LOADMODULE',         -34);
 * ('MDB2_ERROR_INSUFFICIENT_DATA',  -35);
 * </pre>
 *
 * DATAタイプ
 *
 * 'text':
 * 'clob':
 * 'blob':
 * 'integer':
 * 'boolean':
 * 'date':
 * 'time':
 * 'timestamp':
 * 'float':
 * 'decimal':
 *
 * Example 1. セレクトクエリー
 *
 * </pre>
 * <code>
 *   $mdb2 = BEAR_Mdb2::getInstance($dsn);
 *   ...
 *   $value = $mdb2->queryOne($query);
 *   $value = $mdb2->queryRow($query);
 *   $value = $mdb2->queryAll($query);
 * </code>
 *
 * Example 2. インサート文生成
 *
 * <code>
 *  $mdb2 = BEAR_Mdb2::getInstance($dsn);
 *  $table_name = "user_table";
 *  $fields_values = array('id'=>$id, 'password'=>$password);
 *  $result = $mdb2->extend->autoExecute($table_name, $fields_values, MDB2_AUTOQUERY_INSERT);
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Mdb2
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Mdb2.php 417 2008-07-02 12:03:30Z koriyama $
 * @see         PEAR::MDB2, PEAR::MDB2_Driver_Datatype_mysql
 */
class BEAR_Mdb2 extends MDB2
{

    /**
     * キャッシュオプション
     * $_cache['life_time']     int キャッシュ時間
     * $_cache['id']            mixed キャッシュID
     *
     * @var mixed
     * @access private
     */
    private $_cache = false;

    /**
     * BEAR_Resourceオプション
     * 
     * queryPagerで使用
     *
     * @var array
     */
    public static $options;

    /**
     * インスタンス
     * 
     * @var BEAR_Mdb2
     */
    private static $_mdb2_instance = false;

    /**
     * シングルトン
     *
     * <pre>MDB2のsingletonの代替です。
     *
     *
     *　</pre>
     * @param string $dsn
     * @param array $option
     * @return MDB2_Driver_Datatype_mysqli
     */
    public function getInstance($dsn, $option = array())
    {
        if (!isset(self::$_mdb2_instance[$dsn])) {
            // MDB2インスタンス生成
            if (App::$debug) {
                // Debugモード オプション
                $option['debug'] = true;
                $option['debug_handler'] = array('BEAR_Mdb2', '_debugHandler');
            } else {
                $option['debug'] = false;
                $option['debug_handler'] = array('BEAR_Mdb2', '_liveHandler');
            }
            self::$_mdb2_instance[$dsn] = MDB2::factory($dsn, $option);
            self::$_mdb2_instance[$dsn]->setFetchMode(MDB2_FETCHMODE_ASSOC);
        }
        return self::$_mdb2_instance[$dsn];
    }

    /**
     * ユーザーがインターフェースを複製するのを防ぐ
     *
     */
    public function __clone()
    {
        trigger_error('Singleton.Clone is not allowed.', E_USER_ERROR);
    }

    /**
     * カウントクエリーを生成する
     *
     * <pre>SQL文から"SELECT COUNT(*)" を付加したカウントクエリーを生成して返します。
     * COUNT文を含まないSQLからセレクト結果の個数を知るためCOUNTのクエリーを
     * 使用するのに用います
     * DBページャーで内部的にも使用されています。
     *
     * Example 1. SQLからCOUNT()を取得
     *
     * </pre>
     * <code>
     * $count_query = $this->getCountSQL($query));
     * $total_items = $this->getOne($count_query, $params);
     * </code>
     *
     * @param string $query クエリー
     * @return string 書き換えられたクエリー | false（失敗）
     * @access public
     * @static
     *
     */
    public static function rewriteCountQuery($query)
    {
        if (preg_match('/^\s*SELECT\s+\bDISTINCT\b/is', $query) || preg_match('/\s+GROUP\s+BY\s+/is', $query)) {
            return false;
        }
        $open_parenthesis = '(?:\()';
        $close_parenthesis = '(?:\))';
        $subquery_in_select = $open_parenthesis . '.*\bFROM\b.*' . $close_parenthesis;
        $pattern = '/(?:.*' . $subquery_in_select . '.*)\bFROM\b\s+/Uims';
        if (preg_match($pattern, $query)) {
            return false;
        }
        $subquery_with_limit_order = $open_parenthesis . '.*\b(LIMIT|ORDER)\b.*' . $close_parenthesis;
        $pattern = '/.*\bFROM\b.*(?:.*' . $subquery_with_limit_order . '.*).*/Uims';
        if (preg_match($pattern, $query)) {
            return false;
        }
        $queryCount = preg_replace('/(?:.*)\bFROM\b\s+/Uims', 'SELECT COUNT(*) FROM ', $query, 1);
        list($queryCount, ) = preg_split('/\s+ORDER\s+BY\s+/is', $queryCount);
        list($queryCount, ) = preg_split('/\bLIMIT\b/is', $queryCount);
        return trim($queryCount);
    }

    /**
     * ページャーセレクト
     *
     * <pre>DB結果の一部だけをSELECTする機能と、HTMLページングの機能が合わさったメソッドです。
     * getAll()メソッドの引数に加えて一画面に表示するデータ数を引数に指示すると
     * ページング(スライス）されたデータ結果、エージェントに合わせたリンクHTML文字列が返ります。
     * 引数のSQLからCOUNT文とLIMIT文をメソッド内部で生成して実行します。
     * SELECTの範囲を全件ではなくて任意の数にしたいときは$pagerOptions['totalItems']にトータルの件数をセットします。
     * 
     * </pre>
     * @param object PEAR::MDB2 instance
     * @param string db query
     * @param array  PEAR::Pager options
     * @param boolean Disable pagination (get all results)
     * @param integer fetch mode constant
     * @return array with links and paged data
     */
    /**
     * ページャーセレクト
     *
     * <pre>DB結果の一部だけをSELECTする機能と、HTMLページングの機能が合わさったメソッドです。
     * getAll()メソッドの引数に加えて一画面に表示するデータ数を引数に指示すると
     * ページング(スライス）されたデータ結果、エージェントに合わせたリンクHTML文字列が返ります。
     * 引数のSQLからCOUNT文とLIMIT文をメソッド内部で生成して実行します。
     * SELECTの範囲を全件ではなくて任意の数にしたいときは$pagerOptions['totalItems']にトータルの件数をセットします。
     *
     * @param MDB2_Driver_Datatype_mysql $db 
     * @param string $query 
     * @param array $pagerOptions
     * @return BEAR_Vo
     */
    public function queryPager(&$db, $query, $pagerOptions = array())
    {
        if (!array_key_exists('totalItems', $pagerOptions)) {
            //be smart and try to guess the total number of records
            $countQuery = self::rewriteCountQuery($query);
            if ($countQuery) {
                $totalItems = $db->queryOne($countQuery);
                if (PEAR::isError($totalItems)) {
                    return $totalItems;
                }
            } else {
                //GROUP BY => fetch the whole resultset and count the rows returned
                $res = & $db->queryCol($query);
                if (PEAR::isError($res)) {
                    return $res;
                }
                $totalItems = count($res);
            }
            $pagerOptions['totalItems'] = $totalItems;
        }
        // ページング
        $bear_pager = new BEAR_Pager();
        // totalItems以外のBEAR_Pagerデフォルトオプションを使用
        $bear_default_pager_options = $bear_pager->getPagerOptions();
        unset($bear_default_pager_options['totalItems']);
        $pagerOptions = $bear_default_pager_options + $pagerOptions;
        $bear_pager->setOptions($pagerOptions);
        $bear_pager->pager->build();
        $pager = $bear_pager->pager;
        //情報
        $getpager = array();
        $info['totalItems'] = $pagerOptions['totalItems'];
        $bear_pager->makeLinks($pagerOptions['delta'], $pagerOptions['totalItems']);
        $links = $pager->getLinks();
        $info['page_numbers'] = array('current' => $pager->getCurrentPageID(), 'total' => $pager->numPages());
        list($info['from'], $info['to']) = $pager->getOffsetByPageId();
        $info['limit'] = $info['to'] - $info['from'] + 1;
        $db->setLimit($pagerOptions['perPage'], $info['from'] - 1);
        $result = $db->queryAll($query);
        if (PEAR::isError($result)) {
            return $result;
        }
        //        $last_query = $db->
        // VOオブジェクトにして返す
        $vo = new BEAR_Vo($result, $info, $links);
        BEAR_Log::appLog("DB Pager", array('info' => $info));
        return $vo;
    }

    /**
     * エラーハンドラー
     *
     * <pre>エラー処理</pre>
     *
     * @param object $paer_error
     * @access private
     */
    static function _errorHandler($paer_error)
    {
        trigger_error('BEAR_Mdb2 Error:' . $paer_error->toString(), E_USER_WARNING);
    }

    /**
     * Debugハンドラー
     *
     * <pre>開発時のハンドラーです。AJAXコールの場合はヘッダーにエラー情報を返します</pre>
     *
     * @param object $object
     * @param string $type
     * @param string $query
     * @param string $is_error
     * @access private
     */
    public static function _debugHandler(&$db, $type, $query, $is_error)
    {
        $log['type'] = $type;
        $log['sql'] = $query;
        $log['err'] = $is_error;
        if (PEAR::isError($db)) {
            $log['msg'] = $db->toString();
        }
        if (App::$debug) {
            if (strtolower((substr($query, 0, 6))) == 'select') {
                $debug_handler = $db->getOption('debug_handler');
                $db->setOption('debug_handler', '');
                $start_time = microtime(true);
                $db->query($query);
                $log['time'] = microtime(true) - $start_time;
                //                $log['explain'] = $db->queryAll("EXPLAIN EXTENDED {$query}");
                $db->setOption('debug_handler', $debug_handler);
            }
            //ログ
            BEAR_Log::appLog('MDB2', $log);
        }
    }

    /**
     * アサーション
     * 
     * @param $bool
     */
    static function assert($bool)
    {
        if (!$bool) {
            BEAR_Main::end();
        }
    }
}
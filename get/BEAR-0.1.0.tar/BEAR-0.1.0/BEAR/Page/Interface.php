<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Page
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * $_GETが取得できるインターフェイス
 * 
 * このインターフェイスが実装されてるページにはフレームワークが$_GETを渡します
 * 
 * @category    BEAR
 * @package     BEAR_Page
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: Interface.php 88 2008-07-28 13:24:23Z koriyama $
 *  */
interface args_Interface
{

    /**
     * ページ初期化
     *
     * @param array $args
     */
    function onInit(array $args);
}
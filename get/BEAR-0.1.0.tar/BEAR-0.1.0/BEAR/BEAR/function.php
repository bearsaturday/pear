<?php
/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$

/**
 * print_a関数読み込み
 */
require_once ('BEAR/inc/debuglib.php');

/**
 * デバック用プリント（print_a版）
 *
 * <pre>デバック表示。デバックモードのときにしか機能しません。
 * bear.jsによるAJAXリクエストのときはheaderにprint_rフォーマットで出力されます。</pre>
 *
 * Example. 画面に最大30
 *
 * <code>
 * print_b($values, "")
 * </code>
 * <code>
 *
 * @param mixed $values
 * @param string $label
 * @param string $option
 */
function p($values = '', $is_fill_path = false)
{
    //    if (BEAR_Page::isAjaxRequest()) {
    //        static $cnt = 0;
    //        header("X-BEAR-print-{$cnt}:" . print_r($values, true));
    //        $cnt++;
    //        return;
    //    }
    $trace = (debug_backtrace());
    $file = $trace[0]['file'];
    $include_path = explode(":", get_include_path());
    // include_pathがあれば除去
    if (!$is_fill_path) {
        foreach($include_path as $var) {
            if ($var != '.') {
                $file = str_replace($var, '', $file);
            }
        }
    }
    $file = substr($file, 1); //先頭の/を除去
    $method = (isset($trace[1]['function'])) ? " ({$trace[1]['class']}" . '->' . "{$trace[1]['function']})" : '';
    $label = "in {$file} on line {$trace[0]['line']}$method";
    $option = "show_objects:1;max_y:50;label:{$label}";
    print_a($values, $option);
}

/**
 * クラスリバーシエンジニアリング表示
 *
 * クラスの内容概略が画面表示されます。
 *
 * @param string $class クラスまたはオブジェクト
 */
function c($class)
{
    ob_start();
    if (is_object($class)) {
        $class = get_class($class);
    }
    Reflection::export(new ReflectionClass($class));
    $reflection = ob_get_clean();
    $option = "show_objects:1;label:{$class}";
    print_a($reflection, $option);
}

/**
 * バックトレース表示
 *
 */
function t()
{
    print_a(debug_backtrace());
}

/**
 * PEARのVar_Dump表示
 *
 * PEARのVar_Dump::displayを使った変数表示です。
 *
 * @param mixed $values
 * @see http://pear.php.net/package/Var_Dump/docs
 */
function v($values)
{
    require_once ('PEAR/Var_Dump.php'); // auloader doesn't work
    Var_Dump::displayInit(array('display_mode' => 'HTML4_Text'));
    Var_Dump::display($values);
}
?>
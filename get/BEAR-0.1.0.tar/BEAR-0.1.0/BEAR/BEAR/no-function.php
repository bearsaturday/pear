<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 */

function p()
{}

function c()
{}

function t()
{}

function v()
{}

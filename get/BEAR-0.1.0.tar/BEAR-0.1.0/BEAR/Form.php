<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Form
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * BEARフォームクラス
 *
 * PEAR::HTML_QuickFormクラスのラッパークラスです。
 *
 * @category    BEAR
 * @package     BEAR_Form
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Form.php 406 2008-07-02 06:41:10Z koriyama $
 * @see         PEAR::HTML_QuickForm
 */
class BEAR_Form extends HTML_QuickForm
{

    /**
     * '静的な' Smarty テンプレートのためのレンダラ
     * @see http://pear.php.net/manual/ja/package.html.html-quickform.html-quickform-renderer-arraysmarty.php
     */
    const RENDERER_SMARTY_ARRAY = 0;

    /**
     * 完全に妥当な XHTML を出力するレンダラ
     * 
     * @see http://pear.php.net/manual/ja/package.html.html-quickform-renderer-tableless.intro.php
     *
     */
    const RENDERER_DHTML_TABLELESS = 1;

    /**
     * アプリケーションランダラ
     * 
     * App::onFormRender()がコールされます
     */
    const RENDERER_APP = -1;

    /**
     * JS Alertのメッセージ
     *
     */
    const JS_WARNING = '入力内容に誤りがあります';

    /**
     * 必須項目メッセージ
     *
     */
    const REQUIRE_NOTES = '<span style="font-size:80%; color:#ff0000;">*</span><span style="font-size:80%;">の項目は必ず入力してください。</span>';

    /**
     * エラーテンプレート
     *
     */
    const TEMPLATE_ERROR = '{if $error}<font color="red">{$label}</font>{/if}';

    /**
     * 必須項目テンプレート
     *
     */
    const TEMPLATE_REQUIRED = '{$html}{if $required}<font color="#FF0000">*</font>{/if}';

    /**
     * 有効なトークン名のセッション保存時のキー
     * 
     * @internal 
     */
    const TOKEN_SESSION_NAME = '_valid_token';

    /**
     * Submit値
     * 
     * Quick_Form::getSubmitValue()の値
     *
     * @var array
     */
    public static $submitValue;

    /**
     * Export値
     * 
     * Quick_Form::getExportValue()の値
     * 
     */
    public static $exportValue;

    /**
     * AJAXフォーム用フラグ
     *
     * @var bool
     * @access private
     */
    private $_is_ajax_form = false;

    /**
     * エラーテンプレート
     * 
     * @var string
     */
    public static $error_template = self::TEMPLATE_ERROR;

    /**
     * 必須項目テンプレート
     * 
     * @var string
     */
    public static $require_template = self::TEMPLATE_REQUIRED;

    /**
     * 必須項目説明表示
     * 
     * @var string
     */
    public static $requireNotes = self::REQUIRE_NOTES;

    /**
     * JS警告
     */
    public static $jsWarning = self::JS_WARNING;

    /**
     * フォームレンダラ
     * 
     * @var string
     */
    public static $renderer = self::RENDERER_SMARTY_ARRAY;

    /**
     * フォーム名
     */
    public static $form = 'form';

    /**
     * 送信方法
     *
     * @var string
     */
    public static $method = 'post';

    /**
     * 有効なトークン
     *
     * @var string
     */
    public static $validToken = null;

    /**
     * シングルトン
     */
    private static $_instance = null;

    /**
     * 
     * シングルトンパターンのためコンストラクタ不可
     * 
     */
    final private function __construct()
    {}

    /**
     * BEAR_Formインスタンス取得
     *
     * @param string $formNames
     * @param string $method
     * @param string $action
     * @param string $target
     * @param string $attributes
     * @return BEAR_Form
     */
    public static function getInstance($formNames = 'form', $method = 'post', $action = '', $target = '', $attributes = null)
    {
        //        $formNames = $config['form'];
        //        $method = $config['method'];
        //        $action = $config['action'];
        //        $target = $config['target'];
        //        $attributes = $config['attributes'];
        self::$form = $formNames;
        if (!is_array($formNames)) {
            if (self::$_instance === null) {
                self::$_instance = self::_new($formNames, $method, $action, $target, $attributes, false);
            }
        } else {
            foreach($formNames as $form_name) {
                self::$_instance[$form_name] = self::_new($form_name, $method, $action, $target, $attributes, true);
            }
        }
        self::$method = $method;
        return self::$_instance;
    }

    /**
     * コンストラクタ
     */
    function _new($form_name, $method, $action, $target, $attributes, $trackSubmit)
    {
        // QuickForm作成
        $form = new HTML_QuickForm($form_name, $method, $action, $target, $attributes, $trackSubmit);
        // 必須項目メッセージ日本語化
        $form->setRequiredNote(BEAR_Form::$requireNotes);
        // JSメッセージ日本語化
        $form->setJsWarnings(BEAR_Form::$jsWarning, '');
        // BEAR使用hidden項目
        self::_saveToken($form);
        return $form;
    }

    /**
     * @ignore 
     */
    public function __clone()
    {
        trigger_error('Singleton.Clone is not allowed.', E_USER_ERROR);
    }

    /**
     * BEAR_FORMがインスタンスをもつか返す
     *
     * @return bool
     */
    public static function hasInstance()
    {
        return (self::$_instance) ? true : false;
    }

    /**
     * インスタンス解放
     * 
     * ページの再生成で使用されます
     */
    public static function init()
    {
        self::$_instance = null;
    }

    /**
     * トークンの保存
     * 
     * 二重送信防止とCSSF防止のため、セッションとhiddenに埋め込みます
     *
     * @param array $formNames
     * @param object $form
     * @param bool $is_single_form
     * @return void
     * @access private
     */
    private function _saveToken(&$form)
    {
        $newToken = self::makeToken();
        $form->addElement('hidden', '_token', $newToken);
        self::$validToken = BEAR_Session::get(self::TOKEN_SESSION_NAME);
        $_SESSION[self::TOKEN_SESSION_NAME] = $newToken;
    }

    /**
     * トークン生成
     *
     * <pre>14桁の16進数トークンを生成。
     * 前12桁がデータ、残り2桁がチェックサム。
     * スタティックコールできます。
     *
     * データ例）
     * 8486ab282a8f37
     * <--data----><check sum>
     * </pre>
     *
     * @return string
     * @static
     */
    public static function makeToken($isAjax = false, $seed = '')
    {
        $rnd = md5(uniqid(rand(), true));
        if ($isAjax) {
            $token_body = 'a' . substr(md5($rnd), 0, 12);
        } else {
            $token_body = '0' . substr(md5($rnd), 0, 12);
        }
        $result = $token_body . self::makeAuthKey();
        return $result;
    }

    /**
     * トークン用認証キー生成
     *
     * @return string
     */
    public static function makeAuthKey()
    {
        return substr(md5(session_id() . App::AUTH_KEY), 0, 4);
    }

    /**
     * フォームをAJAX用にする
     *
     * <pre>QuickFormのフォームをAJAX対応にします。formタグにrel=bearという属性が追加され
     * postがAJAXリクエストに変わります</pre>
     *
     * Example.1 ページ内でフォームをAJAXフォームに変換
     *
     * <code>
     * $this->form->ajax();
     * </code>
     *
     * @param void
     * @return void
     *
     */
    public function ajax()
    {
        $token_ref = & $this->getElement('_token');
        if (!PEAR::isError($token_ref)) {
            $token_ref->_attributes['value'] = BEAR_Main::makeToken(true);
        } else {
            BEAR_Log::appLog('BEAR_Error', array('Erro no token for AJAX'));
        }
        $attr = $this->_attributes;
        $attr['rel'] = "bear";
        $this->setAttributes($attr);
        $this->_is_ajax_form = true;
    }

    /**
     * AJAXフォームかどうかを返す
     *
     * フォームがAJAXか
     *
     * @return bool
     */
    public function isAjaxForm()
    {
        return $this->_is_ajax_form;
    }
}
<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Cache
 */

/**
 * キャッシュ無クラス
 * 
 * 何をしてもPHPのエラーにならずにエラー(false)を返すクラスです。factoryなどで使います。
 * 
 * @category    BEAR
 * @package     BEAR_Cache
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id:$
 * 
 */
final class BEAR_Cache_Adapter_None
{

    final function __call($name, $args)
    {
        if (App::$debug) {
            BEAR_Log::appLog('BEAR_None', array('name' => $name, 'args' => $args));
        }
        return false;
    }
}
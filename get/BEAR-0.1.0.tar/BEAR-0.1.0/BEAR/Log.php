<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR_Log
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

/**
 * ログ
 *
 * <pre>ログを記録するクラスです</@re>
 * 
 * Example 1. debugモードのときにアプリケーションログを画面出力
 *
 * <code>
 * BEAR_Log::appLog($label, $data);
 * </code>
 *
 * @category    BEAR
 * @package     BEAR_Log
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR_Log.php 414 2008-07-02 10:42:38Z koriyama $
 */
class BEAR_Log
{

    /**
     * アプリケーションログ
     */
    const TYPE_APP = 0;

    /**
     * エラーログ
     */
    const TYPE_ERROR = 1;

    /**
     * リソースアクセスログ
     */
    const TYPE_RESOURCE = 2;

    /**
     * アプリケーションログ
     *
     * @var array
     */
    public static $log;

    /**
     * エラーログ
     *
     * @var array
     */
    public static $errorLog;

    /**
     * リソースログ
     *
     * @var array
     */
    public static $resoruceLog;

    /**
     * Smartyにアサインされた変数
     *
     * @var array
     */
    public static $smartyLog;

    /**
     * エラー統計
     *
     * @var int
     */
    public static $errorStat;

    /**
     * アプリユーザー
     * 
     * ユーザーの特定につながる情報をストアします。
     */
    public static $user = "nobody";

    /**
     * アプリケーションログを記録
     *
     * アプリケーションログを記録します。$valueは配列可です。
     *
     * @param string $label ラベル
     * @param mixed $value  値
     * @access public
     * @static
     */
    public static function appLog($label, $log)
    {
        self::$log[][$label] = $log;
    }

    /**
     * エラーログを保存
     * 
     */
    public static function errorLog($label, $log)
    {
        self::$errorLog[][$error_type][$label] = $log;
    }

    /**
     * エラーログを保存
     * 
     */
    public static function resourceLog($label, $log)
    {
        self::$resoruceLog[][$error_type][$label] = $log;
    }

    /**
    }
     * アプリケーションログを表示
     *
     * アプリケーションログをHTML表示します。
     *
     * @param   void
     * @return  void
     * @access  public
     * @static
     * @ignore
     */
    public function displayScreenLog()
    {
        if (!App::$debug) {
            return;
        }
        // アプリケーションログ
        $appLog = print_a(BEAR_Log::$log, "label:Log;show_objects:0;max_y:30;return:1");
        // サブミットされる前のアプリケーションログ
        if (isset($_SESSION['applog'])) {
            $appLog = BEAR_Log::display($_SESSION['applog'], "label:Previous Log; return:1") . $appLog;
            session_unregister('bear_log');
        }
        // エラー統計
        $errorFgColor = "white";
        if (BEAR_Error::$errorStat & E_ERROR) {
            $errorBgColor = "red";
            $errorMsg = "Fatal Error";
        } elseif (BEAR_Error::$errorStat & E_WARNING) {
            $errorBgColor = "yellow";
            $errorFgColor = "black";
            $errorMsg = "Warning";
        } elseif (BEAR_Error::$errorStat & E_NOTICE) {
            $errorBgColor = "#2D41D7";
            $errorMsg = "Notice";
        } else {
            $errorBgColor = "green";
        }
        // デバック情報表示HTML
        // bear.jsを使用する場合はbear_debuggingがtrueになる
        $html = '<!--BEAR Debug Info--><div style=" font-size: 9px; position: absolute;  top: 0px;  right: 0px; text-align: right;"><a href="/beardev/log/" accesskey="b" target="bearlog" name="' . $errorMsg . '" style="padding:5px 3px 3px 3px;background-color:' . $errorBgColor . ';color:' . $errorFgColor . ';font:bold 8pt Verdana; margin-top:100px; border: 1px solid #dddddd">BEAR</a></div>' . '<!--/BEAR Debug Info--></div>';
        print $html;
    }

    /**
     * アプリケーションHTMLを保存
     *
     * アプリケーションログをHTML保存します。BEAR_Log::filelog()からコールされます
     * 
     * @deprecated 
     */
    function writeHTMLLog()
    {
        static $done = false;
        if (!$done) {
            $done = true;
            $conf = array('mode' => 0644);
            $conf['append'] = (isset($_GET['_clearlog'])) ? false : true;
            $fileName = (isset($_GET['_logname'])) ? $_GET['_logname'] . '.html' : 'log.html';
            $log = &Log::singleton('file', _BEAR_APP_HOME . '/logs/' . $fileName, 'error', $conf);
            $uri = $_SERVER['REQUEST_URI'];
            $appLog = '<hr>';
            if ($uri) {
                $appLog .= "<a href={$uri}>{$uri}</a>";
            } else {
                $appLog = "<p>{$_SERVER["SCRIPT_NAME"]}</p>";
            }
            $appLog = (print_a(self::$log, 'label:BEAR Log; return:1')) . "<hr>";
            $log->log($appLog, PEAR_LOG_DEBUG);
        }
    }

    /**
     * スクリプトシャットダウン時のログ処理
     *
     * @todo EPGSをシリアライズして読み込む実装に変更
     */
    public static function shutDownLogDebug()
    {
    	setcookie('_BEAR_BEARDEV', "hello kuma");
    	$pageLog = serialize(array('app'=>BEAR_Log::$log,
    	   'smarty'=>BEAR_Page::$smarty->_tpl_vars, 
    	   'var'=>DbugL::css . show_vars('trim_tabs:2;show_objects:0;max_y:30;avoid@:1; return:1') . '$_SERVER' . print_a($_SERVER, 'return:1'),
    	   'uri'=>$_SERVER['REQUEST_URI']));
        $result = file_put_contents(_BEAR_APP_HOME . '/logs/page.log', $pageLog);
        if (!$result){
            BEAR_Error::showBoxMessage('Log folder permission denied.（ログフォルダに書き込めません', '<code>chmod 777 '.  _BEAR_APP_HOME . '/logs</code><br>' . 
            '<code>chmod -R 777 '.  _BEAR_APP_HOME . '/tmp</code>', '上記のようにしてwebから書き込めるようにしてください');
        }
    }

    /**
     * スクリプトシャットダウン時のログ処理
     *
     * @todo syslogにリソースログを残す 
     */
    public static function shutDownLogLive()
    {}
}
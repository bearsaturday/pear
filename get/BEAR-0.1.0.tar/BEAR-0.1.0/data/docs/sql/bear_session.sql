# Table "bear_session" DDL

CREATE TABLE `bear_session`
(
  `id` varchar(32) NOT NULL,
  `value` text,
  `time` timestamp(14) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`time`)
) TYPE=MyISAM

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>
            BEAR Log
        </title><!-- Ext JS -->
        <link rel="stylesheet" type="text/css" href="/beardev/ext-2.1/resources/css/ext-all.css">
        <script type="text/javascript" src="/beardev/ext-2.1/adapter/ext/ext-base.js">
</script>
        <script type="text/javascript" src="/beardev/ext-2.1/ext.js">
</script>
        <link rel="stylesheet" type="text/css" href="tabs-example.css">
        <link rel="stylesheet" type="text/css" href="examples.css"><!-- BEARDev JS - Log-->

        <script type="text/javascript" src="index.js">
</script>
    </head>
    <body>
        <h1>
            Log
        </h1><?php 
                        require 'App.php';
                        $pageLog = unserialize(file_get_contents(_BEAR_APP_HOME . '/logs/page.log'));
                        ?>
        <div style="font-size:12px; padding: 20px;">
            <img src="/beardev/ext-2.1/resources/images/default/tree/leaf.gif" alt="script">
            
            <a href="<?php echo $pageLog['uri']; ?>"><?php echo $pageLog['uri']; ?></a>
        </div>
        <div id="bearlog"></div>
    </body>
</html>

<?php
/**
 * ページ変数表示
 * 
 * /logs/page.logに保存されたページ状態のログを表示します。
 */

//ライブモードで使用するためApp.phpより先に読み込み
require_once 'BEAR/inc/debuglib.php';
require_once 'App.php';

$pageLog = unserialize(file_get_contents(_BEAR_APP_HOME . '/logs/page.log'));
switch ($_GET['log']) {
	case 'app':
		print_a($pageLog['app']);
		break;
	case 'smarty':
		print_a($pageLog['smarty']);
		break;
	case 'var':
		print $pageLog['var'];
		break;
	default:
		print_a($pageLog);
	break;
}

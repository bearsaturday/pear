<?php

/**
 * BEAR
 *
 * @category    BEAR
 * @package     BEAR
 * @copyright   2008 Akihito Koriyama  All rights reserved.
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 */

define('_BEAR_BEAR_HOME', realpath(dirname(__FILE__)));

/**
 * BEARシステムクラス
 *
 * フレームワーク全体で必要なプロパティ、スタティックメソッドを持ちます。
 *
 * @category    BEAR
 * @package     BEAR
 * @author      Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @version     $Id: BEAR.php 414 2008-07-02 10:42:38Z koriyama $
 * @license     http://opensource.org/licenses/bsd-license.php BSD
 * 
 * Copyright (c) 2008, Akihito Koriyama.  All rights reserved.
 * 
 * Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */
class BEAR
{

    /**
     * BEARバージョン
     */
    const VERSION = '0.1.0';

    /**
     * DATETIME型時間
     *
     * @var string
     */
    public static $datetime;

    /**
     * BEARルートパス
     *
     * @var unknown_type
     */
    public static $path;

    /**
     *  エージェントレター
     * 
     * ユーザーエージェントが英字1文字で表される
     * 
     * BEAR_Agent::UA_PC
     * BEAR_Agent::UA_DOCOMO
     * BEAR_Agent::UA_AU
     * BEAR_Agent::U_SOFTBANK
     * BEAR_Agent::U_SOFTBANK
     */
    public static $ua;

    /**
     * 初期化
     *
     */
    public static function init()
    {
        self::$datetime = date("Y-m-d H:i:s", time()); // datetime
        self::$path = realpath(dirname(dirname(__FILE__))) . '/'; // BEAR Path
        self::setDebugFunction(); // Debug関数登録
        self::registerShutdownFunction(); // シャットダウン関数登録
    }

    /**
     * クラスローダー
     *
     * @param string $class
     */
    public static function autoload($class)
    {
        $prefix = substr($class, 0, 4);
        switch ($prefix) {
            case 'BEAR' :
                $file = 'BEAR/' . str_replace('_', '/', $class) . '.php';
                include $file;
                break;
            case 'App_' :
                $file = str_replace('_', '/', $class) . '.php';
                include $file;
                break;
            default :
                $pear_path = str_replace('_', '/', $class) . '.php';
                $include = include $pear_path;
                if ($include != 1) {
                    $include = include 'PEAR/' . $pear_path;
                }
        }
        // クラス宣言を含むかどうか確認する
        if (!class_exists($class, false)) {
            echo '<div style="background-color: #f9f9f9; border: 1px solid #D0D0D0;margin: 14px 0 14px 0; padding: 12px 10px 12px 10px; display:block;">';
            echo '<div style="font-size: 16px; color: #ff0000;margin: 10px 0 10px 0;">' . 'BEAR Auto loader failed.' . '</div>';
            echo '<div style="font-size: 14px; color: #000000;margin: 10px 0 10px 0;";">' . "$class クラスが読み込みできませんでした。<br>PEARパッケージの場合は<code>sudo pear install -a $class</code>でインストールしてください。" . '</div>';
            error_log('BEAR Auto loader failed to load ' . $class);
        }
    }

    /**
     * シャットダウン処理の登録
     */
    public static function registerShutdownFunction()
    {
        if (App::$debug) {
            PEAR::registerShutdownFunc(array('BEAR_Log', 'shutDownLogDebug'));
        } else {
            PEAR::registerShutdownFunc(array('BEAR_Log', 'shutDownLogLive'));
        }
    }

    /**
     * 連想配列の取得
     * 
     * <pre>
     * PHPの連想配列を指定すればそのまま、ファイルパスを指定すれば設定ファイルから読み込み連想配列として渡します。またURLのクエリー形式も使用できます。
     * BEARで広く使われています。BEARの全てのクラスのコンストラクタ（シングルトン含む）、リソースへの引数、オプションにこの連想配列フォーマットが使われます。
     * 
     * array --　連想配列としてオプションが入力されます
     * 
     * string -- ファイルから拡張子によりフォーマットが異なります
     * 　
     *  *.ini フォーマット
     *  *.xml フォーマット
     *  *.php defineフォーマット
     *
     * @param $values mixed
     * @return array オプション値
     * @todo propel, json, db, リソースURI...
     *      * 
     * @see http://pear.php.net/manual/ja/package.configuration.config.php
     * @see BEAR/test/files/example.ini
     * @see BEAR/test/files/example.xml
     * @see BEAR/test/files/example.php
     * 
     */
    public static function values($values)
    {
        // arraynならそのまま
        if (is_array($values) || is_object($values)) {
            return (array)$values;
        }
        // false | null なら 設定なし 
        if (!$values) {
            return null;
        }
        // クエリーがあるときはクエリーをパースした連想配列を返す
        $parseUrl = parse_url($values);
        if (isset($parseUrl['query'])) {
            $options = array();
            parse_str($parseUrl['query'], $options);
            return $options;
        }
        // PEAR::Configを使って設定ファイルをパース
        $pathinfo = pathinfo($values);
        $firstPathLetter = substr($values, 0, 1);
        // 相対パスなら絶対パスに
        $values = ($firstPathLetter == '/') ? $values : _BEAR_APP_HOME . '/App/resources/' . $values;
        switch ($pathinfo['extension']) {
            case 'ini' :
                $parse = 'inicommented';
                break;
            case 'xml' :
                $parse = 'xml';
                break;
            case 'php' :
                $parse = 'PHPConstants';
                break;
            case 'yml' :
                require_once 'BEAR/inc/spyc-0.2.5/spyc.php';
                $yaml = Spyc::YAMLLoad($values);
                return $yaml;
            default :
                PEAR_ErrorStack::staticPush('BEAR_Error', 0, 'error', array('ext' => $ext, 'input' => $values), 'Invalid values path');
                return false;
                break;
        }
        $config = new Config();
        $root = &$config->parseConfig($values, $parse);
        if (PEAR::isError($root)) {
            PEAR_ErrorStack::staticPush(BEAR_Error::PACKAGE_BEAR, 0, 'error', array('parse' => $parse, 'input' => $values), '設定を読み込む際のエラー: ' . $root->getMessage());
            return false;
        } else {
            $result = $root->toArray();
            return $result['root'];
        }
    }

    /**
     * デバック用関数設定
     *
     * p($value);    プリント (table)
     * c($class);    クラス解析プリント
     * t();          バックトレース
     * v($value);    Var Dump (text)
     */
    function setDebugFunction()
    {
        if (App::$debug) {
            include 'BEAR/BEAR/BEAR/function.php';
        } else {
            include 'BEAR/BEAR/BEAR/no-function.php';
        }
    }
}

// クラスローダー登録
spl_autoload_register(array('BEAR', 'autoload'));
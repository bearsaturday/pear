<?php

/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category  BEAR
 * @package   BEAR
 * @author    Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright 2008 Akihito Koriyama  All rights reserved.
 * @license   http://opensource.org/licenses/bsd-license.php BSD
 * @link      http://api.bear-project.net/BEAR/BEAR.html
 */
/**
 * p
 *
 * @return void
 * @ignore
 */
function p()
{
}

/**
 * t
 *
 * @return void
 * @ignore
 */
function t()
{
}
<?php
   if(!ereg( "Firefox", getenv( "HTTP_USER_AGENT" ) ) ) {
       // tweak for safari or ...
       echo '<html><head><script type="text/javascript" src="/beardev/bearshell/refresh.js"></script></head><body></body></html>';
   }
require_once 'App.php';
$_SERVER['beardev'] = 1;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
    <head>
        <title>BEAR Shell</title>
        <link rel="stylesheet" href="/beardev/css/bearshell.css" type="text/css" media="screen">
        <script type="text/javascript" src="/beardev/js/jquery.bear.js"></script>
        <script type="text/javascript" src="/beardev/js/app.js"></script>
        <script type="text/javascript" src="/beardev/bearshell/page.js"></script>
    </head>
    <body>
        <div id="msg"></div>
        <div id="output">
            BEAR Version <?php echo BEAR::VERSION . ' ' . date('r');?>
            <div class="info">
                type 'help' for help
            </div><br>
        </div>
        <div id="input">
            <form class='cmdline' action="/beardev/bearshell/shell.php" method="post" name="form" id="form">
                <table class="inputtable">
                    <tr>
                        <td class="inputtd">
                            <span class="prompt" id="prompt"><?php
                            echo App::$config['info']['id']?>@BEAR $</span> <input id='q' name='q' type='text' class='cmdline' value="" autocomplete='off'> <input name="_submit" type="submit"><br>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
    </body>
</html>


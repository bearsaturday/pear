<?php
/**
 * BEAR
 *
 * PHP versions 5
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Execute
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: Null.php 524 2009-03-07 06:55:47Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 */

/**
 * ヌルリソース
 *
 * <pre>
 * nullを返すリソースです。
 * </pre>
 *
 * @category   BEAR
 * @package    BEAR_Resource
 * @subpackage Execute
 * @author     Akihito Koriyama <koriyama@users.sourceforge.jp>
 * @copyright  2008 Akihito Koriyama  All rights reserved.
 * @license    http://opensource.org/licenses/bsd-license.php BSD
 * @version    SVN: Release: $Id: Null.php 524 2009-03-07 06:55:47Z koriyama@users.sourceforge.jp $
 * @link       http://api.bear-project.net/BEAR_Resource/BEAR_Resource.html
 *  */
class BEAR_Resource_Execute_Null extends BEAR_Base implements BEAR_Resource_Request_Interface
{

    /**
     * コンストラクタ
     * 
     * @param array $config 設定
     */
    function __construct($config)
    {
        parent::__construct($config);
    }

    /**
     * リソースアクセス
     *
     * リソースを使用します。
     *
     * @param array  $uri    URI
     * @param array  $values 引数
     * @param string $method リクエストメソッド（無効)
     *
     * @return mixed
     */
    public function request($uri, array $values, $method)
    {
        BEAR_Log::appLog('Resource not found', array('uri'=>$uri, 'values'=>$values, 'method'=>$method));
        throw new BEAR_Exception('Not Found', BEAR::CODE_BAD_REQUEST);
    }
}
<?php
include 'panda_ini.php';

$debugInfo = array('time' => time());
// show status page with specify http code
throw $this->_exception('User deleted.', 404, $debugInfo);
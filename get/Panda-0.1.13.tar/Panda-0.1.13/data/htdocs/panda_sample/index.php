<?php
include 'panda_ini.php';

/**
 * Main Class - run 'page'
 *
 */
class Test_App_Main
{

    /*
     * Main public val
     */
    public $a = null;

    /**
     * run page
     */
    public function run()
    {
        $page = new Test_App_Page();
        $page->init();
    }
}

/**
 * Page Class
 *
 */
class Test_App_Page
{

    /**
     * Page Const
     */
    CONST APP = 'APP_CONST';

    /**
     * Page Static Val
     */
    static $statcVar = 'this is $statc var';

    /*
     * Page Public Val
     */
    public $pub = 'this is $pub var';

    /**
     * Page private val
     */
    private $private = 'this is $private var';

    /**
     * Paga Init
     */
    public function init()
    {
        $isGood = true;
        $num = 0;
        $str = 'hello panda';
        $this->private = 'new private var';
        // asert
        $this->_assert($a);
        // Strict
        $this->_strict();
        // notice
        $this->_notice();
        //E_Warning
        $this->_warning($num);
        // repeatead error
        $this->_repeatedError();
        // E_USER_ERROR
        trigger_error('*User Error Message Here*', E_USER_WARNING);
    }

    /**
     * assert
     */
    private function _assert($data)
    {
        assert($data === false);
    }

    /**
     * E_Strict
     */
    private function _strict()
    {
        //E_Strict Creating default object from empty value (空の値からデフォルトオブジェクトを作ろうとしている。)
        $main = new Test_App_Main();
        $main->a->b = 1;
    }

    /**
     * E_Notice
     */
    private function _notice()
    {
        return $a[a];
    }

    /**
     * Warning
     */
    private function _warning($denominator)
    {
        $line = __LINE__;
        $local = "you can see in PHP error context";
        echo 1 / $denominator;
    }

    /**
     * Repeated Error
     */
    private function _repeatedError()
    {
        $line = __LINE__;
        $local = "you can see in PHP error context";
        // repeat error (report only once)
        for ($i = 0; $i < 10; $i++) {
            print $a; //notice
        }
    }

    /**
     * Error callback
     */
    public static function onError($heading, $subHeading, $info, $options)
    {
        $userAgent = isset($_GET['HTTP_USER_AGENT']) ? $_GET['HTTP_USER_AGENT'] : 'CLI';
        openlog('PHP', LOG_ODELAY, LOG_LOCAL5);
        syslog(LOG_ERR, "PHP - $heading - $subHeading - {$options['file']} - " . serialize($info) . " - $userAgent");
    }
}

?>

<html>
<head>
<link rel="stylesheet" href="default.css" type="text/css" media="screen" />
</head>
<body>
<h1>Panda Sample Page</h1>
<p>start. (Open firebug console with firePHP.)</p>
<?php
$main = new Test_App_Main();
$main->run();
// warning error in root (BIG context)
//echo 1 / 0;
?>
<p>end.</p>
<h1>More Error</h1>
<ul>
<li><a href="fatal_error.php">fatal error</a></li>
<li><a href="pear_error.php">pear error</a></li>
<li><a href="uncaught_exception.php">uncaght exception</a></li>
<li><a href="panda_exception.php">panda exception</a></li>
</ul>
<h1>PHP Standard Error (without Panda)</h1>
<ul>

<li><a href="?nopanda">this page</a></li>
<li><a href="fatal_error.php?nopanda">fatal error</a></li>
<li><a href="pear_error.php?nopanda">pear error</a></li>
<li><a href="uncaught_exception.php?nopanda">uncaght exception</a></li>

</ul>
<h1>Debug Utility</h1>
<ul>
<li><a href="utility.php?a=1&msg=hello_panda">panda debug function</a></li>
</ul>
</body>
</html>



</body>
</html>

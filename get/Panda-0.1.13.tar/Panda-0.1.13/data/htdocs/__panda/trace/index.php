<?php
require_once '../inc/debuglib.php';

error_reporting(false);


/**
 * Trace Page Class
 *
 */
class Panda_Trace_Page
{

    /**
     * Editor - None
     */
    const EDITOR_NONE = 0;

    /**
     * Editor - TextMate
     */
    const EDITOR_TEXTMATE = 1;

    /**
     * trace depth
     *
     * @var integer
     */
    private $_levelNum;

    /**
     * trace levels
     *
     * @var array
     */
    private $_traceLevels;

    /**
     * raw trace log
     *
     * @var array
     */
    private $_traceLog;

    /**
     * trace summery html
     *
     * @var string
     */
    private $_traceSummary;

    /**
     * each trace page
     *
     * @var array
     */
    private $_tracePage;

    /**
     * reflection log
     *
     * @var array
     */
    private $_ref;

    /**
     * Editor for file
     *
     * @var string
     */
    private $_editor = self::EDITOR_TEXTMATE;

    /**
     * Constructer
     */
    public function __construct()
    {
        $this->_init();
        $this->_run();
    }

    /**
     * Get trace depth
     *
     * @return integer
     */
    public function getLineNum()
    {
        return $this->_levelNum;
    }

    /**
     * Get trace page string
     *
     * @return string
     */
    public function getTracePage()
    {
        return $this->_tracePage;
    }

    /**
     * Get Summery page
     *
     * @return string
     */
    public function getSummeryPage()
    {
        return "<h3>Summery</h3>" . $this->_traceSummary;
    }

    /**
     * Get debug_backtrace() raw string html
     *
     * @return string
     */
    public function getRaw()
    {
        $raw = '<pre>' . print_r($this->_traceLog, true) . '</pre>';
        return $raw;
    }

    /**
     * Init
     *
     * @return void
     */
    private function _init()
    {
        // for PHP 5.2.0 or earlier
        if (!function_exists('sys_get_temp_dir')) {
            require_once '../inc/sys_get_temp_dir.php';
        }
        // init
        $traceFile = sys_get_temp_dir() . '/trace-' . $_GET['id'] . '.log';
        if (!file_exists($traceFile)) {
            trigger_error('invalid trace file. ' . $traceFile, E_USER_ERROR);
        }
        // store trace data
        $this->_traceLog = unserialize(file_get_contents($traceFile));
        if (!$this->_traceLog) {
            die("<p>trace is not available...</p>");
        }
        // store refection data if exists
        $refDataFile = "{$traceFile}.ref.log";
        if (file_exists($refDataFile)) {
            $this->_ref = unserialize(file_get_contents($refDataFile));
        }
        $this->_traceLevels = array_keys($this->_traceLog);
        $this->_levelNum = count($this->_traceLevels);
        $this->_editor = isset($_GET['editor']) ? $_GET['editor'] : self::EDITOR_NONE;
    }

    /**
     * Create data as object property
     *
     * @return void
     */
    private function _run()
    {
        $i = 0;
        // make page data
        foreach ($this->_traceLevels as $level) {
            $trace = $this->_traceLog[$level];
            $line = $trace['line'];
            $file = $trace['file'];
            if (!file_exists($trace['file'])) {
                $hitLine = '';
                $shortList = '';
            } else {
                $files = file($trace['file']);
                $fileArray = array_map('htmlspecialchars', $files);
                if (isset($fileArray[$line - 1])) {
                    $fileArray[$line - 1] = "<span class=\"hit-line\">{$fileArray[$line - 1]}</span>";
                }
                $shortListArray = array_slice($fileArray, $line - 6, 11);
                if (isset($shortListArray[5])) {
                    $shortListArray[5] = "<a href=\"#traceline{$i}\" id=\"traceline-back{$i}\">{$shortListArray[5]}</a>";
                }
                $shortList = implode('', $shortListArray);
                $shortList = '<pre class="short-list">' . $shortList . '</pre>';
                if (isset($fileArray[$line - 1])) {
                    $hitLine = $fileArray[$line - 1];
                }
                if (isset($fileArray[$line - 1])) {
                    $fileArray[$line - 1] = "<a href=\"#traceline-back{$i}\" id=\"traceline{$i}\">{$fileArray[$line - 1]}</a>";
                }
            }
            $args = array();
            if (is_array($trace['args'])) {
                foreach ($trace['args'] as $arg) {
                    if (is_array($arg)) {
                        $args[] = 'Array';
                    } elseif (is_string($arg)) {
                        $args[] = "'{$arg}'";
                    } elseif (is_scalar($arg)) {
                        $args[] = $arg;
                    } else {
                        $args[] = 'Object';
                    }
                }
                $args = implode(',', $args);
            }
            if (isset($trace['class'])) {
                $hitInfo = "{$trace['class']}{$trace['type']}{$trace['function']}({$args}) ";
            } elseif (isset($trace['function'])) {
                $hitInfo = "{$trace['function']}({$args}) ";
            } else {
                $hitInfo = '';
            }
            $this->_traceSummary .= '<li><span class="timeline-num">' . $i . '</span>';
            $this->_traceSummary .= '<span class="timeline-body">' . $hitLine . '</span>';
            $this->_traceSummary .= '<span class="timeline-info">' . $hitInfo . '<br />';
            //            $this->_traceSummary .= '<span class="panda-file">';
            $this->_traceSummary .= $this->_getEditorLink($trace['file'], $line);
            // trace detail
            $this->_tracePage[$i] = "<h3 class='hit-head'>" . '<span class="timeline-num">' . $i . "</span>{$hitLine}</h3>";
            $this->_tracePage[$i] .= '<span id="hit-info">' . $hitInfo . '<br />';
            $this->_tracePage[$i] .= $this->_getEditorLink($file, $line) . '</span>';
            $this->_tracePage[$i] .= $shortList;
            if (isset($trace['args'])) {
                $this->_tracePage[$i] .= '<h3>Args</h3>';
                $this->_tracePage[$i] .= print_a($trace['args'], "return:1");
            }
            if (isset($trace['object'])) {
                $this->_tracePage[$i] .= '<h3>Object</h3>';
                $this->_tracePage[$i] .= print_a((array)$trace['object'], "return:1");
            }
            if (isset($this->_ref[$i]) && file_exists($this->_ref[$i]['file'])) {
                $array = array_slice(file($this->_ref[$i]['file']), $this->_ref[$i]['start'] - 1, $this->_ref[$i]['end'] - $this->_ref[$i]['start'] + 1);
                $methodCode = $this->_ref[$i]['doc'] . "\n";
                $methodCode .= implode('', $array);
                $open = "<?php ";
                $clode = " ?>";
                $code = highlight_string($open . $methodCode . $clode, true);
                $code = str_replace('&lt;?php', '', $code);
                $code = str_replace('?&gt;', '', $code);
                $code = str_replace('<span style="color: #0000BB">&lt;?php&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>', '', $code);
                $code = str_replace($clode, '', $code);
                $this->_tracePage[$i] .= "<h3>Source Code for {$trace['class']}::{$trace['function']}()</h3>";
                $this->_tracePage[$i] .= '<pre><div class="short-list">' . $code . '</div></pre>';
                if ($this->_ref[$i]['export']) {
                    $this->_tracePage[$i] .= '<h3>Class Reflection</h3>';
                    $this->_tracePage[$i] .= '<pre>' . $this->_ref[$i]['export'] . '</pre>';
                }
            }
            $i++;
        }
    }

    /**
     * Get editor link
     */
    private function _getEditorLink($file, $line = 0, $column = 0, $content = false)
    {
        if (!$content) {
            if ($file) {
                $content = "$file on line $line";
            } else {
                return '';
            }
        }
        switch ($this->_editor) {
        case self::EDITOR_TEXTMATE :
            $result = '<a class="file" class="panda-file" name="Edit in TextMate" href="txmt://open/?url=file://';
            $result .= $file . '&line=' . $line . '&column=' . $column . '">' . $content . '</a>';
            break;
        default :
            $result = $content;
            break;
        }
        return $result;
    }
}
// retrieve valiables
$trace = new Panda_Trace_Page();
$levelNum = $trace->getLineNum();
$tracePage = $trace->getTracePage();
$summaryPage = $trace->getSummeryPage();
$raw = $trace->getRaw();
$path = (isset($_GET['path'])) ? $path : '/';


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<title>Backtrace</title>
<link rel="shortcut icon" href="<?php
echo $path;
?>__panda/favicon.ico">
<link type="text/css"
	href="<?php
echo $path;
?>__panda/jquery-ui/css/jquery-ui-1.7.1.custom.css"
	rel="stylesheet">
<link rel="stylesheet"
	href="<?php
echo $path;
?>__panda/css/default.css" type="text/css"
	media="screen">
<link rel="stylesheet" href="<?php
echo $path;
?>__panda/css/trace.css"
	type="text/css" media="screen">
<script type="text/javascript"
	src="<?php
echo $path;
?>__panda/jquery-ui/js/jquery-1.3.2.min.js"></script>
<script type="text/javascript"
	src="<?php
echo $path;
?>__panda/jquery-ui/js/jquery-ui-1.7.1.custom.min.js"></script>
<script type="text/javascript"><!--
    $(function(){
        // Tabs
        $('#tabs').tabs({ajaxOptions: { async : true, dataType : "html"}});
    });
    --></script>
</head>
<body onload="">
<h1>Backtrace</h1>
<div id="tabs">
<ul>
	<li><a href="#index">Summary</a></li>
	<?php
for ($i = 0; $i < $levelNum; $i++) {
    echo "<li><a href=\"#tab-{$i}\">{$i}</a></li>";
}
?>
	<li><a href="#raw">Raw</a></li>
</ul>

<div id="index">
<ol id="trace-summary" class="timeline">
<?php
echo $summaryPage;
?>
</ol>
</div>
<?php
for ($i = 0; $i < $levelNum; $i++) {
    $page = isset($tracePage[$i]) ? $tracePage[$i] : 'n/a';
    echo " <div id=\"tab-{$i}\">" . $page . "</div>";
}
?>
<div id="raw"><?php
echo $raw;
?></div>
</div>
</body>
</html>
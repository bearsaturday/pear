README
======

What is Panda?
-----------------
Panda is a PHP error handler.

Requirements
------------
Panda is only supported on PHP 5.2 and up.

Install Panda
-------------
$ pear channel-discover pear.bear-project.net  
$ pear install bear/Panda-beta

First Panda
-------------
1) move data/htdocs/panda_sample under web root directory.
2) edit papnda_ini.file,
3) oepn  http://example.com/panda_sample/

Panda Quick Manual
------------------
English
http://code.google.com/p/panda-project/wiki/quickmanualen
Japanese
http://code.google.com/p/panda-project/wiki/quickmanual



